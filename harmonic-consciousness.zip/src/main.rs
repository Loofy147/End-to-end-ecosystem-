mod vector;
mod triangle;
mod reciprocal;
mod field;
mod utils;

use field::create_harmonic_field;
use vector::ConsciousVector;

fn main() -> Result<(), Box<dyn std::error::Error>> {
    let field = create_harmonic_field(ConsciousVector::new(5.0, 11.0, 3.0)?);
    println!("Field Coherence Index: {:.6}", field.coherence_index);
    println!("Field Entropy: {:.6}", field.entropy);
    Ok(())
}
