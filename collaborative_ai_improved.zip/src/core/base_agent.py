import asyncio
import logging
from abc import ABC, abstractmethod
from typing import Dict, Any
from datetime import datetime

class BaseAgent(ABC):
    def __init__(self, agent_id: str, name: str, capabilities: list):
        self.agent_id = agent_id
        self.name = name
        self.capabilities = capabilities
        self.state = {}
        self.logger = logging.getLogger(f"agent.{self.name}.{self.agent_id}")
        self.metrics = {"tasks_processed": 0, "errors": 0, "avg_latency": 0.0}

    @abstractmethod
    async def process_task(self, task: Any) -> Dict[str, Any]:
        pass

    async def handle_task(self, task: Any) -> Dict[str, Any]:
        start = datetime.utcnow()
        try:
            result = await self.process_task(task)
            self.metrics["tasks_processed"] += 1
            return result
        except Exception as e:
            self.metrics["errors"] += 1
            self.logger.exception("Error processing task")
            return {"status": "error", "error": str(e)}
        finally:
            latency = (datetime.utcnow() - start).total_seconds()
            # rolling average
            prev = self.metrics["avg_latency"]
            self.metrics["avg_latency"] = (prev * (self.metrics['tasks_processed'] - 1) + latency) / max(1, self.metrics['tasks_processed'])
