import asyncio
from src.core.base_agent import BaseAgent
from typing import Dict, Any

class EnsembleAgent(BaseAgent):
    async def process_task(self, task: Any) -> Dict[str, Any]:
        self.logger.info(f"Task {task.task_id}: starting ensemble")
        models = task.input.get('models', [])
        await asyncio.sleep(0.2)
        return {"status":"success", "ensemble": "voting_average", "performance":0.94}
