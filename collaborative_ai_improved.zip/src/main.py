import asyncio
import logging
from src.orchestrator import CollaborativeOrchestrator

def run_demo():
    logging.basicConfig(level=logging.INFO)
    orchestrator = CollaborativeOrchestrator()
    from src.agents.data_preprocessing_agent import DataPreprocessingAgent
    from src.agents.neural_architect_agent import NeuralArchitectAgent
    from src.agents.hyperparameter_agent import HyperparameterAgent
    from src.agents.validation_agent import ValidationAgent
    from src.agents.ensemble_agent import EnsembleAgent

    orchestrator.register_agent("data_preprocessor", DataPreprocessingAgent("dp1","DataPreprocessing",[]))
    orchestrator.register_agent("architect", NeuralArchitectAgent("na1","NeuralArchitect",[]))
    orchestrator.register_agent("hyperparam", HyperparameterAgent("hp1","Hyperparameter",[]))
    orchestrator.register_agent("validator", ValidationAgent("va1","Validation",[]))
    orchestrator.register_agent("ensemble", EnsembleAgent("en1","Ensemble",[]))

    model_spec = {"data":"raw_dataset", "hparams":{"lr":[0.001,0.01]}}
    result = asyncio.run(orchestrator.orchestrate(model_spec))
    print("Orchestration result:", result)

if __name__ == "__main__":
    run_demo()
