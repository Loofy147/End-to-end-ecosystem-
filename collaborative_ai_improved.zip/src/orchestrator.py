import asyncio
import logging
from src.core.base_agent import BaseAgent
from typing import Dict, Any
import uuid

class TaskDefinition:
    def __init__(self, task_id:str, input:Dict[str,Any]):
        self.task_id = task_id
        self.input = input

class CollaborativeOrchestrator:
    def __init__(self):
        self.agents = {}
        self.logger = logging.getLogger("orchestrator")
        self.metrics = {"tasks_submitted":0, "tasks_failed":0}

    def register_agent(self, name:str, agent:BaseAgent):
        self.agents[name] = agent
        self.logger.info(f"Registered agent: {name}")

    async def submit_task(self, agent_name:str, input:Dict[str,Any]) -> Any:
        self.metrics["tasks_submitted"] += 1
        if agent_name not in self.agents:
            self.metrics["tasks_failed"] +=1
            raise ValueError("Unknown agent")
        task = TaskDefinition(str(uuid.uuid4()), input)
        result = await self.agents[agent_name].handle_task(task)
        return result

    async def orchestrate(self, model_spec:Any) -> Dict[str,Any]:
        data = await self.submit_task("data_preprocessor", {"raw_data":model_spec["data"]})
        arch = await self.submit_task("architect", {"problem_spec":model_spec})
        hp = await self.submit_task("hyperparam", {"search_space":model_spec["hparams"]})
        val = await self.submit_task("validator", {"model":arch})
        ens = await self.submit_task("ensemble", {"models":[arch]})
        return {"data":data, "architecture":arch, "hpo":hp, "validation":val, "ensemble":ens}
