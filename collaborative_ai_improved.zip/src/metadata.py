from enum import Enum
from dataclasses import dataclass, field
from typing import Dict, Any, List
from datetime import datetime
import uuid

class ModelComponentType(Enum):
    DATA_PREPROCESSOR = "data_preprocessor"
    FEATURE_EXTRACTOR = "feature_extractor"
    NEURAL_NETWORK = "neural_network"
    OPTIMIZER = "optimizer"
    EVALUATOR = "evaluator"
    ENSEMBLE_COORDINATOR = "ensemble_coordinator"
    HYPERPARAMETER_TUNER = "hyperparameter_tuner"
    MODEL_VALIDATOR = "model_validator"

@dataclass
class ModelComponent:
    component_id: str
    component_type: ModelComponentType
    config: Dict[str, Any]
    dependencies: List[str] = field(default_factory=list)
    created_at: datetime = field(default_factory=datetime.utcnow)
    state: Dict[str, Any] = field(default_factory=dict)
