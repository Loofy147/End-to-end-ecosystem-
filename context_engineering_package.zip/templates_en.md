
# Context Engineering Templates – English

## Specific Templates (4)

### 1. Deep Analysis Template
```
Role: Expert Analyst in [Domain]
Task: Conduct comprehensive analysis of [Topic]
Outputs: Strengths, Opportunities, Challenges, Recommendations
```

### 2. Creative Production Template
```
Role: Creative Content Writer
Task: Produce [Type] content about [Subject]
Audience: [Describe audience]
Constraints: [Limits]
```

### 3. Technical Problem-Solving Template
```
Role: Software Engineer
Problem: [Problem description]
Environment: [Technical details]
Outputs: Code, Documentation, Tests
```

### 4. AI Project Management Template
```
Role: AI Project Manager
Task: Plan and execute [Project Name]
Requirements: [Goals, Budget, Timeline]
Expected Deliverables: [Deliverables]
```

## General Templates (2)

### A. Basic Template
```
Role: [Define role]
Task: [Describe task]
Context: [Essential information]
Outputs: [Desired format]
```

### B. Advanced Template
```
You are a [Role] with experience in [Domain].
Your task: [Task]
Context: [Details]
Constraints: [Rules]
Examples: [Example 1], [Example 2]
```
