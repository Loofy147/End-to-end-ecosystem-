
import argparse, json, os, csv, random
from ga_core import run_ga

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", default="config.json")
    ap.add_argument("--problem", default=None, help="override: string_matching|knapsack|tsp")
    ap.add_argument("--trials", type=int, default=None)
    ap.add_argument("--case", default=None, help="baseline|advanced")
    ap.add_argument("--quick", action="store_true", help="reduce gens/trials for a quick pass")
    args = ap.parse_args()

    with open(args.config, "r", encoding="utf-8") as f:
        cfg = json.load(f)

    if args.problem: cfg["problem"] = args.problem
    trials = args.trials if args.trials else cfg.get("trials", 10)

    # quick mode tweaks
    if args.quick:
        cfg["ga"]["generations"] = max(50, int(cfg["ga"]["generations"]/5))
        trials = min(5, trials)

    out_dir = cfg["logging"].get("out_dir", "results")
    os.makedirs(out_dir, exist_ok=True)

    cases = [args.case] if args.case else ["baseline", "advanced"]

    for case in cases:
        rows = []
        for t in range(trials):
            seed = 1000 + t
            random.seed(seed)
            res = run_ga(cfg["problem"], cfg, case=case, rng_seed=seed, per_gen_log=cfg["logging"].get("per_gen_logging", False))
            rows.append({
                "trial": t+1,
                "case": case,
                "seed": seed,
                "best_fitness": res["best_fitness"],
                "avg_fitness": res["avg_fitness"],
                "time_s": res["time_s"],
                "generations": res["generations"]
            })
        out_csv = os.path.join(out_dir, f"{cfg['problem']}_{case}_results.csv")
        with open(out_csv, "w", newline="", encoding="utf-8") as f:
            w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
            w.writeheader(); w.writerows(rows)
        print(f"[OK] Saved: {out_csv}")

if __name__ == "__main__":
    main()
