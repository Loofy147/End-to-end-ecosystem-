
# GA Experiment Package

حزمة جاهزة لتشغيل تجارب الخوارزمية (Baseline vs Advanced) على مشاكل: **String Matching**, **Knapsack**, **TSP**، مع دعم محاكاة صناعية لتقييم لياقة مكلف.

## الملفات
- `config.json` — إعدادات افتراضية قابلة للتعديل.
- `ga_core.py` — نواة الخوارزمية والمشاكل والعمليات الجينية والتحسينات (islands, local-opt, adaptive).
- `run_all.py` — تشغيل Baseline وAdvanced وتوليد CSVs في `results/`.
- `ablation_runner.py` — تشغيل حالات ablation (تعطيل/تقليل مكونات) وإخراج ملخص.

## تشغيل سريع
```bash
python run_all.py --problem tsp --trials 6 --quick
python run_all.py --problem tsp --case baseline --trials 10
python run_all.py --problem tsp --case advanced --trials 10
python ablation_runner.py --problem tsp --trials 8
```

## تفعيل محاكاة صناعية (تقييم مكلف)
اضبط في `config.json`:
```json
"industrial_sim": {"expensive_eval": true, "heavy_work": 20000}
```
ثم:
```bash
python run_all.py --problem tsp --trials 4 --quick
```

## إخراج النتائج
- كل تشغيل يولد CSV داخل `results/`:
  - `<problem>_baseline_results.csv`
  - `<problem>_advanced_results.csv`
  - `<problem>_ablation_summary.csv`
```

