
import argparse, json, os, csv, random, copy, statistics as stats
from ga_core import run_ga

def run_case(cfg, case_name, trials):
    rows = []
    for t in range(trials):
        seed = 5000 + t
        random.seed(seed)
        res = run_ga(cfg["problem"], cfg, case=case_name, rng_seed=seed, per_gen_log=cfg["logging"].get("per_gen_logging", False))
        rows.append(res)
    return rows

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", default="config.json")
    ap.add_argument("--problem", default=None)
    ap.add_argument("--trials", type=int, default=12)
    args = ap.parse_args()

    with open(args.config, "r", encoding="utf-8") as f:
        base_cfg = json.load(f)
    if args.problem: base_cfg["problem"] = args.problem

    out_dir = base_cfg["logging"].get("out_dir", "results")
    os.makedirs(out_dir, exist_ok=True)

    # Define ablation variants
    variants = {
        "baseline": lambda c: c,
        "advanced": lambda c: c,
        "adv_no_islands": lambda c: (c["advanced"].update({"use_islands": False}) or c),
        "adv_no_local": lambda c: (c["advanced"].update({"use_local_opt": False}) or c),
        "adv_no_adaptive": lambda c: (c["advanced"].update({"adaptive": False}) or c),
        "adv_low_local_rate": lambda c: (c["advanced"].update({"use_local_opt": True, "local_opt_rate": 0.02}) or c),
    }

    summary_rows = []
    for name, mut in variants.items():
        cfg = copy.deepcopy(base_cfg)
        cfg["advanced"] = copy.deepcopy(base_cfg.get("advanced", {}))
        if name=="baseline": case="baseline"
        else: case="advanced"
        cfg = mut(cfg)
        rows = []
        for t in range(args.trials):
            seed = 9000 + t
            random.seed(seed)
            res = run_ga(cfg["problem"], cfg, case=case, rng_seed=seed, per_gen_log=False)
            rows.append(res)
        mean_best = stats.mean(r["best_fitness"] for r in rows)
        mean_time = stats.mean(r["time_s"] for r in rows)
        summary_rows.append({"variant": name, "mean_best": mean_best, "mean_time_s": mean_time})

    # write summary
    out_csv = os.path.join(out_dir, f"{base_cfg['problem']}_ablation_summary.csv")
    import csv
    with open(out_csv, "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=["variant", "mean_best", "mean_time_s"])
        w.writeheader(); w.writerows(summary_rows)
    print(f"[OK] Ablation summary saved: {out_csv}")

if __name__ == "__main__":
    main()
