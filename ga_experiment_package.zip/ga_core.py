
import math, random, time, json, os
from typing import List, Tuple, Dict, Any

# ---------------- Utilities ----------------
def now(): return time.perf_counter()

def lru_freq_memo(maxsize=1000):
    cache = {}
    freq = {}
    last = {}
    def decorator(fn):
        def wrapped(*args):
            key = args
            if key in cache:
                freq[key] = freq.get(key, 0) + 1
                last[key] = time.time()
                return cache[key]
            res = fn(*args)
            if len(cache) >= maxsize:
                # evict worst by freq/recency
                worst_key, worst_score = None, float("inf")
                nowt = time.time()
                for k in list(cache.keys()):
                    f = freq.get(k,1); rec = nowt - last.get(k, nowt)
                    score = f/(rec+1e-9)
                    if score < worst_score:
                        worst_key, worst_score = k, score
                if worst_key is not None:
                    cache.pop(worst_key, None); freq.pop(worst_key, None); last.pop(worst_key, None)
            cache[key] = res
            freq[key] = 1
            last[key] = time.time()
            return res
        return wrapped
    return decorator

# ---------------- Problems ----------------
ARABIC_CHARS = list("ابتثجحخدذرزسشصضطظعغفقكلمنهويءآأؤإئى ")

def build_string_target(cfg):
    t = cfg.get("target_string") or "".join(random.choice(ARABIC_CHARS) for _ in range(cfg.get("target_length", 30)))
    return t

def create_random_string(target):
    return "".join(random.choice(ARABIC_CHARS) for _ in range(len(target)))

def fitness_string(ind, target):
    return sum(1 for a,b in zip(ind, target) if a==b)/len(target)

def create_random_knapsack(n):
    return [random.random()<0.5 for _ in range(n)]

def knapsack_optimal_value(items, capacity):
    dp = [0]*(capacity+1)
    for w,v in items:
        for c in range(capacity, w-1, -1):
            dp[c] = max(dp[c], dp[c-w]+v)
    return dp[capacity]

def fitness_knapsack(ind, items, capacity, opt_val=None):
    tw = 0; tv = 0
    for i,b in enumerate(ind):
        if b:
            tw += items[i][0]; tv += items[i][1]
    if tw>capacity: return 0.0
    if opt_val is None or opt_val==0: return tv/ max(1,sum(v for _,v in items))
    return tv/opt_val

def create_random_tsp(n):
    r = list(range(n)); random.shuffle(r); return r

def tour_length(route, cities):
    total = 0.0
    for i in range(len(route)):
        a = cities[route[i]]; b = cities[route[(i+1)%len(route)]]
        total += math.hypot(a[0]-b[0], a[1]-b[1])
    return total

def expensive_penalty(ops:int):
    s = 0.0
    for i in range(ops):
        s += math.sin(i)*math.cos(1.0001*i)
    return s

def fitness_tsp(route, cities, heavy_ops=0):
    # heavy_ops>0 simulates industrially expensive evaluation
    if heavy_ops>0:
        _ = expensive_penalty(heavy_ops)
    return 1.0/(1.0 + tour_length(route, cities))

# ---------------- Genetic operators ----------------
def one_point_crossover(a,b):
    L = len(a); p = random.randrange(1, L)
    return a[:p]+b[p:], b[:p]+a[p:]

def order_crossover(p1, p2):
    n = len(p1)
    a = random.randrange(n); b = random.randrange(n)
    i,j = min(a,b), max(a,b)
    c1 = [-1]*n; c1[i:j+1] = p1[i:j+1]
    s1 = set(c1[i:j+1])
    donor1 = [x for x in p2 if x not in s1]
    pos = (j+1)%n
    for v in donor1: c1[pos]=v; pos=(pos+1)%n
    c2 = [-1]*n; c2[i:j+1] = p2[i:j+1]
    s2 = set(c2[i:j+1])
    donor2 = [x for x in p1 if x not in s2]
    pos = (j+1)%n
    for v in donor2: c2[pos]=v; pos=(pos+1)%n
    return c1, c2

def mutate_string(s, rate):
    out = []
    for ch in s:
        if random.random()<rate: out.append(random.choice(ARABIC_CHARS))
        else: out.append(ch)
    return "".join(out)

def mutate_knapsack(ind, rate):
    r = ind[:]
    if random.random()<rate*5:
        i = random.randrange(len(r)); r[i] = not r[i]
    return r

def mutate_tsp(route, rate):
    r = route[:]
    if random.random()<rate*5:
        i = random.randrange(len(r)); j = random.randrange(len(r)); r[i], r[j] = r[j], r[i]
    return r

def two_opt(route, cities, tries=10):
    n = len(route)
    best = route; best_len = tour_length(best, cities)
    for _ in range(tries):
        i = random.randrange(n-1); j = random.randrange(i+1, n)
        cand = route[:]; cand[i:j+1] = reversed(cand[i:j+1])
        L = tour_length(cand, cities)
        if L < best_len: return cand
    return route

def hill_climb_bits(ind, fitness_fn, tries=10):
    best = ind[:]; best_f = fitness_fn(best)
    for _ in range(tries):
        i = random.randrange(len(best))
        cand = best[:]; cand[i] = not cand[i]
        f = fitness_fn(cand)
        if f>best_f:
            best, best_f = cand, f
    return best

def tournament_select(pop, fits, k=3):
    best_idx = None
    for _ in range(k):
        i = random.randrange(len(pop))
        if best_idx is None or fits[i]>fits[best_idx]: best_idx = i
    return pop[best_idx]

# ---------------- GA runners ----------------
def run_ga(problem:str, cfg:dict, case:str="baseline", rng_seed:int=0, per_gen_log:bool=False):
    random.seed(rng_seed)

    pop_size = cfg["ga"]["population_size"]
    gens = cfg["ga"]["generations"]
    elit = cfg["ga"]["elitism_rate"]
    base_mut = cfg["ga"]["base_mutation"]
    k = cfg["ga"].get("tournament_k", 3)

    adv = cfg.get("advanced", {})
    use_islands = case!="baseline" and adv.get("use_islands", False)
    use_local = case!="baseline" and adv.get("use_local_opt", False)
    use_adapt = case!="baseline" and adv.get("adaptive", False)
    local_rate = adv.get("local_opt_rate", 0.1)
    island_count = adv.get("island_count", 4)
    island_every = adv.get("island_every", 10)
    island_iters = adv.get("island_iters", 2)

    heavy = 0
    if cfg.get("industrial_sim", {}).get("expensive_eval", False):
        heavy = int(cfg["industrial_sim"].get("heavy_work", 0))

    # Prepare problem
    if problem=="string_matching":
        target = build_string_target(cfg["string_matching"])
        pop = [create_random_string(target) for _ in range(pop_size)]
        fit_fn = lambda ind: fitness_string(ind, target)
        mutate_fn = lambda ind, mr: mutate_string(ind, mr)
        cross_fn = one_point_crossover
        diversity = lambda p: sum(sum(a!=b for a,b in zip(p[i], p[j]))/len(p[i]) for i in range(len(p)) for j in range(i+1, len(p))) / max(1, (len(p)*(len(p)-1)/2))

    elif problem=="knapsack":
        n = cfg["knapsack"]["n"]; cap = cfg["knapsack"]["capacity"]
        # synthesize items (weight, value) reproducibly
        r = random.Random(cfg["knapsack"].get("seed", 42))
        items = [(r.randint(1,25), r.randint(5,120)) for _ in range(n)]
        opt = knapsack_optimal_value(items, cap) if n<=4000 else None
        pop = [create_random_knapsack(n) for _ in range(pop_size)]
        fit_fn = lambda ind: fitness_knapsack(ind, items, cap, opt)
        mutate_fn = lambda ind, mr: mutate_knapsack(ind, mr)
        cross_fn = one_point_crossover
        def diversity(p):
            total=0; pairs=0
            for i in range(len(p)-1):
                for j in range(i+1,len(p)):
                    total += sum(1 for a,b in zip(p[i], p[j]) if a!=b)/len(p[i]); pairs+=1
            return total/max(1,pairs)

    elif problem=="tsp":
        n = cfg["tsp"]["num_cities"]
        r = random.Random(cfg["tsp"].get("seed", 42))
        cities = [(r.uniform(0,1000), r.uniform(0,1000)) for _ in range(n)]
        pop = [create_random_tsp(n) for _ in range(pop_size)]
        fit_fn = lambda route: fitness_tsp(route, cities, heavy_ops=heavy)
        mutate_fn = lambda ind, mr: mutate_tsp(ind, mr)
        cross_fn = order_crossover
        def diversity(p):
            total=0; pairs=0
            for i in range(len(p)-1):
                for j in range(i+1,len(p)):
                    total += sum(1 for a,b in zip(p[i], p[j]) if a!=b)/len(p[i]); pairs+=1
            return total/max(1,pairs)
    else:
        raise ValueError("Unknown problem")

    def eval_pop(pop):
        return [fit_fn(ind) for ind in pop]

    def apply_local(ind):
        if not use_local: return ind
        if problem=="tsp":
            if random.random()<local_rate:
                return two_opt(ind, cities)  # type: ignore
            return ind
        elif problem=="knapsack":
            if random.random()<local_rate:
                return hill_climb_bits(ind, fit_fn, tries=10)
            return ind
        return ind

    def evolve_islands(pop, mutation_rate):
        size = len(pop)
        if island_count<=1: return pop
        islands = [[] for _ in range(island_count)]
        for idx,ind in enumerate(pop):
            islands[idx%island_count].append(ind)
        # do small iterations per island
        for _ in range(island_iters):
            new_islands = []
            for isl in islands:
                fits = eval_pop(isl)
                ranked = [x for _,x in sorted(zip(fits, isl), key=lambda t:-t[0])]
                elites = ranked[:max(1, int(0.2*len(ranked)))]
                newp = elites[:]
                while len(newp) < len(isl):
                    p1 = tournament_select(ranked, eval_pop(ranked), k)
                    p2 = tournament_select(ranked, eval_pop(ranked), k)
                    c1,c2 = cross_fn(p1,p2)
                    m1 = mutate_fn(c1, mutation_rate)
                    newp.append(m1)
                new_islands.append(newp[:len(isl)])
            islands = new_islands
        # ring migration: move best to next
        for i in range(len(islands)):
            src = islands[i]; dst = islands[(i+1)%len(islands)]
            if src and dst:
                # replace worst in dst with best of src
                bsrc = max(src, key=lambda x: fit_fn(x))
                worst_idx = min(range(len(dst)), key=lambda j: fit_fn(dst[j]))
                dst[worst_idx] = bsrc
        merged = [ind for isl in islands for ind in isl]
        return merged[:size]

    mutation = base_mut
    start = now()
    fits = eval_pop(pop)
    history = []
    stag_window = adv.get("adaptive_params", {}).get("stagnation_window", 5)
    best_track = []

    for gen in range(1, gens+1):
        if use_islands and gen % island_every == 0:
            pop = evolve_islands(pop, mutation)
            fits = eval_pop(pop)

        # elitism
        zipped = sorted(zip(pop, fits), key=lambda x:x[1], reverse=True)
        elite_count = max(1, int(elit*pop_size))
        newpop = []
        # local-opt on elites with some probability
        for i in range(elite_count):
            ind = zipped[i][0]
            ind2 = apply_local(ind) if random.random()<0.5 else ind
            newpop.append(ind2)

        # offspring
        while len(newpop) < pop_size:
            p1 = tournament_select(pop, fits, k); p2 = tournament_select(pop, fits, k)
            c1,c2 = cross_fn(p1,p2)
            m1 = mutate_fn(c1, mutation)
            if problem=="tsp" and use_local and random.random()<0.08:
                m1 = two_opt(m1, cities)  # type: ignore
            newpop.append(m1)
            if len(newpop)<pop_size:
                m2 = mutate_fn(c2, mutation)
                if problem=="tsp" and use_local and random.random()<0.08:
                    m2 = two_opt(m2, cities)  # type: ignore
                newpop.append(m2)
        pop = newpop[:pop_size]
        fits = eval_pop(pop)

        best = max(fits); avg = sum(fits)/len(fits); div = diversity(pop)
        best_track.append(best)

        if per_gen_log:
            history.append({"generation": gen, "best": best, "avg": avg, "diversity": div, "mutation": mutation})

        # adaptive mutation
        if use_adapt and gen>stag_window:
            if abs(best_track[-1] - best_track[-stag_window]) < 1e-4:
                mutation = min(adv.get("adaptive_params", {}).get("mutation_max", 0.5), mutation*1.2)
            else:
                mutation = max(adv.get("adaptive_params", {}).get("mutation_min", 0.001), mutation*0.98)

    total = now()-start
    result = {
        "best_fitness": max(fits),
        "avg_fitness": sum(fits)/len(fits),
        "time_s": total,
        "generations": gens,
        "history": history
    }
    return result
