import uuid, copy

def generate_plan(task):
    meta = task.get("meta", {})
    problem_id = task.get("problem_id", task.get("task_id", "p_"+uuid.uuid4().hex[:6]))
    plan = {"plan_id":"plan_"+uuid.uuid4().hex[:8], "problem_id":problem_id, "goal_high":task.get("goal_high",""), "subgoals":[]}
    t = meta.get("type")
    if t=="quadratic":
        a,b,c = meta.get("a"), meta.get("b"), meta.get("c")
        plan["subgoals"].append({"id":"g1","type":"solve_quadratic","spec":{"a":a,"b":b,"c":c},"success_criteria":{"sum_eq": -b/a if a else None}})
    elif t=="nav":
        goal = meta.get("goal",[0,0])
        wp1 = [goal[0]//2, goal[1]//2]
        plan["subgoals"].append({"id":"g1","type":"reach_waypoint","spec":{"waypoint":wp1,"tolerance":0.5},"success_criteria":{"distance_lt":1.0}})
        plan["subgoals"].append({"id":"g2","type":"reach_waypoint","spec":{"waypoint":goal,"tolerance":0.5},"success_criteria":{"distance_lt":0.5}})
    elif t=="fetch":
        objs = meta.get("objects",[{}])
        objid = objs[0].get("id") if objs else None
        plan["subgoals"].append({"id":"g1","type":"pick_object","spec":{"object_id":objid},"success_criteria":{"picked":True}})
        plan["subgoals"].append({"id":"g2","type":"deliver","spec":{"zone":meta.get("zone")},"success_criteria":{"delivered":True}})
    else:
        plan["subgoals"].append({"id":"g1","type":"heuristic","spec":{},"success_criteria":{}})
    return plan

def generate_conservative_variant(plan):
    # Make a conservative variant by relaxing tolerances or splitting a waypoint into smaller steps
    new = copy.deepcopy(plan)
    for sg in new.get("subgoals", []):
        if sg.get("type")=="reach_waypoint":
            # increase tolerance slightly and add intermediate waypoint
            tol = sg["spec"].get("tolerance",0.5)
            sg["spec"]["tolerance"] = min(2.0, tol*1.5)
        if sg.get("type")=="pick_object":
            # no change for pick
            pass
    return new