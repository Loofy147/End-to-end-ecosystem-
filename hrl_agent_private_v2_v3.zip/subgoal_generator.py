def generate(subgoal):
    sg = dict(subgoal)
    if sg.get("type")=="reach_waypoint":
        sg["exec_spec"] = {"waypoint": sg["spec"]["waypoint"], "tolerance": sg["spec"].get("tolerance",0.5)}
    elif sg.get("type")=="solve_quadratic":
        sg["exec_spec"] = {"a": sg["spec"]["a"], "b": sg["spec"]["b"], "c": sg["spec"]["c"]}
    else:
        sg["exec_spec"] = sg.get("spec", {})
    return sg