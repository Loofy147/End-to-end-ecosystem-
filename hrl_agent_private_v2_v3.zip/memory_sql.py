import sqlite3, json, os
from representation import embed, cosine

DB = "memory.sqlite"

def init_db():
    conn = sqlite3.connect(DB)
    c = conn.cursor()
    c.execute('''CREATE TABLE IF NOT EXISTS runs
                 (id TEXT PRIMARY KEY, problem_id TEXT, goal TEXT, timestamp TEXT, run_json TEXT, embedding TEXT)''')
    conn.commit()
    conn.close()

def save_run(record):
    init_db()
    conn = sqlite3.connect(DB)
    c = conn.cursor()
    rid = record.get("id")
    pid = record.get("problem",{}).get("problem_id")
    goal = str(record.get("problem",{}).get("goal_high"))
    ts = record.get("timestamp")
    rjson = json.dumps(record)
    emb = json.dumps(embed({"problem_id":pid,"goal":goal}))
    c.execute("INSERT OR REPLACE INTO runs VALUES (?,?,?,?,?,?)", (rid, pid, goal, ts, rjson, emb))
    conn.commit()
    conn.close()

def search_similar(query_obj, k=5):
    init_db()
    conn = sqlite3.connect(DB)
    c = conn.cursor()
    c.execute("SELECT id, problem_id, goal, timestamp, run_json, embedding FROM runs")
    rows = c.fetchall()
    qemb = embed(query_obj)
    scored = []
    for r in rows:
        rid, pid, goal, ts, rjson, emb_text = r
        try:
            emb = json.loads(emb_text)
        except Exception:
            emb = embed(goal)
        score = cosine(qemb, emb)
        scored.append((score, json.loads(rjson)))
    scored.sort(key=lambda x: -x[0])
    return [r for s,r in scored[:k]]