# memory_faiss.py - wrapper that uses faiss if available, else brute force cosine search
import json, sqlite3, os
from representation import embed, cosine

DB = 'memory.sqlite'

def init_db():
    conn = sqlite3.connect(DB); c = conn.cursor()
    c.execute('''CREATE TABLE IF NOT EXISTS runs (id TEXT PRIMARY KEY, problem_id TEXT, goal TEXT, timestamp TEXT, run_json TEXT, embedding TEXT)''')
    conn.commit(); conn.close()

def save_run(record):
    init_db()
    conn = sqlite3.connect(DB); c = conn.cursor()
    rid = record.get('id')
    pid = record.get('problem',{}).get('problem_id')
    goal = str(record.get('problem',{}).get('goal_high'))
    ts = record.get('timestamp')
    rjson = json.dumps(record)
    emb = json.dumps(embed({'problem_id':pid,'goal':goal}))
    c.execute('INSERT OR REPLACE INTO runs VALUES (?,?,?,?,?,?)', (rid, pid, goal, ts, rjson, emb))
    conn.commit(); conn.close()

def search_similar(query_obj, k=5):
    # try to import faiss
    try:
        import faiss
        return _search_with_faiss(query_obj, k)
    except Exception:
        return _bruteforce_search(query_obj, k)

def _bruteforce_search(query_obj, k=5):
    init_db()
    conn = sqlite3.connect(DB); c = conn.cursor()
    c.execute('SELECT id, problem_id, goal, timestamp, run_json, embedding FROM runs')
    rows = c.fetchall(); conn.close()
    qemb = embed(query_obj)
    scored = []
    for r in rows:
        rid, pid, goal, ts, rjson, emb_text = r
        try:
            emb = json.loads(emb_text)
        except:
            emb = embed(goal)
        score = cosine(qemb, emb)
        scored.append((score, json.loads(rjson)))
    scored.sort(key=lambda x: -x[0])
    return [r for s,r in scored[:k]]

def _search_with_faiss(query_obj, k=5):
    # simple implementation: load all embeddings and index (for demo)
    init_db()
    conn = sqlite3.connect(DB); c = conn.cursor()
    c.execute('SELECT id, run_json, embedding FROM runs')
    rows = c.fetchall(); conn.close()
    if not rows:
        return []
    emb_list = [json.loads(r[2]) for r in rows]
    import numpy as np
    xb = np.array(emb_list).astype('float32')
    d = xb.shape[1]
    index = faiss.IndexFlatIP(d)
    faiss.normalize_L2(xb)
    index.add(xb)
    qemb = np.array([embed(query_obj)]).astype('float32')
    faiss.normalize_L2(qemb)
    D,I = index.search(qemb, k)
    results = []
    for idx in I[0]:
        results.append(json.loads(rows[idx][1]))
    return results