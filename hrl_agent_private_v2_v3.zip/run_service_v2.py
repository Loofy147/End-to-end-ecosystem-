import os, json, time, argparse, uuid
from planner_v2 import generate_plan, generate_conservative_variant
from llm_adapter import plan_from_llm
from subgoal_generator import generate as gen_subgoal
from executor import run_rollout_reach_waypoint, run_rollout_pick_and_deliver, solve_quadratic
from verifier import verify
try:
    from memory_faiss import save_run, search_similar
except Exception:
    from memory_sql import save_run, search_similar

from representation import embed
from datetime import datetime

TASKS_DIR = "tasks"
RUNS_DIR = "runs"
os.makedirs(TASKS_DIR, exist_ok=True)
os.makedirs(RUNS_DIR, exist_ok=True)

def process_task(path, max_retries=2):
    with open(path) as f:
        task = json.load(f)
    # Ask LLM adapter for a plan (local stub by default)
    plan = plan_from_llm(task)
    run_record = {"id": str(uuid.uuid4()), "timestamp": datetime.utcnow().isoformat(), "problem": task, "plan": plan, "subgoals": []}
    stopped_on_failure = False
    for sg in plan["subgoals"]:
        sg_exec = gen_subgoal(sg)
        sg["exec_spec"] = sg_exec.get("exec_spec")
        attempt = 0
        while attempt<=max_retries:
            if sg["type"]=="reach_waypoint":
                res = run_rollout_reach_waypoint(sg["exec_spec"], task.get("meta", {}))
            elif sg["type"] in ("pick_object","deliver"):
                merged = dict(sg["exec_spec"])
                merged.update({"zone": task.get("meta", {}).get("zone")})
                res = run_rollout_pick_and_deliver(merged, task.get("meta", {}))
            elif sg["type"]=="solve_quadratic":
                res = solve_quadratic(sg["exec_spec"]["a"], sg["exec_spec"]["b"], sg["exec_spec"]["c"])
            else:
                res = {"ok": False}
            ver = verify(sg, res)
            run_record["subgoals"].append({"subgoal": sg, "result": res, "verifier": ver, "attempt": attempt})
            if ver["verified"]:
                break
            else:
                # auto-repair: ask planner to make conservative variant and retry
                attempt += 1
                if attempt > max_retries:
                    break
                new_plan = generate_conservative_variant(plan)
                # find matching subgoal by id and replace sg with new version
                for new_sg in new_plan.get("subgoals", []):
                    if new_sg["id"]==sg["id"]:
                        sg = new_sg
                        break
        if not ver["verified"]:
            stopped_on_failure = True
            break
    # save run record
    outpath = os.path.join(RUNS_DIR, f"run_{task.get('task_id','t')}_{int(time.time())}.json")
    with open(outpath, "w") as f:
        json.dump(run_record, f, indent=2)
    save_run(run_record)
    processed_dir = os.path.join(TASKS_DIR, "processed")
    os.makedirs(processed_dir, exist_ok=True)
    os.rename(path, os.path.join(processed_dir, os.path.basename(path)))
    return run_record

def run_once(max_tasks=50):
    tasks = [os.path.join(TASKS_DIR, f) for f in os.listdir(TASKS_DIR) if f.endswith(".json")]
    tasks = [t for t in tasks if not os.path.isdir(t)]
    results = []
    for t in tasks[:max_tasks]:
        results.append(process_task(t))
    return results

if __name__=="__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--once", action="store_true", help="Process tasks once")
    parser.add_argument("--loop", action="store_true", help="Run in loop (CTRL-C to stop)")
    parser.add_argument("--max-tasks", type=int, default=50, help="Max tasks to process in one run (default 50)")
    args = parser.parse_args()
    if args.once:
        res = run_once(max_tasks=args.max_tasks)
        print("Processed tasks:", len(res))
    elif args.loop:
        try:
            while True:
                res = run_once(max_tasks=args.max_tasks)
                if res:
                    print("Processed", len(res), "tasks")
                time.sleep(2)
        except KeyboardInterrupt:
            print("Service stopped")
    else:
        print("Use --once or --loop")