# sign_certificate.py - sign a text with HMAC-SHA256 using secret.key
import hmac, hashlib, json, os, time
def sign_text(text):
    key = open('secret.key','rb').read()
    sig = hmac.new(key, text.encode('utf-8'), hashlib.sha256).hexdigest()
    return sig

def verify_signature(text, sig_hex):
    key = open('secret.key','rb').read()
    return hmac.new(key, text.encode('utf-8'), hashlib.sha256).hexdigest() == sig_hex