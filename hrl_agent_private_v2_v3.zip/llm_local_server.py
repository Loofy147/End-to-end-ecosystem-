from http.server import BaseHTTPRequestHandler, HTTPServer
import json, sys
PORT = 8081

class Handler(BaseHTTPRequestHandler):
    def do_POST(self):
        if self.path != '/generate':
            self.send_response(404); self.end_headers(); return
        length = int(self.headers.get('Content-Length', 0))
        body = self.rfile.read(length).decode('utf-8') if length else ''
        try:
            req = json.loads(body) if body else {}
        except:
            req = {}
        # deterministic stub: echo plan from planner_v2 if task provided, else fixed message
        task = req.get('task')
        if task:
            # import planner to generate plan
            from planner_v2 import generate_plan
            plan = generate_plan(task)
            resp = {'plan': plan, 'source': 'local_server_stub'}
        else:
            resp = {'text': 'no task provided', 'source': 'local_server_stub'}
        resp_b = json.dumps(resp).encode('utf-8')
        self.send_response(200)
        self.send_header('Content-Type','application/json')
        self.send_header('Content-Length', str(len(resp_b)))
        self.end_headers()
        self.wfile.write(resp_b)

if __name__=='__main__':
    server = HTTPServer(('127.0.0.1', PORT), Handler)
    print(f'LLM local server stub running on http://127.0.0.1:{PORT}/generate')
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print('Server stopped')