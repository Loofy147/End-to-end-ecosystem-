from http.server import SimpleHTTPRequestHandler, HTTPServer
import os, json, urllib
RUNS_DIR = "runs"
PORT = 8765

class Handler(SimpleHTTPRequestHandler):
    def do_GET(self):
        if self.path.startswith("/kpi.json"):
            files = [os.path.join(RUNS_DIR, f) for f in os.listdir(RUNS_DIR) if f.endswith(".json")]
            total = 0; success = 0
            for fpath in files:
                try:
                    j = json.load(open(fpath))
                    # count run success heuristically: all subgoals verified
                    rs = j.get("subgoals", [])
                    ok = all([s.get("verifier",{}).get("verified",False) for s in rs])
                    total += 1
                    if ok: success+=1
                except Exception:
                    continue
            kpi = {"total_runs": total, "success_runs": success, "success_rate": (success/total if total else 0.0)}
            self.send_response(200)
            self.send_header("Content-Type","application/json")
            self.end_headers()
            self.wfile.write(json.dumps(kpi).encode('utf-8'))
            return
        else:
            return SimpleHTTPRequestHandler.do_GET(self)

if __name__=="__main__":
    os.chdir(".")
    server = HTTPServer(("127.0.0.1", PORT), Handler)
    print(f"Serving on http://127.0.0.1:{PORT} (CTRL-C to stop)")
    server.serve_forever()