import math, random, time
class GridWorld:
    def __init__(self, start=(0,0), goal=(3,2), obstacles=None):
        self.pos = list(start)
        self.goal = list(goal)
        self.steps = 0
        self.max_steps = 200
        self.obstacles = obstacles or []

    def step_towards(self, waypoint):
        gx, gy = waypoint
        x,y = self.pos
        if x < gx: x+=1
        elif x > gx: x-=1
        if y < gy: y+=1
        elif y > gy: y-=1
        self.pos = [x,y]
        self.steps += 1
        done = (self.pos == self.goal) or (self.steps>=self.max_steps)
        return {"pos": list(self.pos), "done": done}

    def distance_to(self, waypoint):
        return abs(self.pos[0]-waypoint[0]) + abs(self.pos[1]-waypoint[1])

def solve_quadratic(a,b,c):
    disc = b*b - 4*a*c
    if disc < 0:
        return {"roots":[]}
    r1 = (-b + math.sqrt(disc)) / (2*a)
    r2 = (-b - math.sqrt(disc)) / (2*a)
    return {"roots": sorted([r1,r2])}

def run_rollout_reach_waypoint(exec_spec, env_meta):
    env = GridWorld(start=tuple(env_meta.get("start",(0,0))), goal=tuple(env_meta.get("goal",(3,2))))
    waypoint = exec_spec["waypoint"]
    traj = []
    for _ in range(100):
        step = env.step_towards(waypoint)
        traj.append(step["pos"])
        if env.distance_to(waypoint) <= exec_spec.get("tolerance",0.5):
            return {"success":True, "trajectory": traj, "final_pos": env.pos}
    return {"success": False, "trajectory": traj, "final_pos": env.pos}

def run_rollout_pick_and_deliver(exec_spec, env_meta):
    obj = exec_spec.get("object_id")
    objects = env_meta.get("objects", [])
    objpos = None
    for o in objects:
        if o.get("id")==obj:
            objpos = o.get("pos")
    picked = objpos is not None
    zone = exec_spec.get("zone") or env_meta.get("zone")
    delivered = picked and zone is not None
    return {"picked": picked, "delivered": delivered, "objpos": objpos, "zone": zone}