
import { GoogleGenAI, Type } from "@google/genai";
import { EventPayload, SecurityVulnerability } from '../types.ts';

if (!process.env.API_KEY) {
    throw new Error("API_KEY environment variable not set");
}

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

const responseSchema = {
    type: Type.OBJECT,
    properties: {
        decisionLog: {
            type: Type.ARRAY,
            description: "A step-by-step log of the AI's reasoning process, architectural decisions, and impact analysis.",
            items: { type: Type.STRING }
        },
        refactoringSuggestions: {
            type: Type.ARRAY,
            description: "A list of concrete refactoring suggestions derived from the analysis.",
            items: {
                type: Type.OBJECT,
                properties: {
                    originalCode: { type: Type.STRING, description: "The original code snippet that needs refactoring." },
                    suggestedCode: { type: Type.STRING, description: "The refactored code snippet." },
                    explanation: { type: Type.STRING, description: "A detailed explanation of the refactoring." },
                },
                required: ["originalCode", "suggestedCode", "explanation"],
            },
        },
        knowledgeGraph: {
            type: Type.OBJECT,
            description: "Data for a knowledge graph visualization representing the code's architecture.",
            properties: {
                nodes: {
                    type: Type.ARRAY,
                    description: "Nodes for the D3 graph.",
                    items: {
                        type: Type.OBJECT,
                        properties: {
                            id: { type: Type.STRING, description: "Unique ID of the node (e.g., class name or function name)." },
                            group: { type: Type.STRING, description: "Type of the entity (e.g., 'class', 'function', 'module')." },
                            name: { type: Type.STRING, description: "Display name of the node." }
                        },
                        required: ["id", "group", "name"],
                    },
                },
                links: {
                    type: Type.ARRAY,
                    description: "Links between nodes for the D3 graph.",
                    items: {
                        type: Type.OBJECT,
                        properties: {
                            source: { type: Type.STRING, description: "ID of the source node." },
                            target: { type: Type.STRING, description: "ID of the target node." },
                            value: { type: Type.NUMBER, description: "Strength of the link." },
                        },
                        required: ["source", "target", "value"],
                    },
                },
            },
             required: ["nodes", "links"],
        },
        architecturalMetrics: {
            type: Type.ARRAY,
            description: "Advanced architectural metrics for each function.",
            items: {
                type: Type.OBJECT,
                properties: {
                    functionName: { type: Type.STRING, description: "The name of the function being analyzed." },
                    cyclomaticComplexity: { type: Type.NUMBER, description: "The cyclomatic complexity score." },
                    cognitiveComplexity: { type: Type.NUMBER, description: "A score representing the cognitive load to understand the function." },
                    maintainabilityIndex: { type: Type.NUMBER, description: "A score from 0-100 indicating maintainability." },
                },
                required: ["functionName", "cyclomaticComplexity", "cognitiveComplexity", "maintainabilityIndex"],
            },
        },
    },
    required: ["decisionLog", "refactoringSuggestions", "knowledgeGraph", "architecturalMetrics"],
};

export const analyzeCode = async (code: string): Promise<EventPayload> => {
    const prompt = `
You are an Autonomous Architecture Orchestrator. Your purpose is to perform a deep, multi-faceted analysis of the provided Python codebase based on advanced software engineering principles.

Analyze the following Python code:
\`\`\`python
${code}
\`\`\`

Your response must be a single JSON object that conforms to the provided schema. Follow these steps in your analysis:

1.  **Decision Log**: First, narrate your step-by-step reasoning process. Detail the architectural patterns you observe, the potential issues you identify (e.g., high coupling, low cohesion, breaking changes, performance bottlenecks), and the rationale behind your suggested improvements. This log should be a clear, human-readable explanation of your analysis.

2.  **Architectural Metrics**: For each function, calculate the following metrics:
    *   \`cyclomaticComplexity\`: A measure of the number of linearly independent paths through the code.
    *   \`cognitiveComplexity\`: A measure of how difficult the code is for a human to understand.
    *   \`maintainabilityIndex\`: A score from 0 to 100, where higher is better.

3.  **Knowledge Graph**: Construct a graph of the codebase.
    *   **Nodes**: Identify all key entities: modules, classes, and functions.
    *   **Links**: Identify and represent the relationships between them (e.g., function calls, inheritance, instantiation). The 'value' should represent the strength or importance of the link.

4.  **Refactoring Suggestions**: Based on your analysis, provide concrete, actionable refactoring suggestions. For each suggestion, include the original code snippet, the improved version, and a clear explanation.

Your entire output must be a single, valid JSON object matching the schema.
`;

    try {
        const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: prompt,
            config: {
                responseMimeType: "application/json",
                responseSchema: responseSchema,
                temperature: 0.1,
            }
        });

        const jsonString = response.text.trim();
        const result = JSON.parse(jsonString);

        if (
            !result.decisionLog ||
            !result.refactoringSuggestions ||
            !result.knowledgeGraph ||
            !result.architecturalMetrics
        ) {
            throw new Error("Invalid response structure from API");
        }

        return result as EventPayload;

    } catch (error) {
        console.error("Error analyzing code with Gemini:", error);
        throw new Error("Failed to get analysis from AI. Please check the console for details.");
    }
};

export const architectCode = async (idea: string, existingCode: string): Promise<string> => {
    const prompt = `
You are a world-class Python software architect. Your task is to take an idea from the user and generate a new block of Python code that implements this idea.

The generated code should be designed to be appended to the existing code provided below. Do not repeat the existing code in your output. Only return the new Python code block that fulfills the user's request. Consider the context of the existing code to ensure the new code is compatible and well-integrated.

User's Idea:
${idea}

---
Existing Code:
\`\`\`python
${existingCode}
\`\`\`
---

New Python code to be appended:
`;
    
    try {
        const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: prompt,
            config: {
                temperature: 0.4,
            }
        });
        return response.text.trim();
    } catch (error) {
        console.error("Error generating code with Gemini:", error);
        throw new Error("Failed to generate code from AI. Please check the console for details.");
    }
};

export const generateUnitTests = async (code: string): Promise<string> => {
    const prompt = `
You are an expert Test Engineer specializing in Python. Your task is to write comprehensive unit tests for the provided Python code using the pytest framework.

Your response must be ONLY the Python code for the tests.
- Analyze the provided code to understand its functionality, especially the public functions.
- Create a new pytest test file structure.
- Write clear, effective, and isolated unit tests for each function or method.
- Use mocks if necessary to isolate components.
- Do not include any explanations, comments outside of the code, or markdown formatting.

Python code to test:
\`\`\`python
${code}
\`\`\`

Your pytest code output:
`;

    try {
        const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: prompt,
            config: {
                temperature: 0.3,
            }
        });
        
        let testCode = response.text.trim();
        if (testCode.startsWith('```python')) {
            testCode = testCode.substring(9, testCode.length - 3).trim();
        } else if (testCode.startsWith('```')) {
            testCode = testCode.substring(3, testCode.length - 3).trim();
        }
        return testCode;

    } catch (error) {
        console.error("Error generating unit tests with Gemini:", error);
        throw new Error("Failed to generate unit tests from AI. Please check the console for details.");
    }
};

const securityResponseSchema = {
    type: Type.OBJECT,
    properties: {
        vulnerabilities: {
            type: Type.ARRAY,
            description: "A list of security vulnerabilities found in the code.",
            items: {
                type: Type.OBJECT,
                properties: {
                    cwe: { type: Type.STRING, description: "The CWE ID for the vulnerability, e.g., 'CWE-79'." },
                    name: { type: Type.STRING, description: "The name of the vulnerability." },
                    description: { type: Type.STRING, description: "A detailed description of the vulnerability in context." },
                    severity: {
                        type: Type.STRING,
                        description: "The severity of the vulnerability.",
                        enum: ['Critical', 'High', 'Medium', 'Low', 'Informational']
                    },
                    recommendation: { type: Type.STRING, description: "The recommendation to fix the vulnerability." },
                },
                required: ["cwe", "name", "description", "severity", "recommendation"],
            },
        }
    },
    required: ["vulnerabilities"]
};

export const scanCodeForSecurity = async (code: string): Promise<{ securityVulnerabilities: SecurityVulnerability[] }> => {
    const prompt = `
You are an expert Static Application Security Testing (SAST) engine. Your task is to analyze the provided Python code for security vulnerabilities.

Analyze the following Python code:
\`\`\`python
${code}
\`\`\`

Your response must be a single JSON object that conforms to the provided schema. For each vulnerability you find, provide the following details:
- **cwe**: The Common Weakness Enumeration (CWE) ID (e.g., "CWE-79").
- **name**: A short, descriptive name for the vulnerability (e.g., "Cross-Site Scripting (XSS)").
- **description**: A detailed explanation of the vulnerability in the context of the provided code.
- **severity**: The severity level, which must be one of: 'Critical', 'High', 'Medium', 'Low', 'Informational'.
- **recommendation**: A concrete, actionable recommendation on how to fix the vulnerability in the code.

If no vulnerabilities are found, return a JSON object with an empty "vulnerabilities" array. Your entire output must be a single, valid JSON object matching the schema.
`;

    try {
        const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: prompt,
            config: {
                responseMimeType: "application/json",
                responseSchema: securityResponseSchema,
                temperature: 0.2,
            }
        });
        
        const jsonString = response.text.trim();
        const result = JSON.parse(jsonString);

        if (!result.vulnerabilities) {
             throw new Error("Invalid security response structure from API");
        }

        return { securityVulnerabilities: result.vulnerabilities };

    } catch (error) {
        console.error("Error scanning for security vulnerabilities with Gemini:", error);
        throw new Error("Failed to get security analysis from AI. Please check the console for details.");
    }
};

export const generateDocumentation = async (code: string): Promise<string> => {
    const prompt = `
You are an expert Technical Writer. Your task is to generate comprehensive and clear documentation for the provided Python code in Markdown format.

Analyze the following Python code:
\`\`\`python
${code}
\`\`\`

Your response must be a single Markdown block. Do not wrap it in \`\`\`markdown ... \`\`\`.

The documentation should include:
- A brief, high-level summary of the code's purpose.
- A section for each class, detailing its purpose, attributes, and methods.
- For each function or method, provide a description, its parameters, and what it returns. Mimic standard Python docstring format (e.g., reStructuredText or Google style) within the Markdown.
- Include a "Usage Example" section if you can infer a clear way to use the code.
- Maintain a professional and clear tone.

Your Markdown documentation output:
`;

    try {
        const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: prompt,
            config: {
                temperature: 0.3,
            }
        });
        
        return response.text.trim();

    } catch (error) {
        console.error("Error generating documentation with Gemini:", error);
        throw new Error("Failed to generate documentation from AI. Please check the console for details.");
    }
};
