
import React from 'react';
import { AppIcon } from '../constants.tsx';

const Header: React.FC = () => {
    return (
        <header className="bg-gray-900 border-b border-gray-800 p-4">
            <div className="container mx-auto flex items-center">
                <div className="text-cyan-400">
                    <AppIcon />
                </div>
                <h1 className="text-xl font-bold text-gray-100 ml-3">
                    Autonomous Architecture Orchestrator
                </h1>
            </div>
        </header>
    );
};

export default Header;
