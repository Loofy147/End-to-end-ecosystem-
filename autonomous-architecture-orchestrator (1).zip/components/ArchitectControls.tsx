
import React from 'react';
import { ARCHITECT_PROMPT_EXAMPLE } from '../constants.tsx';

interface ArchitectControlsProps {
  idea: string;
  setIdea: (idea: string) => void;
}

const ArchitectControls: React.FC<ArchitectControlsProps> = ({ idea, setIdea }) => {
  return (
    <div className="bg-gray-950 rounded-lg border border-gray-800 shadow-inner w-full h-full">
      <textarea
        value={idea}
        onChange={(e) => setIdea(e.target.value)}
        className="w-full h-full bg-transparent text-gray-300 font-sans p-3 rounded-md resize-none focus:outline-none"
        placeholder={ARCHITECT_PROMPT_EXAMPLE}
        spellCheck="false"
      />
    </div>
  );
};

export default ArchitectControls;
