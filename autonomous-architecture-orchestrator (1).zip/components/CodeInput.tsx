
import React from 'react';

interface CodeInputProps {
  code: string;
  setCode: (code: string) => void;
}

const CodeInput: React.FC<CodeInputProps> = ({ code, setCode }) => {
  return (
    <div className="p-4 bg-gray-950 rounded-lg border border-gray-800 shadow-inner w-full h-full">
      <textarea
        value={code}
        onChange={(e) => setCode(e.target.value)}
        className="w-full h-full bg-transparent text-gray-300 font-mono resize-none focus:outline-none"
        placeholder="Paste your Python code here..."
        spellCheck="false"
      />
    </div>
  );
};

export default CodeInput;
