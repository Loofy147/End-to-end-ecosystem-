
import React, { useState } from 'react';
import CodeInput from './CodeInput.tsx';
import ArchitectControls from './ArchitectControls.tsx';
import { ArchitectIcon, ARCHITECT_PROMPT_EXAMPLE } from '../constants.tsx';

interface WorkspaceProps {
  code: string;
  setCode: (code: string) => void;
  onAnalyze: () => void;
  onGenerate: (idea: string) => void;
  onGenerateTests: () => void;
  onSecurityScan: () => void;
  onGenerateDocs: () => void;
  isAnalysisLoading: boolean;
  isArchitectLoading: boolean;
  isTestBuilderLoading: boolean;
  isSecurityScannerLoading: boolean;
  isDocWriterLoading: boolean;
}

const Workspace: React.FC<WorkspaceProps> = ({
  code,
  setCode,
  onAnalyze,
  onGenerate,
  onGenerateTests,
  onSecurityScan,
  onGenerateDocs,
  isAnalysisLoading,
  isArchitectLoading,
  isTestBuilderLoading,
  isSecurityScannerLoading,
  isDocWriterLoading,
}) => {
  const [architectIdea, setArchitectIdea] = useState('');

  const handleGenerateClick = () => {
    onGenerate(architectIdea || ARCHITECT_PROMPT_EXAMPLE);
    setArchitectIdea('');
  }

  const isLoading = isAnalysisLoading || isArchitectLoading || isTestBuilderLoading || isSecurityScannerLoading || isDocWriterLoading;

  return (
    <div className="bg-gray-900 rounded-lg border border-gray-800 shadow-lg flex flex-col h-full">
      <div className="flex-grow p-4 grid grid-cols-1 lg:grid-cols-2 gap-4">
        <div className="flex flex-col">
            <h2 className="text-lg font-bold mb-2 text-gray-200">Codebase Input</h2>
            <div className="flex-grow h-[300px] lg:h-auto">
                <CodeInput code={code} setCode={setCode} />
            </div>
        </div>
        <div className="flex flex-col">
            <h2 className="text-lg font-bold mb-2 text-gray-200 flex items-center">
                <ArchitectIcon />
                <span className="ml-2">Architect Agent</span>
            </h2>
            <div className="flex-grow h-[300px] lg:h-auto">
                <ArchitectControls 
                    idea={architectIdea}
                    setIdea={setArchitectIdea}
                />
            </div>
        </div>
      </div>
      <div className="p-4 bg-gray-950/50 border-t border-gray-800 flex justify-end items-center flex-wrap gap-4">
        
        <div className="flex items-center space-x-4">
            {isDocWriterLoading && <span className="text-sm text-indigo-400">Doc Writer is working...</span>}
            <button
              onClick={onGenerateDocs}
              disabled={isLoading}
              className="bg-indigo-600 hover:bg-indigo-700 disabled:bg-gray-600 disabled:cursor-not-allowed text-white font-bold py-2 px-4 rounded-lg shadow-lg transition-all duration-200 ease-in-out transform hover:scale-105 disabled:scale-100 flex items-center"
            >
              Generate Docs
            </button>
        </div>
        
        <div className="flex items-center space-x-4">
            {isSecurityScannerLoading && <span className="text-sm text-yellow-400">Scanner is working...</span>}
            <button
              onClick={onSecurityScan}
              disabled={isLoading}
              className="bg-yellow-600 hover:bg-yellow-700 disabled:bg-gray-600 disabled:cursor-not-allowed text-white font-bold py-2 px-4 rounded-lg shadow-lg transition-all duration-200 ease-in-out transform hover:scale-105 disabled:scale-100 flex items-center"
            >
              Scan Security
            </button>
        </div>

        <div className="flex items-center space-x-4">
          {isTestBuilderLoading && <span className="text-sm text-blue-400">Test Builder is working...</span>}
          <button
            onClick={onGenerateTests}
            disabled={isLoading}
            className="bg-blue-600 hover:bg-blue-700 disabled:bg-gray-600 disabled:cursor-not-allowed text-white font-bold py-2 px-4 rounded-lg shadow-lg transition-all duration-200 ease-in-out transform hover:scale-105 disabled:scale-100 flex items-center"
          >
            Generate Tests
          </button>
        </div>

        <div className="flex items-center space-x-4">
         {isArchitectLoading && <span className="text-sm text-purple-400">Architect is thinking...</span>}
         <button
          onClick={handleGenerateClick}
          disabled={isLoading}
          className="bg-purple-600 hover:bg-purple-700 disabled:bg-gray-600 disabled:cursor-not-allowed text-white font-bold py-2 px-4 rounded-lg shadow-lg transition-all duration-200 ease-in-out transform hover:scale-105 disabled:scale-100 flex items-center"
        >
          Generate Code
        </button>
        </div>

        <div className="flex items-center space-x-4">
            {isAnalysisLoading && <span className="text-sm text-cyan-400">Orchestrator is analyzing...</span>}
            <button
              onClick={onAnalyze}
              disabled={isLoading}
              className="bg-cyan-500 hover:bg-cyan-600 disabled:bg-gray-600 disabled:cursor-not-allowed text-white font-bold py-2 px-6 rounded-lg shadow-lg transition-all duration-200 ease-in-out transform hover:scale-105 disabled:scale-100 flex items-center"
            >
              Orchestrate Analysis
            </button>
        </div>
      </div>
    </div>
  );
};

export default Workspace;