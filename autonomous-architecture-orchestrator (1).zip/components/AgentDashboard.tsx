
import React from 'react';
import { Agent } from '../types.ts';
import { AgentIcon } from '../constants.tsx';

interface AgentDashboardProps {
  agents: Agent[];
}

const AgentStatusIndicator: React.FC<{ status: 'Idle' | 'Processing' }> = ({ status }) => {
  const colorClass = status === 'Idle' ? 'bg-green-500' : 'bg-yellow-500 animate-pulse';
  return <span className={`w-3 h-3 rounded-full ${colorClass}`}></span>;
};

const AgentDashboard: React.FC<AgentDashboardProps> = ({ agents }) => {
  return (
    <div className="bg-gray-900 rounded-lg border border-gray-800 p-4">
      <h3 className="flex items-center font-bold text-gray-200 mb-3">
        <AgentIcon />
        <span className="ml-2">Agent Status</span>
      </h3>
      <div className="space-y-3">
        {agents.map(agent => (
          <div key={agent.name} className="flex justify-between items-center text-sm">
            <span className="text-gray-400">{agent.name}</span>
            <div className="flex items-center space-x-2">
              <span className="text-gray-300">{agent.status}</span>
              <AgentStatusIndicator status={agent.status} />
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default AgentDashboard;
