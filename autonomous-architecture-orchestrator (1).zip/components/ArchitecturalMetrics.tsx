
import React from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { ArchitecturalMetric } from '../types.ts';

interface ArchitecturalMetricsProps {
  data: ArchitecturalMetric[];
}

const CustomTooltip: React.FC<any> = ({ active, payload, label }) => {
    if (active && payload && payload.length) {
      return (
        <div className="bg-gray-800 p-3 border border-gray-700 rounded-md shadow-lg text-sm">
          <p className="font-bold text-gray-200 mb-2">{`${label}`}</p>
          <p className="text-cyan-400">{`Cyclomatic Complexity: ${payload[0].value}`}</p>
          <p className="text-purple-400">{`Cognitive Complexity: ${payload[1].value}`}</p>
          <p className="text-green-400">{`Maintainability Index: ${payload[2].value}`}</p>
        </div>
      );
    }
  
    return null;
  };

const ArchitecturalMetrics: React.FC<ArchitecturalMetricsProps> = ({ data }) => {
  if (!data || data.length === 0) {
    return <div className="p-6 text-gray-500">No architectural metrics data available.</div>;
  }

  return (
    <div style={{ width: '100%', height: 400 }} className="p-4">
      <ResponsiveContainer>
        <BarChart
          data={data}
          margin={{
            top: 20,
            right: 30,
            left: 20,
            bottom: 5,
          }}
          barSize={40}
        >
          <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
          <XAxis dataKey="functionName" stroke="#9ca3af" tick={{ fontSize: 12 }} />
          <YAxis yAxisId="left" orientation="left" stroke="#9ca3af" />
          <YAxis yAxisId="right" orientation="right" stroke="#4ade80" domain={[0, 100]} />
          <Tooltip content={<CustomTooltip />} cursor={{fill: 'rgba(107, 114, 128, 0.1)'}}/>
          <Legend wrapperStyle={{paddingTop: '20px'}} />
          <Bar yAxisId="left" dataKey="cyclomaticComplexity" stackId="complexity" fill="#22d3ee" name="Cyclomatic Complexity" />
          <Bar yAxisId="left" dataKey="cognitiveComplexity" stackId="complexity" fill="#a855f7" name="Cognitive Complexity" />
          <Bar yAxisId="right" dataKey="maintainabilityIndex" fill="#4ade80" name="Maintainability Index" />
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
};

export default ArchitecturalMetrics;
