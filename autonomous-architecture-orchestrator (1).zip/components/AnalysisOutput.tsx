
import React, { useState, useEffect } from 'react';
import RefactoringSuggestions from './RefactoringSuggestions.tsx';
import KnowledgeGraph from './KnowledgeGraph.tsx';
import ArchitecturalMetrics from './ArchitecturalMetrics.tsx';
import DecisionLog from './DecisionLog.tsx';
import SecurityReport from './SecurityReport.tsx';
import LoadingSpinner from './LoadingSpinner.tsx';
import { EventPayload, EventStatus } from '../types.ts';
import { CodeIcon, GraphIcon, MetricsIcon, LogIcon, TestIcon, CopyIcon, SecurityIcon, DocIcon } from '../constants.tsx';

interface AnalysisOutputProps {
  result: EventPayload | null;
  status: EventStatus;
  error?: string;
  onIntegrate: (originalCode: string, suggestedCode: string) => void;
}

type Tab = 'decisionLog' | 'refactor' | 'graph' | 'metrics' | 'unitTests' | 'security' | 'documentation';

const AnalysisOutput: React.FC<AnalysisOutputProps> = ({ result, status, error, onIntegrate }) => {
  const [activeTab, setActiveTab] = useState<Tab>('decisionLog');
  const [isCopied, setIsCopied] = useState(false);

  useEffect(() => {
    // When a new result comes in, try to set a sensible default tab
    if (result) {
        if (result.decisionLog?.length) setActiveTab('decisionLog');
        else if (result.documentation) setActiveTab('documentation');
        else if (result.securityVulnerabilities?.length) setActiveTab('security');
        else if (result.unitTests) setActiveTab('unitTests');
        else if (result.refactoringSuggestions?.length) setActiveTab('refactor');
        else if (result.knowledgeGraph?.nodes?.length) setActiveTab('graph');
        else if (result.architecturalMetrics?.length) setActiveTab('metrics');
    }
  }, [result]);

  const handleCopy = (code: string) => {
    if (navigator.clipboard) {
        navigator.clipboard.writeText(code).then(() => {
            setIsCopied(true);
            setTimeout(() => setIsCopied(false), 2000);
        });
    }
  };

  if (status === 'processing') {
      return (
        <div className="flex-grow container mx-auto p-8 bg-gray-900 rounded-lg border border-gray-800 text-center flex flex-col items-center justify-center min-h-[400px]">
            <LoadingSpinner />
            <p className="mt-4 text-gray-400">Orchestrator is processing the request...</p>
        </div>
      )
  }

  if (status === 'failed') {
      return (
        <div className="flex-grow container mx-auto p-8 bg-red-900/20 rounded-lg border border-red-800 text-center flex flex-col items-center justify-center min-h-[400px]">
            <h2 className="text-xl font-bold text-red-400">Analysis Failed</h2>
            <p className="mt-4 text-red-300">{error || 'An unknown error occurred.'}</p>
        </div>
      )
  }
  
  if (!result) {
    return null;
  }


  const renderTabContent = () => {
    switch (activeTab) {
      case 'decisionLog':
        return <DecisionLog logEntries={result.decisionLog || []} />;
      case 'refactor':
        return <RefactoringSuggestions suggestions={result.refactoringSuggestions || []} onIntegrate={onIntegrate} />;
      case 'graph':
        return <KnowledgeGraph data={result.knowledgeGraph || { nodes: [], links: [] }} />;
      case 'metrics':
        return <ArchitecturalMetrics data={result.architecturalMetrics || []} />;
      case 'security':
        return <SecurityReport vulnerabilities={result.securityVulnerabilities || []} />;
      case 'documentation':
        if (!result.documentation) return null;
        return (
             <div className="p-4">
                <div className="flex justify-end mb-2">
                    <button
                        onClick={() => handleCopy(result.documentation!)}
                        className="flex items-center text-xs bg-gray-700 hover:bg-gray-600 text-gray-200 px-2 py-1 rounded-md transition-all duration-200"
                        title="Copy generated documentation"
                    >
                        <CopyIcon />
                        <span>{isCopied ? 'Copied!' : 'Copy'}</span>
                    </button>
                </div>
                <div className="prose prose-invert prose-sm max-w-none bg-gray-950 rounded-md p-6 border border-gray-800">
                    <pre className="whitespace-pre-wrap font-sans">
                        {result.documentation.trim()}
                    </pre>
                </div>
            </div>
        );
      case 'unitTests':
        if (!result.unitTests) return null;
        return (
            <div className="p-4">
                <div className="flex justify-end mb-2">
                    <button
                        onClick={() => handleCopy(result.unitTests!)}
                        className="flex items-center text-xs bg-gray-700 hover:bg-gray-600 text-gray-200 px-2 py-1 rounded-md transition-all duration-200"
                        title="Copy generated test code"
                    >
                        <CopyIcon />
                        <span>{isCopied ? 'Copied!' : 'Copy'}</span>
                    </button>
                </div>
                <pre className="bg-gray-950 rounded-md p-4 overflow-x-auto text-sm border border-gray-800">
                    <code className={`language-python text-gray-300`}>
                        {result.unitTests.trim()}
                    </code>
                </pre>
            </div>
        );
      default:
        return null;
    }
  };

  const TabButton: React.FC<{tabName: Tab, icon: React.ReactNode, label: string, disabled?: boolean}> = ({tabName, icon, label, disabled = false}) => (
    <button
        onClick={() => setActiveTab(tabName)}
        disabled={disabled}
        className={`flex items-center space-x-2 py-2 px-4 text-sm font-medium rounded-t-lg transition-colors duration-200 disabled:opacity-50 disabled:cursor-not-allowed ${
            activeTab === tabName
            ? 'border-b-2 border-cyan-400 text-cyan-400 bg-gray-900'
            : 'text-gray-400 hover:bg-gray-800/50 hover:text-gray-200'
        }`}
        >
        {icon}
        <span>{label}</span>
    </button>
  );

  return (
    <div className="flex-grow bg-gray-900 rounded-lg border border-gray-800 shadow-2xl flex flex-col">
      <div className="border-b border-gray-800">
        <nav className="flex space-x-2 px-4 flex-wrap">
           <TabButton tabName="decisionLog" icon={<LogIcon />} label="Decision Log" disabled={!result.decisionLog || result.decisionLog.length === 0} />
           <TabButton tabName="documentation" icon={<DocIcon />} label="Documentation" disabled={!result.documentation} />
           <TabButton tabName="security" icon={<SecurityIcon />} label="Security" disabled={!result.securityVulnerabilities || result.securityVulnerabilities.length === 0} />
           <TabButton tabName="refactor" icon={<CodeIcon />} label="Refactoring" disabled={!result.refactoringSuggestions || result.refactoringSuggestions.length === 0} />
           <TabButton tabName="graph" icon={<GraphIcon />} label="Knowledge Graph" disabled={!result.knowledgeGraph || !result.knowledgeGraph.nodes?.length} />
           <TabButton tabName="metrics" icon={<MetricsIcon />} label="Architectural Metrics" disabled={!result.architecturalMetrics || result.architecturalMetrics.length === 0} />
           <TabButton tabName="unitTests" icon={<TestIcon />} label="Unit Tests" disabled={!result.unitTests} />
        </nav>
      </div>
      <div className="flex-grow p-2 overflow-y-auto">
        {renderTabContent()}
      </div>
    </div>
  );
};

export default AnalysisOutput;