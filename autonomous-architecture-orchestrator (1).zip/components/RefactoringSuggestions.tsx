
import React, { useState } from 'react';
import { CopyIcon, IntegrateIcon } from '../constants.tsx';
import { RefactoringSuggestion } from '../types.ts';

interface RefactoringSuggestionsProps {
  suggestions: RefactoringSuggestion[];
  onIntegrate: (originalCode: string, suggestedCode: string) => void;
}

const CodeBlock: React.FC<{ code: string; language: string }> = ({ code, language }) => (
    <pre className="bg-gray-900 rounded-md p-4 overflow-x-auto text-sm">
        <code className={`language-${language} text-gray-300`}>
            {code.trim()}
        </code>
    </pre>
);

const RefactoringSuggestions: React.FC<RefactoringSuggestionsProps> = ({ suggestions, onIntegrate }) => {
  const [copiedIndex, setCopiedIndex] = useState<number | null>(null);

  const handleCopy = (code: string, index: number) => {
    if (navigator.clipboard) {
        navigator.clipboard.writeText(code).then(() => {
            setCopiedIndex(index);
            setTimeout(() => setCopiedIndex(null), 2000);
        });
    }
  };

  if (!suggestions || suggestions.length === 0) {
    return <div className="p-6 text-gray-500">No refactoring suggestions available.</div>;
  }

  return (
    <div className="space-y-8 p-4">
      {suggestions.map((suggestion, index) => (
        <div key={index} className="bg-gray-900 border border-gray-800 rounded-lg overflow-hidden shadow-md">
          <div className="p-4 bg-gray-800/50">
            <h3 className="font-bold text-lg text-cyan-400">Suggestion {index + 1}</h3>
            <p className="mt-2 text-gray-400">{suggestion.explanation}</p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 p-4">
            <div>
              <h4 className="font-semibold mb-2 text-red-400">Original Code</h4>
              <CodeBlock code={suggestion.originalCode} language="python" />
            </div>
            <div>
              <div className="flex justify-between items-center mb-2">
                <h4 className="font-semibold text-green-400">Suggested Code</h4>
                <div className="flex items-center space-x-2">
                  <button
                    onClick={() => onIntegrate(suggestion.originalCode, suggestion.suggestedCode)}
                    className="flex items-center text-xs bg-cyan-600/50 hover:bg-cyan-600 text-cyan-100 px-2 py-1 rounded-md transition-all duration-200"
                    title="Integrate this change into the code editor"
                  >
                    <IntegrateIcon />
                    <span>Integrate</span>
                  </button>
                  <button
                    onClick={() => handleCopy(suggestion.suggestedCode, index)}
                    className="flex items-center text-xs bg-gray-700 hover:bg-gray-600 text-gray-200 px-2 py-1 rounded-md transition-all duration-200"
                    title="Copy suggested code"
                  >
                    <CopyIcon />
                    <span>{copiedIndex === index ? 'Copied!' : 'Copy'}</span>
                  </button>
                </div>
              </div>
              <CodeBlock code={suggestion.suggestedCode} language="python" />
            </div>
          </div>
        </div>
      ))}
    </div>
  );
};

export default RefactoringSuggestions;
