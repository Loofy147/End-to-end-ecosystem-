
import React, { useEffect, useRef } from 'react';
import * as d3 from 'd3';
import { KnowledgeGraphData, D3Node, D3Link } from '../types.ts';

interface KnowledgeGraphProps {
  data: KnowledgeGraphData;
}

const KnowledgeGraph: React.FC<KnowledgeGraphProps> = ({ data }) => {
  const ref = useRef<SVGSVGElement>(null);

  useEffect(() => {
    if (!data || !ref.current || !data.nodes || data.nodes.length === 0) return;

    const width = ref.current.parentElement?.clientWidth || 800;
    const height = 500;
    const color = d3.scaleOrdinal(d3.schemeCategory10);

    const links: D3Link[] = data.links.map(d => ({...d}));
    const nodes: D3Node[] = data.nodes.map(d => ({...d}));
    
    d3.select(ref.current).selectAll("*").remove();

    const svg = d3.select(ref.current)
        .attr('width', width)
        .attr('height', height)
        .attr('viewBox', [-width / 2, -height / 2, width, height]);

    const simulation = d3.forceSimulation(nodes)
        .force("link", d3.forceLink(links).id((d: any) => d.id).distance(100))
        .force("charge", d3.forceManyBody().strength(-300))
        .force("center", d3.forceCenter(0, 0));

    const link = svg.append("g")
        .attr("stroke", "#999")
        .attr("stroke-opacity", 0.6)
      .selectAll("line")
      .data(links)
      .join("line")
        .attr("stroke-width", d => Math.sqrt(d.value));

    const node = svg.append("g")
        .attr("stroke", "#fff")
        .attr("stroke-width", 1.5)
      .selectAll("g")
      .data(nodes)
      .join("g");
      
    const circles = node.append("circle")
        .attr("r", 10)
        .attr("fill", d => color(d.group));
    
    const labels = node.append("text")
        .text(d => d.name)
        .attr('x', 12)
        .attr('y', 4)
        .style('fill', '#e5e7eb')
        .style('font-size', '12px');

    node.append("title")
        .text(d => `${d.group}: ${d.name}`);

    const drag = (simulation: any) => {
      function dragstarted(event: any, d: D3Node) {
        if (!event.active) simulation.alphaTarget(0.3).restart();
        d.fx = d.x;
        d.fy = d.y;
      }
      
      function dragged(event: any, d: D3Node) {
        d.fx = event.x;
        d.fy = event.y;
      }
      
      function dragended(event: any, d: D3Node) {
        if (!event.active) simulation.alphaTarget(0);
        d.fx = null;
        d.fy = null;
      }
      
      return d3.drag()
          .on("start", dragstarted)
          .on("drag", dragged)
          .on("end", dragended);
    }
    
    node.call(drag(simulation));

    simulation.on("tick", () => {
      link
          .attr("x1", (d: any) => d.source.x)
          .attr("y1", (d: any) => d.source.y)
          .attr("x2", (d: any) => d.target.x)
          .attr("y2", (d: any) => d.target.y);

      node
          .attr("transform", (d: any) => `translate(${d.x},${d.y})`);
    });

  }, [data]);

  if (!data || !data.nodes || data.nodes.length === 0) {
    return <div className="p-6 text-gray-500">No knowledge graph data available to display.</div>;
  }

  return (
    <div className="p-4 w-full h-[500px]">
      <svg ref={ref}></svg>
    </div>
  );
};

export default KnowledgeGraph;
