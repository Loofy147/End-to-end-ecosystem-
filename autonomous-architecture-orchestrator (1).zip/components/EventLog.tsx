
import React from 'react';
import { ArchitectureEvent, EventStatus } from '../types.ts';
import { HistoryIcon } from '../constants.tsx';

interface EventLogProps {
  events: ArchitectureEvent[];
  selectedEventId: string | null;
  onSelectEvent: (eventId: string) => void;
}

const EventStatusBadge: React.FC<{ status: EventStatus }> = ({ status }) => {
    const baseClasses = "px-2 py-0.5 text-xs font-semibold rounded-full";
    const statusClasses = {
        [EventStatus.COMPLETED]: "bg-green-800 text-green-200",
        [EventStatus.PROCESSING]: "bg-yellow-800 text-yellow-200 animate-pulse",
        [EventStatus.FAILED]: "bg-red-800 text-red-200",
        [EventStatus.PENDING]: "bg-gray-700 text-gray-300",
    };
    return <span className={`${baseClasses} ${statusClasses[status]}`}>{status}</span>;
}

const EventLog: React.FC<EventLogProps> = ({ events, selectedEventId, onSelectEvent }) => {
  return (
    <div className="bg-gray-900 rounded-lg border border-gray-800 p-4 flex flex-col flex-grow">
      <h3 className="flex items-center font-bold text-gray-200 mb-3">
        <HistoryIcon />
        <span className="ml-2">Event Log</span>
      </h3>
      <div className="flex-grow overflow-y-auto pr-2 -mr-2">
        {events.length === 0 ? (
            <p className="text-sm text-gray-500 text-center py-4">No events yet.</p>
        ) : (
            <div className="space-y-2">
            {events.map(event => (
                <button
                key={event.id}
                onClick={() => onSelectEvent(event.id)}
                className={`w-full text-left p-2.5 rounded-md transition-colors duration-150 ${
                    selectedEventId === event.id ? 'bg-cyan-900/50' : 'bg-gray-800/50 hover:bg-gray-800'
                }`}
                >
                <div className="flex justify-between items-center">
                    <span className="font-semibold text-sm text-gray-300">{event.type}</span>
                    <EventStatusBadge status={event.status} />
                </div>
                <p className="text-xs text-gray-500 mt-1">{new Date(event.timestamp).toLocaleTimeString()}</p>
                </button>
            ))}
            </div>
        )}
      </div>
    </div>
  );
};

export default EventLog;
