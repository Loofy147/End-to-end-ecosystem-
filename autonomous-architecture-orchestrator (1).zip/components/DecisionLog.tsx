
import React from 'react';

interface DecisionLogProps {
  logEntries: string[];
}

const DecisionLog: React.FC<DecisionLogProps> = ({ logEntries }) => {
  if (!logEntries || logEntries.length === 0) {
    return <div className="p-6 text-gray-500">No decision log available for this analysis.</div>;
  }

  return (
    <div className="p-6 font-mono text-sm text-gray-300">
      <div className="space-y-4">
        {logEntries.map((entry, index) => (
          <div key={index} className="flex items-start">
            <div className="flex-shrink-0 h-5 w-5 rounded-full bg-cyan-900/50 ring-1 ring-cyan-700 flex items-center justify-center mr-4 mt-1">
                <span className="text-xs text-cyan-300 font-bold">{index + 1}</span>
            </div>
            <p className="leading-relaxed">{entry}</p>
          </div>
        ))}
      </div>
    </div>
  );
};

export default DecisionLog;
