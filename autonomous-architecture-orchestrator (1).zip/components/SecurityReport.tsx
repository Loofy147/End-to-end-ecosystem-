
import React from 'react';
import { SecurityVulnerability } from '../types.ts';

interface SecurityReportProps {
  vulnerabilities: SecurityVulnerability[];
}

const SeverityBadge: React.FC<{ severity: SecurityVulnerability['severity'] }> = ({ severity }) => {
    const severityClasses = {
        'Critical': 'bg-red-800 text-red-200 ring-red-600',
        'High': 'bg-orange-800 text-orange-200 ring-orange-600',
        'Medium': 'bg-yellow-800 text-yellow-200 ring-yellow-600',
        'Low': 'bg-blue-800 text-blue-200 ring-blue-600',
        'Informational': 'bg-gray-700 text-gray-200 ring-gray-500',
    }
    return (
        <span className={`px-3 py-1 text-xs font-bold rounded-full ring-1 ${severityClasses[severity]}`}>
            {severity}
        </span>
    );
};


const SecurityReport: React.FC<SecurityReportProps> = ({ vulnerabilities }) => {
  if (!vulnerabilities || vulnerabilities.length === 0) {
    return <div className="p-6 text-gray-500">No security vulnerabilities were found.</div>;
  }

  return (
    <div className="space-y-6 p-4">
      {vulnerabilities.map((vuln, index) => (
        <div key={index} className="bg-gray-900 border border-gray-800 rounded-lg overflow-hidden shadow-md">
          <div className="p-4 flex justify-between items-start bg-gray-800/50">
            <div>
                <h3 className="font-bold text-lg text-yellow-400">{vuln.name}</h3>
                <p className="text-sm text-gray-400 font-mono mt-1">{vuln.cwe}</p>
            </div>
            <SeverityBadge severity={vuln.severity} />
          </div>
          <div className="p-4 space-y-4">
            <div>
                <h4 className="font-semibold text-gray-300 mb-2">Description</h4>
                <p className="text-gray-400 text-sm leading-relaxed">{vuln.description}</p>
            </div>
            <div>
                <h4 className="font-semibold text-gray-300 mb-2">Recommendation</h4>
                <pre className="bg-gray-950 rounded-md p-3 text-sm border border-gray-700 overflow-x-auto">
                    <code className="text-green-300">
                        {vuln.recommendation}
                    </code>
                </pre>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
};

export default SecurityReport;
