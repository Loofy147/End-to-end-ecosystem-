
import React from 'react';

export const PYTHON_CODE_EXAMPLE = `
"""
Advanced AI Architecture Design System
====================================

A comprehensive framework for intelligent system orchestration, featuring:
- Multi-layered AI component architecture
- Adaptive learning pipeline orchestration
- Intelligent resource allocation and optimization
- Advanced pattern recognition and system evolution

Core architectural principles:
- Modular AI component composition
- Event-driven intelligent workflows
- Scalable distributed processing
- Continuous learning and adaptation
"""

import asyncio
import logging
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from enum import Enum
from typing import Dict, List, Optional, Any, Callable, Union
from concurrent.futures import ThreadPoolExecutor, ProcessPoolExecutor
import threading
import time
import json
import numpy as np
from collections import defaultdict, deque
import weakref


# ==================== Core Architecture Components ====================

class AIComponentType(Enum):
    """Enumeration of AI component archetypes for system orchestration"""
    NEURAL_PROCESSOR = "neural_processor"
    KNOWLEDGE_ENGINE = "knowledge_engine"
    DECISION_ORCHESTRATOR = "decision_orchestrator"
    LEARNING_OPTIMIZER = "learning_optimizer"
    INFERENCE_ACCELERATOR = "inference_accelerator"
    MEMORY_MANAGER = "memory_manager"
    PATTERN_ANALYZER = "pattern_analyzer"

# A function with high complexity for testing analysis
def complex_function(data_packet, config_flags, user_permissions):
    if 'critical' in config_flags and user_permissions > 4:
        processed_data = []
        for item in data_packet:
            if item['type'] == 'A':
                if item['value'] > 100:
                    processed_data.append(item['value'] * 1.5)
                else:
                    processed_data.append(item['value'] * 1.1)
            elif item['type'] == 'B':
                 if 'extended_processing' in config_flags:
                    nested_val = 0
                    for i in range(item['count']):
                        nested_val += i * item['factor']
                    processed_data.append(nested_val)
                 else:
                    processed_data.append(item['value'])
    else:
        return None
    return processed_data

class NeuralProcessor(ABC):
    """Advanced neural processing component with adaptive architecture"""
    
    def __init__(self, component_id: str):
        self.component_id = component_id
        
    @abstractmethod
    async def process(self, input_data: Any) -> Any:
        """Core processing method for component-specific AI operations"""
        pass
`;

export const ARCHITECT_PROMPT_EXAMPLE = `Create a new class called 'KnowledgeEngine' that inherits from a base 'AIComponent' class. It should have a method to query a knowledge graph and another to perform semantic reasoning.`;

export const AppIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="h-6 w-6">
        <path d="M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5"></path>
    </svg>
);

export const CodeIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="h-5 w-5">
        <path d="M16 18l6-6-6-6M8 6l-6 6 6 6"></path>
    </svg>
);

export const GraphIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="h-5 w-5">
        <path d="M18 6l-4-1-6 4-4-1-2 4 2 2 4-1 6 4 4-1 2-4-2-2z"></path>
        <path d="M10 13l-4-1-6 4 6 4 4-1"></path>
        <path d="M10 13l6 4 6-4-6-4"></path>
    </svg>
);

export const MetricsIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="h-5 w-5">
        <line x1="12" y1="20" x2="12" y2="10"></line>
        <line x1="18" y1="20" x2="18" y2="4"></line>
        <line x1="6" y1="20" x2="6" y2="16"></line>
    </svg>
);

export const LogIcon = () => (
  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="h-5 w-5">
    <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path>
    <polyline points="14 2 14 8 20 8"></polyline>
    <line x1="16" y1="13" x2="8" y2="13"></line>
    <line x1="16" y1="17" x2="8" y2="17"></line>
    <polyline points="10 9 9 9 8 9"></polyline>
  </svg>
);

export const TestIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="h-5 w-5">
        <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"></path>
        <path d="m9 12 2 2 4-4"></path>
    </svg>
);

export const SecurityIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="h-5 w-5">
        <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"></path>
    </svg>
);

export const DocIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="h-5 w-5">
        <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z" />
        <polyline points="14 2 14 8 20 8" />
        <line x1="16" y1="13" x2="8" y2="13" />
        <line x1="16" y1="17" x2="8" y2="17" />
        <line x1="10" y1="9" x2="8" y2="9" />
    </svg>
);


export const CopyIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="h-4 w-4 mr-1.5">
        <rect x="9" y="9" width="13" height="13" rx="2" ry="2"></rect>
        <path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"></path>
    </svg>
);

export const IntegrateIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="h-4 w-4 mr-1.5">
        <polyline points="20 6 9 17 4 12"></polyline>
    </svg>
);

export const ArchitectIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="h-5 w-5">
      <path d="m12 5 2 5 5 2-5 2-2 5-2-5-5-2 5-2 2-5z"></path>
      <path d="M12 5v.01"></path>
      <path d="M5 12v.01"></path>
      <path d="M19 12v.01"></path>
      <path d="M12 19v.01"></path>
    </svg>
);

export const HistoryIcon = () => (
  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="h-5 w-5">
    <path d="M12 20v-6M12 8V2"></path>
    <path d="m5 12-2-2 2-2"></path>
    <path d="m19 12 2-2-2-2"></path>
    <circle cx="12" cy="12" r="8"></circle>
  </svg>
);

export const AgentIcon = () => (
  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="h-5 w-5">
    <path d="M12 8V4H8"></path>
    <rect width="16" height="12" x="4" y="8" rx="2"></rect>
    <path d="M2 14h2"></path>
    <path d="M20 14h2"></path>
    <path d="M15 13v2"></path>
    <path d="M9 13v2"></path>
  </svg>
);