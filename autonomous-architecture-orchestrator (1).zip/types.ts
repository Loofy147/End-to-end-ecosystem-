
export enum ArchitectureEventType {
    CODE_ANALYSIS_REQUESTED = "Code Analysis Requested",
    ARCHITECT_AGENT_REQUESTED = "Architect Agent Requested",
    TEST_GENERATION_REQUESTED = "Test Generation Requested",
    SECURITY_SCAN_REQUESTED = "Security Scan Requested",
    DOCUMENTATION_GENERATION_REQUESTED = "Documentation Generation Requested",
}

export enum EventStatus {
    PENDING = 'pending',
    PROCESSING = 'processing',
    COMPLETED = 'completed',
    FAILED = 'failed',
}

export enum AgentName {
    ORCHESTRATOR = "Orchestrator",
    ARCHITECT = "Architect",
    TEST_BUILDER = "Test Builder",
    SECURITY_SCANNER = "Security Scanner",
    DOC_WRITER = "Doc Writer",
}

export interface Agent {
    name: AgentName;
    status: 'Idle' | 'Processing';
}

export interface ArchitectureEvent {
    id: string;
    type: ArchitectureEventType;
    timestamp: string;
    payload: EventPayload;
    status: EventStatus;
    error?: string;
}

export interface EventPayload {
    code?: string;
    idea?: string;
    refactoringSuggestions?: RefactoringSuggestion[];
    knowledgeGraph?: KnowledgeGraphData;
    architecturalMetrics?: ArchitecturalMetric[];
    decisionLog?: string[];
    unitTests?: string;
    securityVulnerabilities?: SecurityVulnerability[];
    documentation?: string;
}

export interface SecurityVulnerability {
  cwe: string;
  name: string;
  description: string;
  severity: 'Critical' | 'High' | 'Medium' | 'Low' | 'Informational';
  recommendation: string;
}

export interface RefactoringSuggestion {
  originalCode: string;
  suggestedCode: string;
  explanation: string;
}

// Minimal D3 interfaces to avoid full d3 types dependency
export interface D3SimulationNodeDatum {
  index?: number;
  x?: number;
  y?: number;
  vx?: number;
  vy?: number;
  fx?: number | null;
  fy?: number | null;
}

export interface D3Node extends D3SimulationNodeDatum {
  id: string;
  group: string;
  name: string;
}

export interface D3Link {
  source: string | D3Node;
  target: string | D3Node;
  value: number;
}

export interface KnowledgeGraphData {
  nodes: D3Node[];
  links: D3Link[];
}

export interface ArchitecturalMetric {
  functionName: string;
  cyclomaticComplexity: number;
  cognitiveComplexity: number;
  maintainabilityIndex: number;
}