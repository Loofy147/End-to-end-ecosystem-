
async function fetchJSON(url, opts={}){
  const r = await fetch(url, opts);
  if(!r.ok) throw new Error(await r.text());
  return await r.json();
}

async function refreshKPI(){
  const k = await fetchJSON('/api/kpi');
  document.getElementById('kpi-total').textContent = k.total_runs;
  document.getElementById('kpi-success').textContent = k.success_runs;
  document.getElementById('kpi-rate').textContent = (k.success_rate*100).toFixed(2)+'%';
}

async function refreshTasks(){
  const arr = await fetchJSON('/api/tasks');
  const el = document.getElementById('tasks');
  el.innerHTML='';
  arr.forEach(t=>{
    const div = document.createElement('div');
    div.className='task';
    div.innerHTML = `<div>${t.file || ''}</div><div>${t.type || ''}</div><div>${t.goal||''}</div>`;
    el.appendChild(div);
  });
}

async function refreshRuns(){
  const arr = await fetchJSON('/api/runs?limit=100');
  const el = document.getElementById('runs');
  el.innerHTML='';
  let series = [];
  arr.forEach((r, idx)=>{
    const div = document.createElement('div');
    div.className='run '+(r.success ? 'success' : 'fail');
    div.innerHTML = `<div>#${idx+1} — ${r.file}</div><div>${r.success?'✅':'❌'}</div><div>${r.subgoals} subgoals</div>`;
    el.appendChild(div);
    series.push(r.success?1:0);
  });
  drawChart(series.reverse());
}

function drawChart(series){
  const c = document.getElementById('chart');
  const ctx = c.getContext('2d');
  ctx.clearRect(0,0,c.width,c.height);
  const w = c.width, h = c.height;
  // axes
  ctx.strokeStyle = '#2c3344'; ctx.beginPath();
  ctx.moveTo(30, h-30); ctx.lineTo(w-10, h-30); ctx.moveTo(30, 10); ctx.lineTo(30, h-30); ctx.stroke();
  // bars
  const maxBars = Math.min(series.length, 60);
  const data = series.slice(-maxBars);
  const bw = (w-50)/maxBars;
  data.forEach((v,i)=>{
    const x = 30 + i*bw + 2;
    const bh = (h-50) * (v?1:0.1);
    ctx.fillStyle = v? '#22c55e' : '#ef4444';
    ctx.fillRect(x, (h-30)-bh, bw-4, bh);
  });
  // legend
  ctx.fillStyle='#e5e7eb'; ctx.fillText('نجاح/فشل آخر 60 تشغيل', 40, 20);
}

async function loadConfig(){
  try {
    const cfg = await fetchJSON('/api/config');
    document.getElementById('llm-mode').value = (cfg.llm_mode || 'local_stub');
  } catch(e){}
}

async function saveMode(){
  const mode = document.getElementById('llm-mode').value;
  await fetchJSON('/api/config', {method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({llm_mode: mode})});
  await loadConfig();
}

async function processNow(){
  const max = parseInt(document.getElementById('max-tasks').value || '50', 10);
  const res = await fetchJSON('/api/process?max='+max);
  alert('تمت معالجة: '+res.processed+' مهمة');
  await refreshKPI();
  await refreshRuns();
}

async function addTask(){
  const txt = document.getElementById('task-json').value;
  try{
    const j = JSON.parse(txt);
    const res = await fetchJSON('/api/add_task', {method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify(j)});
    document.getElementById('upload-status').textContent = 'أضيفت: '+res.added;
    document.getElementById('task-json').value='';
    await refreshTasks();
  }catch(e){
    document.getElementById('upload-status').textContent = 'خطأ: '+e.message;
  }
}

document.getElementById('btn-save-mode').addEventListener('click', saveMode);
document.getElementById('btn-process').addEventListener('click', processNow);
document.getElementById('btn-add-task').addEventListener('click', addTask);

// initial load
(async function init(){
  await loadConfig();
  await refreshKPI();
  await refreshTasks();
  await refreshRuns();
  setInterval(()=>{ refreshKPI(); refreshRuns(); }, 5000);
})();


// Tabs
const tabs = document.querySelectorAll('.tabs button');
tabs.forEach(btn=>btn.addEventListener('click',()=>{
  tabs.forEach(b=>b.classList.remove('active'));
  document.querySelectorAll('.tab').forEach(s=>s.classList.remove('active'));
  btn.classList.add('active');
  document.getElementById('tab-'+btn.dataset.tab).classList.add('active');
}));

// Filters + run detail
document.getElementById('btn-apply').addEventListener('click', refreshRunsFiltered);
async function refreshRunsFiltered(){
  const flt = document.getElementById('filter').value;
  const q = document.getElementById('search-q').value;
  const data = await fetchJSON('/api/runs?limit=500&filter='+flt+'&q='+encodeURIComponent(q));
  const el = document.getElementById('runs');
  el.innerHTML='';
  data.forEach((r)=>{
    const div = document.createElement('div');
    div.className='run '+(r.success ? 'success' : 'fail');
    div.innerHTML = `<div>${r.file}</div><div>${r.problem_id||''}</div><div>${r.success?'✅':'❌'}</div><button class="view">عرض</button>`;
    div.querySelector('.view').addEventListener('click', async ()=>{
      const j = await fetchJSON('/api/run/'+encodeURIComponent(r.file));
      document.getElementById('run-detail').textContent = JSON.stringify(j, null, 2);
    });
    el.appendChild(div);
  });
}

// Trend series
async function refreshTrend(){
  const k = await fetchJSON('/api/kpi_series?window=20');
  drawTrend(k.series);
}
function drawTrend(series){
  const c = document.getElementById('trend');
  const ctx = c.getContext('2d');
  ctx.clearRect(0,0,c.width,c.height);
  const w=c.width, h=c.height;
  ctx.strokeStyle='#2c3344'; ctx.beginPath();
  ctx.moveTo(30, h-30); ctx.lineTo(w-10, h-30); ctx.moveTo(30, 10); ctx.lineTo(30, h-30); ctx.stroke();
  if(series.length===0) return;
  const maxX = Math.max(1, series.length-1);
  ctx.beginPath();
  series.forEach((v,i)=>{
    const x = 30 + (w-50)*(i/maxX);
    const y = (h-30) - (h-50)*v;
    if(i===0) ctx.moveTo(x,y); else ctx.lineTo(x,y);
  });
  ctx.strokeStyle='#06b6d4'; ctx.stroke();
  ctx.fillStyle='#e5e7eb'; ctx.fillText('معدل النجاح (rolling window)', 40, 20);
}

// Live logs
async function refreshLogs(){
  try{
    const d = await fetchJSON('/api/logs?lines=500');
    document.getElementById('logs').textContent = d.log || '';
  }catch(e){}
}
// Scheduler
document.getElementById('btn-sched-start').addEventListener('click', async ()=>{
  const s = parseInt(document.getElementById('sched-int').value || '30', 10);
  await fetchJSON('/api/scheduler/start?interval='+s);
});
document.getElementById('btn-sched-stop').addEventListener('click', async ()=>{
  await fetchJSON('/api/scheduler/stop');
});

// Batch add
document.getElementById('btn-add-batch').addEventListener('click', async ()=>{
  const t = document.getElementById('task-jsonl').value.trim();
  if(!t) return;
  let payload;
  try{
    const parsed = JSON.parse(t);
    if(Array.isArray(parsed)) payload = parsed;
  }catch(e){}
  if(!payload) payload = {batch: t};
  const res = await fetchJSON('/api/add_task', {method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify(payload)});
  document.getElementById('upload-status').textContent = 'مضاف: '+(res.added_batch ? res.added_batch.length : 1);
  document.getElementById('task-jsonl').value='';
  await refreshTasks();
});

// Config editor
async function loadConfigEditor(){
  try{
    const cfg = await fetchJSON('/api/config');
    document.getElementById('config-json').value = JSON.stringify(cfg, null, 2);
  }catch(e){ document.getElementById('config-json').value = '{}'; }
}
document.getElementById('btn-save-config').addEventListener('click', async ()=>{
  try{
    const txt = document.getElementById('config-json').value;
    const obj = JSON.parse(txt);
    await fetchJSON('/api/config', {method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify(obj)});
    document.getElementById('cfg-status').textContent = 'تم الحفظ';
  }catch(e){
    document.getElementById('cfg-status').textContent = 'خطأ: '+e.message;
  }
});

// Export
document.getElementById('btn-export-runs').addEventListener('click', ()=>{
  window.location.href = '/api/export/runs_zip';
});
document.getElementById('btn-rebuild').addEventListener('click', async ()=>{
  const d = await fetchJSON('/api/export/rebuild');
  document.getElementById('export-status').textContent = 'تقرير: '+d.report_md_exists+' | شهادة PDF: '+d.certificate_pdf_exists;
});

// Boot
(async function boot2(){
  await refreshTrend();
  setInterval(refreshTrend, 8000);
  setInterval(refreshLogs, 3000);
  await loadConfigEditor();
  await refreshRunsFiltered();
})();
