# LLM Adapter: supports 'local_stub' and 'local_server' modes.
import os, json, requests

MODE = os.environ.get('LLM_MODE','local_stub')
SERVER_URL = os.environ.get('LLM_SERVER_URL','http://127.0.0.1:8081/generate')

def plan_from_llm(task):
    if MODE=='local_stub':
        from planner_v2 import generate_plan
        return generate_plan(task)
    elif MODE=='local_server':
        # call local HTTP server (must be running)
        try:
            payload = {'task': task}
            r = requests.post(SERVER_URL, json=payload, timeout=5)
            j = r.json()
            return j.get('plan') or j.get('plan', j)
        except Exception as e:
            # fallback to stub on error
            from planner_v2 import generate_plan
            return generate_plan(task)
    else:
        # unknown mode: fallback stub
        from planner_v2 import generate_plan
        return generate_plan(task)