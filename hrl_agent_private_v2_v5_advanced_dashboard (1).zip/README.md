# Hichem_Private_HRL_v2 - Fully Private Agent Environment (v2)

This upgraded package contains additional features:
- LLM adapter stub (local or external) with default `local_stub` to preserve privacy.
- Auto-repair: planner can generate conservative alternative subgoals when verification fails.
- Expanded eval suite (200 tasks generated programmatically).
- Improved memory similarity search (cosine similarity implemented locally).
- Simple local dashboard (HTTP server serving runs and KPIs) - optional and local-only.
- run_service_v2.py supports `--max-tasks` to limit processing (useful for smoke tests).

Privacy: No external network calls by default when llm_mode is local_stub.

Marketing templates included in `agent_config.json` under `marketing`.

How to run (process up to 50 tasks smoke test):
```
python3 run_service_v2.py --once --max-tasks 50
```

## لوحة التحكم المتقدمة (محلية بالكامل)
- شغّل الخادم:
```bash
python3 dashboard_server.py
```
- افتح المتصفح على: `http://127.0.0.1:8787/`
- من اللوحة يمكنك:
  - عرض مؤشرات KPI مباشرة.
  - عرض آخر التشغيلات مع حالة النجاح/الفشل.
  - إضافة مهام جديدة (JSON).
  - تشغيل معالجة فورية لعدد محدد من المهام.
  - تغيير وضع LLM بين `local_stub` و `local_server` (تأثيره عند التشغيل القادم).
