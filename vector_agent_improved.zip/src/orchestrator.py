import time, threading
import numpy as np
from concurrent.futures import ThreadPoolExecutor
from .database import VectorDatabase
from .vector_engine import VectorEmbeddingEngine, MatrixFactorizationEngine
from .adapter import AIModelAdapter
from .metadata import VectorType
from collections import deque

class VectorMatrixOrchestrator:
    def __init__(self, workers=4):
        self.db = VectorDatabase()
        self.engines = {
            VectorType.EMBEDDING: VectorEmbeddingEngine(),
            VectorType.FEATURE: MatrixFactorizationEngine()
        }
        self.adapters = {}
        self.pool = ThreadPoolExecutor(max_workers=workers)
        self.queue = deque()
        self.metrics = {"processed":0, "served":0, "errors":0}
        self.latencies = deque(maxlen=10)
        self.lock = threading.Lock()

    def register_model(self, name, mtype):
        self.adapters[name] = AIModelAdapter(mtype)

    def submit(self, data, vtype, params=None):
        vid = f"v_{int(time.time()*1000)}"
        self.pool.submit(self._task, vid, data, vtype, params or {})
        return vid

    def _task(self, vid, data, vtype, params):
        start = time.time()
        try:
            out = self.engines[vtype].transform(data, params)
            # store
            from .metadata import VectorMetadata
            meta = VectorMetadata(vid, vtype, out.shape[1], datetime.now())
            self.db.store_vector(out, meta)
            with self.lock:
                self.metrics["processed"] += 1
                self.latencies.append(time.time()-start)
        except Exception:
            with self.lock:
                self.metrics["errors"] += 1

    def serve(self, model, vids, target):
        vecs = []
        for vid in vids:
            vec, _ = self.db.retrieve_vector(vid)
            vecs.append(vec)
        data = self.adapters[model].prepare_data(vecs, target)
        with self.lock:
            self.metrics["served"] += 1
        return data

    def metrics_report(self):
        return {**self.metrics, "avg_latency": sum(self.latencies)/len(self.latencies) if self.latencies else 0}
