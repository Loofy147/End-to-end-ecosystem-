import numpy as np
from dataclasses import dataclass, field
from typing import Tuple, List, Dict, Optional
from enum import Enum
from datetime import datetime

class VectorType(Enum):
    EMBEDDING = "embedding"
    FEATURE = "feature"
    ATTENTION = "attention"
    GRADIENT = "gradient"
    ACTIVATION = "activation"

class MatrixOperation(Enum):
    TRANSPOSE = "transpose"
    INVERSE = "inverse"
    EIGEN = "eigendecomposition"
    SVD = "svd"
    QR = "qr"
    CHOLESKY = "cholesky"

@dataclass
class VectorMetadata:
    vector_id: str
    vector_type: VectorType
    dimensions: int
    creation_timestamp: datetime
    source_model: Optional[str] = None
    transformation_history: List[str] = field(default_factory=list)
    quality_metrics: Dict[str, float] = field(default_factory=dict)
    usage_count: int = 0
    checksum: str = ""

@dataclass
class MatrixProfile:
    matrix_id: str
    shape: Tuple[int, int]
    dtype: str
    sparsity: float
    condition_number: float
    rank: int
    eigenvalues: Optional[np.ndarray] = None
    singular_values: Optional[np.ndarray] = None
    memory_footprint: int = 0
