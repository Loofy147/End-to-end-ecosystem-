import sqlite3, threading, hashlib, pickle, json
from .metadata import VectorMetadata, MatrixProfile
import numpy as np
from datetime import datetime

class VectorDatabase:
    def __init__(self, path="vector_db.sqlite"):
        self.path = path
        self.conn = sqlite3.connect(self.path, check_same_thread=False)
        self.lock = threading.Lock()
        self._init_schema()

    def _init_schema(self):
        with self.lock:
            cur = self.conn.cursor()
            cur.execute("""CREATE TABLE IF NOT EXISTS vectors (
                id TEXT PRIMARY KEY, type TEXT, dims INTEGER,
                data BLOB, meta TEXT, created TIMESTAMP, checksum TEXT)""")
            cur.execute("""CREATE TABLE IF NOT EXISTS matrices (
                id TEXT PRIMARY KEY, profile TEXT, data BLOB)""")
            cur.commit()

    def store_vector(self, vec, meta: VectorMetadata):
        cid = hashlib.md5(vec.tobytes()).hexdigest()
        meta.checksum = cid
        b = pickle.dumps(vec)
        mj = json.dumps(meta.__dict__, default=str)
        with self.lock:
            cur = self.conn.cursor()
            cur.execute("""INSERT OR REPLACE INTO vectors 
                (id, type, dims, data, meta, created, checksum)
                VALUES (?, ?, ?, ?, ?, ?, ?)""", 
                (meta.vector_id, meta.vector_type.value, meta.dimensions,
                 b, mj, meta.creation_timestamp, cid))
            self.conn.commit()
