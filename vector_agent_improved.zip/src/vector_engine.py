import numpy as np
from typing import Dict, Any
from abc import ABC, abstractmethod

class DataTransformationEngine(ABC):
    @abstractmethod
    def transform(self, data: np.ndarray, params: Dict[str, Any]) -> np.ndarray:
        pass

    @abstractmethod
    def inverse_transform(self, data: np.ndarray, params: Dict[str, Any]) -> np.ndarray:
        pass

class VectorEmbeddingEngine(DataTransformationEngine):
    def __init__(self, embedding_dim: int = 512):
        self.embedding_dim = embedding_dim
        self.proj = np.random.randn(embedding_dim, embedding_dim) * 0.1

    def transform(self, data, params):
        reg = params.get('regularization', 1e-6)
        norm_factor = params.get('normalization_factor', 1.0)
        emb = data @ self.proj
        emb = emb / (np.linalg.norm(emb, axis=1, keepdims=True) + reg)
        return emb * norm_factor

    def inverse_transform(self, data, params):
        inv = np.linalg.pinv(self.proj)
        return data @ inv

class MatrixFactorizationEngine(DataTransformationEngine):
    def __init__(self, rank: int = 50):
        self.rank = rank
        self.U = self.S = self.Vt = None

    def transform(self, data, params):
        reg = params.get('regularization', 1e-6)
        mat = data + reg * np.eye(data.shape[0])
        self.U, s, self.Vt = np.linalg.svd(mat, full_matrices=False)
        self.S = s[:self.rank]
        return self.U[:, :self.rank] @ np.diag(self.S)

    def inverse_transform(self, data, params):
        if self.U is None:
            raise RuntimeError("Transform first")
        return self.U[:, :self.rank] @ np.diag(self.S) @ self.Vt
