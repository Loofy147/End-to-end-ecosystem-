import time
from .orchestrator import VectorMatrixOrchestrator
from .metadata import VectorType

def run_demo():
    vm = VectorMatrixOrchestrator()
    vm.register_model("transf", "transformer")
    vid = vm.submit(__import__("numpy").random.randn(100,512), VectorType.EMBEDDING)
    time.sleep(1)
    data = vm.serve("transf", [vid], VectorType.EMBEDDING)
    print("Demo output shape:", data.shape)
    print("Metrics:", vm.metrics_report())

if __name__ == "__main__":
    run_demo()
