import numpy as np
from typing import List
from .metadata import VectorType

class AIModelAdapter:
    def __init__(self, model_type: str):
        self.model_type = model_type
        mapping = {
            "transformer": [VectorType.EMBEDDING, VectorType.ATTENTION],
            "cnn": [VectorType.FEATURE, VectorType.ACTIVATION],
            "rnn": [VectorType.EMBEDDING, VectorType.GRADIENT],
        }
        self.supported = mapping.get(model_type, [])

    def prepare_data(self, vecs: List[np.ndarray], target):
        data = np.vstack(vecs)
        if target == VectorType.EMBEDDING:
            return data / np.linalg.norm(data, axis=1, keepdims=True)
        if target == VectorType.FEATURE:
            return (data - data.mean(0)) / (data.std(0) + 1e-6)
        return data
