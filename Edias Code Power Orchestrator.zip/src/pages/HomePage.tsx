import { useState } from 'react'
import { 
  Code, Terminal, Play, FilePlus, Download, Settings, 
  Share2, Monitor, CheckSquare, Sparkles, History, 
  Layers, Zap, Cpu, LayoutTemplate, GitBranch, Save,
  PanelRight, Undo, Redo, RotateCw, FileCode, Database
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { 
  Select,
  SelectContent,
  SelectGroup,
  SelectItem,
  SelectLabel,
  SelectTrigger,
  SelectValue
} from '@/components/ui/select'
import { Badge } from '@/components/ui/badge'
import { Slider } from '@/components/ui/slider'
import { Switch } from '@/components/ui/switch'
import { useToast } from '@/hooks/use-toast'
import { 
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger
} from '@/components/ui/tooltip'
import { useIsMobile } from '@/hooks/use-mobile'
import { 
  Popover,
  PopoverContent,
  PopoverTrigger
} from '@/components/ui/popover'
import { Label } from '@/components/ui/label'

function HomePage() {
  const { toast } = useToast()
  const isMobile = useIsMobile()
  const [prompt, setPrompt] = useState('')
  const [isGenerating, setIsGenerating] = useState(false)
  const [generatedCode, setGeneratedCode] = useState('')
  const [selectedModel, setSelectedModel] = useState('advanced')
  const [aiContextSize, setAiContextSize] = useState(70)
  const [isAdvancedMode, setIsAdvancedMode] = useState(false)
  const [codeHistory, setCodeHistory] = useState([])
  const [historyIndex, setHistoryIndex] = useState(-1)
  const [selectedLanguage, setSelectedLanguage] = useState('typescript')
  const [selectedFramework, setSelectedFramework] = useState('react')
  
  const handleGenerate = () => {
    if (!prompt.trim()) {
      toast({
        title: "Empty prompt",
        description: "Please enter a description for your code generation",
        variant: "destructive"
      })
      return
    }
    
    setIsGenerating(true)
    // Simulate generation process with more realistic timing based on complexity
    const generationTime = 1500 + Math.random() * 1500
    
    setTimeout(() => {
      // Generate mock code based on the prompt
      const newGeneratedCode = generateMockCode(prompt, selectedLanguage, selectedFramework)
      
      // Add to history
      const newHistory = [...codeHistory]
      if (historyIndex !== codeHistory.length - 1) {
        // If we're in the middle of history, truncate forward history
        newHistory.splice(historyIndex + 1)
      }
      newHistory.push(newGeneratedCode)
      
      setCodeHistory(newHistory)
      setHistoryIndex(newHistory.length - 1)
      setGeneratedCode(newGeneratedCode)
      setIsGenerating(false)
      
      toast({
        title: "Code generated successfully",
        description: `Your ${selectedFramework} code has been generated using the ${modelDetails[selectedModel].name} model`
      })
    }, generationTime)
  }
  
  const handleSaveCode = () => {
    if (!generatedCode) {
      toast({
        title: "No code to save",
        description: "Generate some code first before saving",
        variant: "destructive"
      })
      return
    }
    
    toast({
      title: "Code saved",
      description: "Your code has been saved to your collection"
    })
  }
  
  const handleUndo = () => {
    if (historyIndex > 0) {
      setHistoryIndex(historyIndex - 1)
      setGeneratedCode(codeHistory[historyIndex - 1])
      toast({
        title: "Undo successful",
        description: "Reverted to previous version"
      })
    }
  }
  
  const handleRedo = () => {
    if (historyIndex < codeHistory.length - 1) {
      setHistoryIndex(historyIndex + 1)
      setGeneratedCode(codeHistory[historyIndex + 1])
      toast({
        title: "Redo successful",
        description: "Applied next version"
      })
    }
  }
  
  const handleUseExample = (examplePrompt, exampleLanguage, exampleFramework) => {
    setPrompt(examplePrompt)
    setSelectedLanguage(exampleLanguage || 'typescript')
    setSelectedFramework(exampleFramework || 'react')
    toast({
      title: "Example loaded",
      description: "You can now generate code from this example"
    })
  }
  
  const generateMockCode = (prompt, language, framework) => {
    // This is a simulation of code generation based on the prompt
    if (language === 'typescript' && framework === 'react') {
      return `import React, { useState, useEffect } from 'react';

// Generated based on: "${prompt}"
interface Props {
  data: any[];
  onUpdate: (data: any) => void;
}

export const GeneratedComponent: React.FC<Props> = ({ data, onUpdate }) => {
  const [isLoading, setIsLoading] = useState(false);
  const [items, setItems] = useState(data);

  useEffect(() => {
    // Initialize with provided data
    if (data && data.length > 0) {
      setItems(data);
    }
  }, [data]);

  const handleProcess = async () => {
    setIsLoading(true);
    try {
      // Process logic would go here
      const result = await Promise.resolve([...items, { id: items.length + 1 }]);
      setItems(result);
      onUpdate(result);
    } catch (error) {
      console.error("Error processing data:", error);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="p-4 border rounded-lg shadow-sm">
      <h2 className="text-xl font-bold mb-4">Generated Component</h2>
      <div className="space-y-4">
        {items.map((item) => (
          <div key={item.id} className="p-2 bg-gray-50 rounded">
            Item {item.id}
          </div>
        ))}
      </div>
      <button 
        className="mt-4 px-4 py-2 bg-blue-500 text-white rounded hover:bg-blue-600 disabled:opacity-50"
        onClick={handleProcess}
        disabled={isLoading}
      >
        {isLoading ? 'Processing...' : 'Process Data'}
      </button>
    </div>
  );
};`;
    } else if (language === 'python') {
      return `# Generated based on: "${prompt}"
import pandas as pd
from typing import List, Dict, Any, Optional

class DataProcessor:
    """
    A data processing utility that handles transformation operations.
    """
    
    def __init__(self, config: Optional[Dict[str, Any]] = None):
        self.config = config or {"verbose": False}
        self.data = None
        
    def load_data(self, source: str) -> pd.DataFrame:
        """Load data from the given source path."""
        try:
            if source.endswith('.csv'):
                self.data = pd.read_csv(source)
            elif source.endswith('.json'):
                self.data = pd.read_json(source)
            else:
                raise ValueError(f"Unsupported file format: {source}")
                
            if self.config.get("verbose"):
                print(f"Loaded data with shape: {self.data.shape}")
                
            return self.data
        except Exception as e:
            print(f"Error loading data: {e}")
            return pd.DataFrame()
    
    def process(self) -> pd.DataFrame:
        """Process the loaded data according to requirements."""
        if self.data is None:
            raise ValueError("No data loaded. Call load_data first.")
            
        # Apply transformations based on the prompt
        # This would be customized based on specific requirements
        result = self.data.copy()
        
        # Example operations
        if not result.empty:
            # Handle missing values
            result = result.fillna(result.mean(numeric_only=True))
            
            # Add derived features
            if 'date' in result.columns:
                result['year'] = pd.to_datetime(result['date']).dt.year
                
        return result
        
    def save_output(self, output_path: str) -> bool:
        """Save processed data to the specified path."""
        if self.data is None:
            return False
            
        try:
            if output_path.endswith('.csv'):
                self.data.to_csv(output_path, index=False)
            elif output_path.endswith('.json'):
                self.data.to_json(output_path, orient='records')
            else:
                self.data.to_csv(output_path, index=False)
                
            return True
        except Exception as e:
            print(f"Error saving data: {e}")
            return False
            
# Usage example
if __name__ == "__main__":
    processor = DataProcessor({"verbose": True})
    df = processor.load_data("input_data.csv")
    result = processor.process()
    processor.save_output("processed_data.csv")`;
    } else {
      return `// Generated code would appear here based on your prompt:\n// "${prompt}"\n\n// Please select a language and framework to generate specific code.`;
    }
  };
  
  return (
    <div className="min-h-screen bg-gradient-to-b from-background to-secondary/30">
      {/* Header Section */}
      <header className="container mx-auto py-6">
        <div className="flex flex-col items-center text-center mb-4">
          <div className="flex items-center gap-3">
            <Sparkles className="w-10 h-10 text-primary" />
            <h1 className="text-4xl font-bold tracking-tight">Edias Generator</h1>
          </div>
          <p className="text-xl text-muted-foreground mt-2">
            Powerful Coding Orchestrator with Advanced Generation Capabilities
          </p>
          <div className="flex gap-2 mt-3">
            <Badge variant="outline" className="bg-primary/10 text-primary">v2.0</Badge>
            <Badge variant="outline" className="bg-secondary/20">Pro Edition</Badge>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 pb-12">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Left Column - Code Generation */}
          <div className="lg:col-span-2">
            <Card className="w-full mb-6 shadow-lg border-2 border-primary/10">
              <CardHeader>
                <div className="flex justify-between items-start">
                  <div>
                    <CardTitle className="flex items-center gap-2">
                      <Terminal className="w-5 h-5" />
                      Code Generator
                    </CardTitle>
                    <CardDescription>
                      Describe what you want to build and let our AI generate the code for you
                    </CardDescription>
                  </div>
                  <div className="flex items-center gap-2">
                    <TooltipProvider>
                      <Tooltip>
                        <TooltipTrigger asChild>
                          <Button variant="outline" size="icon" onClick={() => setIsAdvancedMode(!isAdvancedMode)}>
                            <Settings className="h-4 w-4" />
                          </Button>
                        </TooltipTrigger>
                        <TooltipContent>
                          <p>{isAdvancedMode ? 'Hide' : 'Show'} Advanced Settings</p>
                        </TooltipContent>
                      </Tooltip>
                    </TooltipProvider>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <div className="flex flex-col gap-4">
                  <div className="grid gap-2">
                    <Textarea 
                      placeholder="Describe what you want to generate (e.g., 'Create a responsive navbar with dark mode toggle')"
                      value={prompt}
                      onChange={(e) => setPrompt(e.target.value)}
                      className="min-h-[100px] resize-none"
                    />
                  </div>
                  
                  {/* Advanced Settings Panel */}
                  {isAdvancedMode && (
                    <Card className="bg-muted/50">
                      <CardContent className="pt-4">
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-2">
                          <div className="space-y-2">
                            <Label htmlFor="ai-model">AI Model</Label>
                            <Select 
                              value={selectedModel} 
                              onValueChange={setSelectedModel}
                            >
                              <SelectTrigger id="ai-model">
                                <SelectValue placeholder="Select Model" />
                              </SelectTrigger>
                              <SelectContent>
                                <SelectGroup>
                                  <SelectLabel>AI Models</SelectLabel>
                                  {Object.entries(modelDetails).map(([key, model]) => (
                                    <SelectItem key={key} value={key}>
                                      <div className="flex items-center gap-2">
                                        <span>{model.name}</span>
                                        {model.isNew && <Badge variant="outline" className="text-xs bg-green-500/10 text-green-500 border-green-500/20">NEW</Badge>}
                                      </div>
                                    </SelectItem>
                                  ))}
                                </SelectGroup>
                              </SelectContent>
                            </Select>
                            <p className="text-xs text-muted-foreground">{modelDetails[selectedModel].description}</p>
                          </div>
                          
                          <div className="space-y-2">
                            <Label htmlFor="context-size">Context Size: {aiContextSize}%</Label>
                            <Slider 
                              id="context-size"
                              value={[aiContextSize]} 
                              onValueChange={(values) => setAiContextSize(values[0])} 
                              max={100} 
                              step={10}
                            />
                            <p className="text-xs text-muted-foreground">Controls how much context the AI model considers</p>
                          </div>
                        </div>
                        
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          <div className="space-y-2">
                            <Label htmlFor="language">Programming Language</Label>
                            <Select value={selectedLanguage} onValueChange={setSelectedLanguage}>
                              <SelectTrigger id="language">
                                <SelectValue placeholder="Select Language" />
                              </SelectTrigger>
                              <SelectContent>
                                <SelectItem value="typescript">TypeScript</SelectItem>
                                <SelectItem value="javascript">JavaScript</SelectItem>
                                <SelectItem value="python">Python</SelectItem>
                                <SelectItem value="java">Java</SelectItem>
                                <SelectItem value="go">Go</SelectItem>
                              </SelectContent>
                            </Select>
                          </div>
                          
                          <div className="space-y-2">
                            <Label htmlFor="framework">Framework</Label>
                            <Select value={selectedFramework} onValueChange={setSelectedFramework}>
                              <SelectTrigger id="framework">
                                <SelectValue placeholder="Select Framework" />
                              </SelectTrigger>
                              <SelectContent>
                                <SelectItem value="react">React</SelectItem>
                                <SelectItem value="vue">Vue</SelectItem>
                                <SelectItem value="angular">Angular</SelectItem>
                                <SelectItem value="svelte">Svelte</SelectItem>
                                <SelectItem value="nextjs">Next.js</SelectItem>
                              </SelectContent>
                            </Select>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  )}
                  
                  <div className="flex flex-wrap justify-between gap-2">
                    <div className="flex gap-2">
                      <Popover>
                        <PopoverTrigger asChild>
                          <Button variant="outline" size="sm" className="gap-1">
                            <LayoutTemplate className="w-3 h-3" />
                            Templates
                          </Button>
                        </PopoverTrigger>
                        <PopoverContent className="w-80">
                          <div className="space-y-2">
                            <h4 className="font-medium text-sm">Project Templates</h4>
                            <div className="grid grid-cols-2 gap-2">
                              {projectTemplates.map((template, i) => (
                                <Button key={i} variant="ghost" size="sm" className="justify-start h-auto py-2" onClick={() => handleUseExample(template.prompt, template.language, template.framework)}>
                                  <div className="flex flex-col items-start text-left">
                                    <span className="text-xs">{template.name}</span>
                                    <span className="text-xs text-muted-foreground">{template.language}/{template.framework}</span>
                                  </div>
                                </Button>
                              ))}
                            </div>
                          </div>
                        </PopoverContent>
                      </Popover>
                      
                      {generatedCode && (
                        <>
                          <TooltipProvider>
                            <Tooltip>
                              <TooltipTrigger asChild>
                                <Button 
                                  variant="outline" 
                                  size="sm"
                                  disabled={historyIndex <= 0}
                                  onClick={handleUndo}
                                >
                                  <Undo className="w-3 h-3" />
                                </Button>
                              </TooltipTrigger>
                              <TooltipContent>
                                <p>Undo</p>
                              </TooltipContent>
                            </Tooltip>
                          </TooltipProvider>
                          
                          <TooltipProvider>
                            <Tooltip>
                              <TooltipTrigger asChild>
                                <Button 
                                  variant="outline" 
                                  size="sm"
                                  disabled={historyIndex >= codeHistory.length - 1}
                                  onClick={handleRedo}
                                >
                                  <Redo className="w-3 h-3" />
                                </Button>
                              </TooltipTrigger>
                              <TooltipContent>
                                <p>Redo</p>
                              </TooltipContent>
                            </Tooltip>
                          </TooltipProvider>
                        </>
                      )}
                    </div>
                    
                    <div className="flex gap-2">
                      <Button 
                        variant="outline" 
                        className="gap-2"
                        onClick={() => {
                          setPrompt('')
                          setGeneratedCode('')
                          toast({
                            title: "Reset complete",
                            description: "All inputs have been cleared"
                          })
                        }}
                      >
                        <RotateCw className="w-4 h-4" />
                        Reset
                      </Button>
                      
                      <Button 
                        onClick={handleGenerate} 
                        disabled={isGenerating}
                        className="gap-2"
                      >
                        {isGenerating ? (
                          <>
                            <span className="animate-spin">◌</span>
                            Generating...
                          </>
                        ) : (
                          <>
                            <Zap className="w-4 h-4" />
                            Generate Code
                          </>
                        )}
                      </Button>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
            
            {/* Generated Code Output */}
            {generatedCode && (
              <Card className="w-full mb-6 shadow-lg border-2 border-primary/10">
                <CardHeader className="pb-2">
                  <div className="flex justify-between items-center">
                    <CardTitle className="flex items-center gap-2 text-lg">
                      <FileCode className="w-5 h-5" />
                      Generated Code
                    </CardTitle>
                    <div className="flex items-center gap-2">
                      <Button variant="ghost" size="sm" onClick={() => {
                        navigator.clipboard.writeText(generatedCode);
                        toast({ title: "Code copied to clipboard" });
                      }}>
                        <span className="sr-only">Copy code</span>
                        <svg
                          xmlns="http://www.w3.org/2000/svg"
                          width="16"
                          height="16"
                          fill="currentColor"
                          viewBox="0 0 16 16"
                        >
                          <path d="M4 1.5H3a2 2 0 0 0-2 2V14a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V3.5a2 2 0 0 0-2-2h-1v1h1a1 1 0 0 1 1 1V14a1 1 0 0 1-1 1H3a1 1 0 0 1-1-1V3.5a1 1 0 0 1 1-1h1v-1z" />
                          <path d="M9.5 1a.5.5 0 0 1 .5.5v1a.5.5 0 0 1-.5.5h-3a.5.5 0 0 1-.5-.5v-1a.5.5 0 0 1 .5-.5h3zm-3-1A1.5 1.5 0 0 0 5 1.5v1A1.5 1.5 0 0 0 6.5 4h3A1.5 1.5 0 0 0 11 2.5v-1A1.5 1.5 0 0 0 9.5 0h-3z" />
                        </svg>
                      </Button>
                      
                      <Button variant="ghost" size="sm" onClick={handleSaveCode}>
                        <Save className="w-4 h-4" />
                        <span className="sr-only">Save code</span>
                      </Button>
                      
                      <Button variant="ghost" size="sm" onClick={() => {
                        const blob = new Blob([generatedCode], { type: 'text/plain' });
                        const url = URL.createObjectURL(blob);
                        const a = document.createElement('a');
                        a.href = url;
                        a.download = `generated-code.${selectedLanguage === 'typescript' ? 'tsx' : selectedLanguage === 'python' ? 'py' : 'js'}`;
                        document.body.appendChild(a);
                        a.click();
                        document.body.removeChild(a);
                        URL.revokeObjectURL(url);
                        toast({ title: "Code downloaded successfully" });
                      }}>
                        <Download className="w-4 h-4" />
                        <span className="sr-only">Download code</span>
                      </Button>
                    </div>
                  </div>
                  <div className="flex items-center gap-2 mt-1">
                    <Badge variant="outline" className="bg-secondary/10">{selectedLanguage}</Badge>
                    <Badge variant="outline" className="bg-secondary/10">{selectedFramework}</Badge>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="relative">
                    <pre className="p-4 bg-muted rounded-md overflow-x-auto text-sm">
                      <code className="text-sm font-mono whitespace-pre">
                        {generatedCode}
                      </code>
                    </pre>
                  </div>
                </CardContent>
                <CardFooter className="text-xs text-muted-foreground flex justify-between">
                  <div>Generated with {modelDetails[selectedModel].name}</div>
                  <div>Context size: {aiContextSize}%</div>
                </CardFooter>
              </Card>
            )}
          </div>
          
          {/* Right Column - Tabs and Tools */}
          <div className="lg:col-span-1">
            <Card className="w-full shadow-lg border-2 border-primary/10">
              <CardHeader className="pb-3">
                <CardTitle className="text-lg">Generation Hub</CardTitle>
                <CardDescription>
                  Explore examples, features, and tools to supercharge your development
                </CardDescription>
              </CardHeader>
              <CardContent className="px-2">
                <Tabs defaultValue="examples" className="w-full">
                  <TabsList className="grid grid-cols-3 mb-4">
                    <TabsTrigger value="examples">Examples</TabsTrigger>
                    <TabsTrigger value="features">Features</TabsTrigger>
                    <TabsTrigger value="tools">Tools</TabsTrigger>
                  </TabsList>

                  <TabsContent value="examples">
                    <div className="grid grid-cols-1 gap-3 px-2">
                      {examples.map((example, index) => (
                        <Card key={index} className="cursor-pointer hover:border-primary/50 transition-all">
                          <CardHeader className="pb-2 pt-3">
                            <CardTitle className="text-md flex items-center gap-2">
                              <example.icon className="w-4 h-4" />
                              {example.title}
                            </CardTitle>
                          </CardHeader>
                          <CardContent className="pb-0">
                            <p className="text-muted-foreground text-sm">{example.description}</p>
                            <div className="flex gap-1 mt-2">
                              <Badge variant="outline" className="text-xs">{example.language}</Badge>
                              <Badge variant="outline" className="text-xs">{example.framework}</Badge>
                            </div>
                          </CardContent>
                          <CardFooter className="pt-2 pb-3">
                            <Button 
                              variant="ghost" 
                              size="sm" 
                              className="gap-1 text-xs"
                              onClick={() => handleUseExample(example.prompt, example.language, example.framework)}
                            >
                              <FilePlus className="w-3 h-3" />
                              Use this example
                            </Button>
                          </CardFooter>
                        </Card>
                      ))}
                    </div>
                  </TabsContent>

                  <TabsContent value="features">
                    <div className="grid grid-cols-1 gap-3 px-2">
                      {features.map((feature, index) => (
                        <Card key={index}>
                          <CardHeader className="pb-2 pt-3">
                            <CardTitle className="text-md flex items-center gap-2">
                              <feature.icon className="w-5 h-5 text-primary" />
                              {feature.title}
                            </CardTitle>
                          </CardHeader>
                          <CardContent>
                            <p className="text-muted-foreground text-sm">{feature.description}</p>
                          </CardContent>
                          {feature.action && (
                            <CardFooter className="pt-0 pb-3">
                              <Button 
                                variant="outline" 
                                size="sm"
                                className="w-full"
                                onClick={feature.action.onClick}
                              >
                                {feature.action.label}
                              </Button>
                            </CardFooter>
                          )}
                        </Card>
                      ))}
                    </div>
                  </TabsContent>

                  <TabsContent value="tools">
                    <div className="grid grid-cols-1 gap-3 px-2">
                      {tools.map((tool, index) => (
                        <Card key={index} className="hover:shadow-md transition-shadow">
                          <CardHeader className="pb-2 pt-3">
                            <CardTitle className="text-md flex items-center gap-2">
                              <tool.icon className="w-5 h-5 text-primary" />
                              {tool.title}
                            </CardTitle>
                          </CardHeader>
                          <CardContent className="pb-0">
                            <p className="text-muted-foreground text-sm">{tool.description}</p>
                          </CardContent>
                          <CardFooter className="pt-2 pb-3">
                            <Button 
                              variant="outline" 
                              size="sm"
                              className="w-full"
                              onClick={() => {
                                toast({
                                  title: `${tool.title} Opening`,
                                  description: "Preparing tool interface..."
                                })
                              }}
                            >
                              Open Tool
                            </Button>
                          </CardFooter>
                        </Card>
                      ))}
                    </div>
                  </TabsContent>
                </Tabs>
              </CardContent>
            </Card>
            
            {/* Activity Feed Card */}
            <Card className="w-full shadow-lg border-2 border-primary/10 mt-6">
              <CardHeader className="pb-2">
                <CardTitle className="text-lg flex items-center gap-2">
                  <History className="w-5 h-5" />
                  Latest Updates
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {activityFeed.map((item, i) => (
                    <div key={i} className="flex gap-3">
                      <div className={`w-2 h-2 mt-2 rounded-full ${i === 0 ? 'bg-green-500' : 'bg-primary/50'}`}></div>
                      <div className="space-y-1">
                        <p className="text-sm font-medium">{item.title}</p>
                        <p className="text-xs text-muted-foreground">{item.time}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
              <CardFooter className="pt-0">
                <Button variant="ghost" size="sm" className="w-full">View All Updates</Button>
              </CardFooter>
            </Card>
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="border-t bg-background/95 backdrop-blur-sm">
        <div className="container mx-auto py-6 flex flex-col md:flex-row justify-between items-center gap-4">
          <div className="flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-primary" />
            <p className="text-sm text-muted-foreground">
              © 2025 Edias Generator Pro. All rights reserved.
            </p>
          </div>
          <div className="flex flex-wrap justify-center gap-4">
            <Button variant="ghost" size="sm">Documentation</Button>
            <Button variant="ghost" size="sm">API Access</Button>
            <Button variant="ghost" size="sm">Support</Button>
            <Button variant="ghost" size="sm">Privacy Policy</Button>
          </div>
        </div>
      </footer>
    </div>
  )
}

// AI model details
const modelDetails = {
  standard: {
    name: "Standard Model",
    description: "Balanced performance for general code generation tasks",
    isNew: false
  },
  advanced: {
    name: "Advanced Model",
    description: "Enhanced capabilities for complex code generation with better context understanding",
    isNew: false
  },
  expert: {
    name: "Expert Model",
    description: "Superior code quality with architectural awareness and best practices implementation",
    isNew: false
  },
  quantum: {
    name: "Quantum Model",
    description: "Next-generation model with exceptional reasoning and optimization capabilities",
    isNew: true
  }
};

// Enhanced examples with language and framework
const examples = [
  {
    title: "React Dashboard",
    description: "Generate a responsive admin dashboard with multiple data visualization components",
    prompt: "Create a React dashboard with charts for data visualization, a sidebar navigation, and responsive design for all screen sizes",
    icon: Monitor,
    language: "typescript",
    framework: "react"
  },
  {
    title: "API Integration",
    description: "Set up a complete API client with error handling and data transformation",
    prompt: "Generate a TypeScript API client that handles authentication, request/response interceptors, and error handling",
    icon: Share2,
    language: "typescript",
    framework: "react"
  },
  {
    title: "Form Validation",
    description: "Create a multi-step form with comprehensive validation logic",
    prompt: "Build a multi-step registration form with field validation, error messages, and form submission handling",
    icon: CheckSquare,
    language: "typescript",
    framework: "react"
  },
  {
    title: "Python Data Processor",
    description: "Generate a Python module for ETL operations on structured data",
    prompt: "Create a Python data processing class that can load CSV/JSON data, transform it, and save to various formats",
    icon: Database,
    language: "python",
    framework: "standard"
  },
]

const features = [
  {
    title: "AI Code Generation",
    description: "Generate complete, production-ready code based on natural language descriptions",
    icon: Code,
    action: {
      label: "View Documentation",
      onClick: () => {}
    }
  },
  {
    title: "Multiple Languages",
    description: "Support for TypeScript, JavaScript, Python, Java, and many other programming languages",
    icon: Terminal,
  },
  {
    title: "Smart Export Options",
    description: "Download generated code as files, copy to clipboard, or directly create project structures",
    icon: Download,
    action: {
      label: "Configure Export Settings",
      onClick: () => {}
    }
  },
  {
    title: "AI Model Selection",
    description: "Choose from different AI models optimized for various coding styles and complexity levels",
    icon: Cpu,
  },
  {
    title: "Version Control",
    description: "Track changes in your generated code with built-in version control features",
    icon: GitBranch,
    action: {
      label: "View Version History",
      onClick: () => {}
    }
  },
  {
    title: "Real-time Preview",
    description: "See your code come to life with instant previewing capabilities",
    icon: Play,
  },
]

const tools = [
  {
    title: "Code Analyzer",
    description: "Analyze existing code for quality, performance issues, and potential improvements",
    icon: Code
  },
  {
    title: "Architecture Designer",
    description: "Design system architecture diagrams with component relationships",
    icon: Layers
  },
  {
    title: "Performance Profiler",
    description: "Profile and optimize your code for maximum performance",
    icon: Zap
  },
  {
    title: "Documentation Generator",
    description: "Generate comprehensive documentation from your code and comments",
    icon: FileCode
  },
]

// Project templates
const projectTemplates = [
  {
    name: "E-commerce Store",
    language: "typescript",
    framework: "nextjs",
    prompt: "Create a Next.js e-commerce store with product listings, cart functionality, and checkout process"
  },
  {
    name: "Blog Platform",
    language: "typescript",
    framework: "react",
    prompt: "Generate a React blog platform with articles list, detail view, and comments section"
  },
  {
    name: "Admin Dashboard",
    language: "typescript",
    framework: "react",
    prompt: "Build an admin dashboard with user management, data tables, and analytics charts"
  },
  {
    name: "Data Processing API",
    language: "python",
    framework: "standard",
    prompt: "Create a Python API for processing and analyzing large datasets with visualization output"
  },
]

// Activity feed
const activityFeed = [
  {
    title: "Quantum Model Released",
    time: "Just now"
  },
  {
    title: "Python Integration Updated",
    time: "2 hours ago"
  },
  {
    title: "New Project Templates Added",
    time: "1 day ago"
  },
  {
    title: "Performance Improvements",
    time: "3 days ago"
  },
]

export default HomePage