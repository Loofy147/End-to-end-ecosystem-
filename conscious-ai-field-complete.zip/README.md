# Conscious AI Field

A modular Rust system for simulating harmonic-conscious growth patterns with interactive vectors and self-organizing nodes.

## Modules
- `conscious_vector`: Models intention-reception-collapse
- `growth_engine`: Simulates harmonic expansion
- `drunat_nodes`: Polymodal growth tubers
- `philosophy_kernel`: Applies symbolic logic
- `interactive_console`: Command interface for live tuning

## Usage
```bash
cargo run
```

Edit `main.rs` or modules to configure your field conditions.
