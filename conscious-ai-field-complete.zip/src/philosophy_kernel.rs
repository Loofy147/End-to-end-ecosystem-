
use crate::conscious_vector::ConsciousVector;

pub fn interpret_vector(vec: &ConsciousVector) -> &'static str {
    let balance = (vec.intention - vec.reception).abs();
    if balance < 1.0 {
        "Harmonic Equilibrium"
    } else if vec.intention > vec.reception {
        "Forward-biased Intentional Flow"
    } else {
        "Reflective Receptive State"
    }
}
