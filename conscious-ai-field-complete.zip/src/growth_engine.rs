
use crate::conscious_vector::ConsciousVector;

pub fn simulate_growth(vec: &ConsciousVector, time: f64) -> f64 {
    let freq = vec.harmonic_frequency();
    (freq * time).sin().abs() * vec.magnitude()
}
