mod conscious_vector;
mod growth_engine;
mod drunat_nodes;
mod philosophy_kernel;
mod interactive_console;

fn main() {
    interactive_console::start();
}
