
use crate::conscious_vector::ConsciousVector;

pub fn em_field_node(vec: &ConsciousVector) -> f64 {
    (vec.intention + vec.reception).sin() * vec.collapse.cos()
}

pub fn behavior_node(vec: &ConsciousVector) -> f64 {
    vec.intention / (vec.reception + 1.0)
}

pub fn time_predictor_node(vec: &ConsciousVector, t: f64) -> f64 {
    vec.harmonic_frequency() * t
}
