
#[derive(Debug, Clone)]
pub struct ConsciousVector {
    pub intention: f64,
    pub reception: f64,
    pub collapse: f64,
}

impl ConsciousVector {
    pub fn new(intention: f64, reception: f64, collapse: f64) -> Result<Self, &'static str> {
        if intention <= 0.0 || reception <= 0.0 || collapse <= 0.0 {
            return Err("All components must be positive");
        }
        Ok(Self { intention, reception, collapse })
    }

    pub fn magnitude(&self) -> f64 {
        (self.intention.powi(2) + self.reception.powi(2) + self.collapse.powi(2)).sqrt()
    }

    pub fn harmonic_frequency(&self) -> f64 {
        self.magnitude() / (2.0 * std::f64::consts::PI)
    }
}
