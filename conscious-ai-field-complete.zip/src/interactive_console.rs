
use crate::conscious_vector::ConsciousVector;
use crate::growth_engine::simulate_growth;
use crate::drunat_nodes::*;
use crate::philosophy_kernel::interpret_vector;

pub fn start() {
    let vec = ConsciousVector::new(5.0, 11.0, 3.0).unwrap();
    println!("Vector: {:?}", vec);
    println!("Magnitude: {:.4}", vec.magnitude());
    println!("Frequency: {:.4} Hz", vec.harmonic_frequency());

    println!("Growth @ t=5: {:.4}", simulate_growth(&vec, 5.0));
    println!("EM Field: {:.4}", em_field_node(&vec));
    println!("Behavioral Bias: {:.4}", behavior_node(&vec));
    println!("Time Prediction @ t=10: {:.4}", time_predictor_node(&vec, 10.0));
    println!("Philosophical Insight: {}", interpret_vector(&vec));
}
