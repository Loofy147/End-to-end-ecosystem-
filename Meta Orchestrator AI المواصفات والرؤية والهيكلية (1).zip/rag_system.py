from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain.embeddings import OpenAIEmbeddings
from langchain.vectorstores import FAISS
from langchain.schema import Document
import os
import json
from typing import List, Dict, Any, Optional
from knowledge_graph import KnowledgeGraph, Entity
from mcp_dynamic import MCPDynamic
from config import Config

class RAGSystem:
    """
    Retrieval-Augmented Generation System
    Integrates with Knowledge Graph and MCP for intelligent context retrieval
    """
    
    def __init__(self, kg: KnowledgeGraph, mcp: MCPDynamic):
        self.kg = kg
        self.mcp = mcp
        self.embeddings = OpenAIEmbeddings(openai_api_key=Config.OPENAI_API_KEY)
        self.text_splitter = RecursiveCharacterTextSplitter(
            chunk_size=1000,
            chunk_overlap=200,
            length_function=len,
        )
        self.vector_store = None
        self.documents = []
    
    def build_vector_store(self, codebase_path: str):
        """Build vector store from codebase and knowledge graph"""
        print("Building vector store from codebase and knowledge graph...")
        
        documents = []
        
        # 1. Add code files as documents
        for root, dirs, files in os.walk(codebase_path):
            for file in files:
                if file.endswith(('.py', '.js', '.md', '.txt')):
                    file_path = os.path.join(root, file)
                    try:
                        with open(file_path, 'r', encoding='utf-8') as f:
                            content = f.read()
                        
                        # Split content into chunks
                        chunks = self.text_splitter.split_text(content)
                        
                        for i, chunk in enumerate(chunks):
                            doc = Document(
                                page_content=chunk,
                                metadata={
                                    "source": file_path,
                                    "file_type": file.split('.')[-1],
                                    "chunk_index": i,
                                    "source_type": "code_file"
                                }
                            )
                            documents.append(doc)
                    except Exception as e:
                        print(f"Error reading file {file_path}: {e}")
        
        # 2. Add knowledge graph entities as documents
        entities = self._get_all_entities_from_kg()
        for entity in entities:
            entity_content = self._entity_to_text(entity)
            doc = Document(
                page_content=entity_content,
                metadata={
                    "entity_id": entity.id,
                    "entity_type": entity.type,
                    "entity_name": entity.name,
                    "source_type": "knowledge_graph"
                }
            )
            documents.append(doc)
        
        # 3. Add MCP context as documents
        mcp_sources = self.mcp.get_data_sources()
        for source in mcp_sources:
            try:
                context = self.mcp.retrieve_context(f"source_{source.id}")
                if context and context.get("sources"):
                    for source_data in context["sources"]:
                        if "data" in source_data and "content" in source_data["data"]:
                            doc = Document(
                                page_content=source_data["data"]["content"],
                                metadata={
                                    "source_id": source.id,
                                    "source_name": source.name,
                                    "source_type": "mcp_data"
                                }
                            )
                            documents.append(doc)
            except Exception as e:
                print(f"Error processing MCP source {source.name}: {e}")
        
        # Build FAISS vector store
        if documents:
            self.documents = documents
            self.vector_store = FAISS.from_documents(documents, self.embeddings)
            print(f"Vector store built with {len(documents)} documents")
        else:
            print("No documents found to build vector store")
    
    def _get_all_entities_from_kg(self) -> List[Entity]:
        """Get all entities from knowledge graph"""
        import sqlite3
        entities = []
        
        try:
            conn = sqlite3.connect(self.kg.db_path)
            cursor = conn.cursor()
            cursor.execute('SELECT id, type, name, properties, created_at FROM entities')
            rows = cursor.fetchall()
            conn.close()
            
            for row in rows:
                entity = Entity(
                    id=row[0],
                    type=row[1],
                    name=row[2],
                    properties=json.loads(row[3]) if row[3] else {},
                    created_at=row[4]
                )
                entities.append(entity)
        except Exception as e:
            print(f"Error retrieving entities from KG: {e}")
        
        return entities
    
    def _entity_to_text(self, entity: Entity) -> str:
        """Convert entity to searchable text"""
        text_parts = [
            f"Entity Type: {entity.type}",
            f"Name: {entity.name}",
            f"ID: {entity.id}"
        ]
        
        # Add properties as text
        for key, value in entity.properties.items():
            if isinstance(value, (str, int, float)):
                text_parts.append(f"{key}: {value}")
            elif isinstance(value, list):
                text_parts.append(f"{key}: {', '.join(map(str, value))}")
        
        # Add context from knowledge graph
        context = self.kg.get_entity_context(entity.id)
        if context["incoming_relationships"]:
            text_parts.append("Incoming relationships:")
            for rel in context["incoming_relationships"]:
                text_parts.append(f"  - {rel['source_id']} {rel['type']} this entity")
        
        if context["outgoing_relationships"]:
            text_parts.append("Outgoing relationships:")
            for rel in context["outgoing_relationships"]:
                text_parts.append(f"  - This entity {rel['type']} {rel['target_id']}")
        
        return "\n".join(text_parts)
    
    def retrieve_context(self, query: str, k: int = 5) -> List[Dict[str, Any]]:
        """Retrieve relevant context for a query"""
        if not self.vector_store:
            print("Vector store not built. Call build_vector_store() first.")
            return []
        
        try:
            # Perform similarity search
            docs = self.vector_store.similarity_search(query, k=k)
            
            context_items = []
            for doc in docs:
                context_item = {
                    "content": doc.page_content,
                    "metadata": doc.metadata,
                    "relevance_score": 1.0  # FAISS doesn't return scores by default
                }
                context_items.append(context_item)
            
            return context_items
        except Exception as e:
            print(f"Error retrieving context: {e}")
            return []
    
    def get_similar_code_patterns(self, task_description: str, language: str = "Python") -> List[Dict[str, Any]]:
        """Get similar code patterns for a given task"""
        # Enhanced query with language and task context
        enhanced_query = f"{language} {task_description} function class implementation"
        
        context_items = self.retrieve_context(enhanced_query, k=3)
        
        # Filter for code-related items
        code_patterns = []
        for item in context_items:
            metadata = item["metadata"]
            if (metadata.get("source_type") == "code_file" and 
                metadata.get("file_type") == "py" and language == "Python") or \
               (metadata.get("entity_type") in ["function", "class"] and 
                metadata.get("source_type") == "knowledge_graph"):
                code_patterns.append(item)
        
        return code_patterns
    
    def enhance_prompt_with_context(self, base_prompt: str, task_description: str, language: str = "Python") -> str:
        """Enhance a prompt with relevant context from RAG"""
        # Get similar code patterns
        patterns = self.get_similar_code_patterns(task_description, language)
        
        if not patterns:
            return base_prompt
        
        # Build context section
        context_section = "\n\n--- RELEVANT CONTEXT FROM CODEBASE ---\n"
        
        for i, pattern in enumerate(patterns[:3], 1):  # Limit to top 3
            context_section += f"\nExample {i}:\n"
            context_section += f"Source: {pattern['metadata'].get('source', 'Unknown')}\n"
            context_section += f"Content:\n{pattern['content'][:500]}...\n"  # Limit content length
        
        context_section += "\n--- END CONTEXT ---\n\n"
        context_section += "Please use the above context to inform your code generation, maintaining consistency with existing patterns and styles.\n\n"
        
        return context_section + base_prompt
    
    def save_vector_store(self, path: str):
        """Save vector store to disk"""
        if self.vector_store:
            self.vector_store.save_local(path)
            print(f"Vector store saved to {path}")
    
    def load_vector_store(self, path: str):
        """Load vector store from disk"""
        try:
            self.vector_store = FAISS.load_local(path, self.embeddings)
            print(f"Vector store loaded from {path}")
        except Exception as e:
            print(f"Error loading vector store: {e}")

# Example usage and testing
if __name__ == "__main__":
    from knowledge_graph import KnowledgeGraph
    from mcp_dynamic import MCPDynamic
    
    # Initialize components
    kg = KnowledgeGraph()
    mcp = MCPDynamic()
    rag = RAGSystem(kg, mcp)
    
    # Build vector store
    rag.build_vector_store("/home/ubuntu/meta-orchestrator")
    
    # Test context retrieval
    context = rag.retrieve_context("Python function initialization", k=3)
    print(f"Retrieved {len(context)} context items")
    
    for i, item in enumerate(context):
        print(f"\nContext {i+1}:")
        print(f"Source: {item['metadata']}")
        print(f"Content: {item['content'][:200]}...")
    
    # Test prompt enhancement
    base_prompt = "Generate a Python function that calculates factorial"
    enhanced_prompt = rag.enhance_prompt_with_context(base_prompt, "factorial calculation", "Python")
    print(f"\nEnhanced prompt length: {len(enhanced_prompt)} characters")

