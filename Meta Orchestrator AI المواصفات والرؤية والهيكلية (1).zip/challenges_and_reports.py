import os
import json
import sqlite3
import random
import hashlib
from datetime import datetime, timedelta
from typing import Dict, List, Any, Optional, Tuple
from dataclasses import dataclass, asdict
from enum import Enum
import logging
from concurrent.futures import ThreadPoolExecutor
import schedule
import time
import threading

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class DifficultyLevel(Enum):
    BEGINNER = "beginner"
    INTERMEDIATE = "intermediate"
    ADVANCED = "advanced"
    EXPERT = "expert"

class ChallengeType(Enum):
    ALGORITHM = "algorithm"
    DATA_STRUCTURE = "data_structure"
    WEB_DEVELOPMENT = "web_development"
    MACHINE_LEARNING = "machine_learning"
    SYSTEM_DESIGN = "system_design"
    DATABASE = "database"
    API_DEVELOPMENT = "api_development"
    DEBUGGING = "debugging"
    OPTIMIZATION = "optimization"
    TESTING = "testing"

class ChallengeStatus(Enum):
    PENDING = "pending"
    IN_PROGRESS = "in_progress"
    COMPLETED = "completed"
    FAILED = "failed"
    REVIEWED = "reviewed"

@dataclass
class Challenge:
    """Represents a coding challenge"""
    id: str
    title: str
    description: str
    difficulty: DifficultyLevel
    challenge_type: ChallengeType
    requirements: List[str]
    test_cases: List[Dict[str, Any]]
    expected_files: List[str]
    time_limit: int  # in minutes
    points: int
    tags: List[str]
    created_at: datetime
    updated_at: datetime
    
    def __post_init__(self):
        if isinstance(self.difficulty, str):
            self.difficulty = DifficultyLevel(self.difficulty)
        if isinstance(self.challenge_type, str):
            self.challenge_type = ChallengeType(self.challenge_type)

@dataclass
class ChallengeAttempt:
    """Represents an attempt to solve a challenge"""
    id: str
    challenge_id: str
    user_id: str
    status: ChallengeStatus
    submitted_files: Dict[str, str]  # filename -> content
    test_results: Dict[str, Any]
    score: float
    feedback: str
    time_taken: int  # in minutes
    started_at: datetime
    completed_at: Optional[datetime] = None
    
    def __post_init__(self):
        if isinstance(self.status, str):
            self.status = ChallengeStatus(self.status)

@dataclass
class PerformanceReport:
    """Performance report for a user or system"""
    user_id: str
    period_start: datetime
    period_end: datetime
    challenges_attempted: int
    challenges_completed: int
    average_score: float
    total_points: int
    improvement_areas: List[str]
    strengths: List[str]
    recommendations: List[str]
    generated_at: datetime

class ChallengeDatabase:
    """Database manager for challenges and attempts"""
    
    def __init__(self, db_path: str = "challenges.db"):
        self.db_path = db_path
        self.init_database()
    
    def init_database(self):
        """Initialize the challenges database"""
        with sqlite3.connect(self.db_path) as conn:
            # Challenges table
            conn.execute("""
                CREATE TABLE IF NOT EXISTS challenges (
                    id TEXT PRIMARY KEY,
                    title TEXT NOT NULL,
                    description TEXT NOT NULL,
                    difficulty TEXT NOT NULL,
                    challenge_type TEXT NOT NULL,
                    requirements TEXT NOT NULL,
                    test_cases TEXT NOT NULL,
                    expected_files TEXT NOT NULL,
                    time_limit INTEGER NOT NULL,
                    points INTEGER NOT NULL,
                    tags TEXT NOT NULL,
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL
                )
            """)
            
            # Challenge attempts table
            conn.execute("""
                CREATE TABLE IF NOT EXISTS challenge_attempts (
                    id TEXT PRIMARY KEY,
                    challenge_id TEXT NOT NULL,
                    user_id TEXT NOT NULL,
                    status TEXT NOT NULL,
                    submitted_files TEXT NOT NULL,
                    test_results TEXT NOT NULL,
                    score REAL NOT NULL,
                    feedback TEXT NOT NULL,
                    time_taken INTEGER NOT NULL,
                    started_at TEXT NOT NULL,
                    completed_at TEXT,
                    FOREIGN KEY (challenge_id) REFERENCES challenges (id)
                )
            """)
            
            # Performance reports table
            conn.execute("""
                CREATE TABLE IF NOT EXISTS performance_reports (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    user_id TEXT NOT NULL,
                    period_start TEXT NOT NULL,
                    period_end TEXT NOT NULL,
                    challenges_attempted INTEGER NOT NULL,
                    challenges_completed INTEGER NOT NULL,
                    average_score REAL NOT NULL,
                    total_points INTEGER NOT NULL,
                    improvement_areas TEXT NOT NULL,
                    strengths TEXT NOT NULL,
                    recommendations TEXT NOT NULL,
                    generated_at TEXT NOT NULL
                )
            """)
    
    def save_challenge(self, challenge: Challenge):
        """Save a challenge to the database"""
        with sqlite3.connect(self.db_path) as conn:
            conn.execute("""
                INSERT OR REPLACE INTO challenges 
                (id, title, description, difficulty, challenge_type, requirements, 
                 test_cases, expected_files, time_limit, points, tags, created_at, updated_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                challenge.id,
                challenge.title,
                challenge.description,
                challenge.difficulty.value,
                challenge.challenge_type.value,
                json.dumps(challenge.requirements),
                json.dumps(challenge.test_cases),
                json.dumps(challenge.expected_files),
                challenge.time_limit,
                challenge.points,
                json.dumps(challenge.tags),
                challenge.created_at.isoformat(),
                challenge.updated_at.isoformat()
            ))
    
    def get_challenge(self, challenge_id: str) -> Optional[Challenge]:
        """Get a challenge by ID"""
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.execute(
                "SELECT * FROM challenges WHERE id = ?", (challenge_id,)
            )
            row = cursor.fetchone()
            
            if row:
                return Challenge(
                    id=row[0],
                    title=row[1],
                    description=row[2],
                    difficulty=DifficultyLevel(row[3]),
                    challenge_type=ChallengeType(row[4]),
                    requirements=json.loads(row[5]),
                    test_cases=json.loads(row[6]),
                    expected_files=json.loads(row[7]),
                    time_limit=row[8],
                    points=row[9],
                    tags=json.loads(row[10]),
                    created_at=datetime.fromisoformat(row[11]),
                    updated_at=datetime.fromisoformat(row[12])
                )
        return None
    
    def save_attempt(self, attempt: ChallengeAttempt):
        """Save a challenge attempt to the database"""
        with sqlite3.connect(self.db_path) as conn:
            conn.execute("""
                INSERT OR REPLACE INTO challenge_attempts 
                (id, challenge_id, user_id, status, submitted_files, test_results, 
                 score, feedback, time_taken, started_at, completed_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                attempt.id,
                attempt.challenge_id,
                attempt.user_id,
                attempt.status.value,
                json.dumps(attempt.submitted_files),
                json.dumps(attempt.test_results),
                attempt.score,
                attempt.feedback,
                attempt.time_taken,
                attempt.started_at.isoformat(),
                attempt.completed_at.isoformat() if attempt.completed_at else None
            ))

class ChallengeGenerator:
    """Generates coding challenges automatically"""
    
    def __init__(self, orchestrator=None):
        self.orchestrator = orchestrator
        self.challenge_templates = self.load_challenge_templates()
    
    def load_challenge_templates(self) -> Dict[str, Dict]:
        """Load challenge templates"""
        return {
            "algorithm": {
                "beginner": [
                    {
                        "title": "Two Sum Problem",
                        "description": "Given an array of integers and a target sum, return indices of two numbers that add up to the target.",
                        "requirements": [
                            "Implement a function that takes an array and target as input",
                            "Return indices of the two numbers that sum to target",
                            "Handle edge cases (no solution, multiple solutions)"
                        ],
                        "expected_files": ["solution.py"],
                        "time_limit": 30,
                        "points": 100
                    },
                    {
                        "title": "Palindrome Checker",
                        "description": "Write a function to check if a given string is a palindrome.",
                        "requirements": [
                            "Implement a function that checks if a string reads the same forwards and backwards",
                            "Handle case sensitivity and spaces",
                            "Return boolean result"
                        ],
                        "expected_files": ["palindrome.py"],
                        "time_limit": 20,
                        "points": 80
                    }
                ],
                "intermediate": [
                    {
                        "title": "Binary Tree Traversal",
                        "description": "Implement different tree traversal algorithms (inorder, preorder, postorder).",
                        "requirements": [
                            "Define a TreeNode class",
                            "Implement recursive and iterative versions",
                            "Handle empty trees"
                        ],
                        "expected_files": ["tree_traversal.py"],
                        "time_limit": 45,
                        "points": 150
                    }
                ],
                "advanced": [
                    {
                        "title": "Dynamic Programming - Longest Common Subsequence",
                        "description": "Find the longest common subsequence between two strings using dynamic programming.",
                        "requirements": [
                            "Implement bottom-up DP solution",
                            "Optimize space complexity",
                            "Return both length and actual subsequence"
                        ],
                        "expected_files": ["lcs.py"],
                        "time_limit": 60,
                        "points": 200
                    }
                ]
            },
            "web_development": {
                "beginner": [
                    {
                        "title": "Simple REST API",
                        "description": "Create a basic REST API for managing a todo list.",
                        "requirements": [
                            "Implement CRUD operations for todos",
                            "Use appropriate HTTP methods",
                            "Return JSON responses"
                        ],
                        "expected_files": ["app.py", "requirements.txt"],
                        "time_limit": 60,
                        "points": 120
                    }
                ]
            },
            "machine_learning": {
                "intermediate": [
                    {
                        "title": "Linear Regression from Scratch",
                        "description": "Implement linear regression without using ML libraries.",
                        "requirements": [
                            "Implement gradient descent",
                            "Calculate cost function",
                            "Make predictions on test data"
                        ],
                        "expected_files": ["linear_regression.py"],
                        "time_limit": 90,
                        "points": 180
                    }
                ]
            }
        }
    
    def generate_challenge(self, difficulty: DifficultyLevel, 
                          challenge_type: ChallengeType) -> Challenge:
        """Generate a new challenge"""
        templates = self.challenge_templates.get(challenge_type.value, {})
        difficulty_templates = templates.get(difficulty.value, [])
        
        if not difficulty_templates:
            # Generate a custom challenge using the orchestrator
            return self.generate_custom_challenge(difficulty, challenge_type)
        
        template = random.choice(difficulty_templates)
        
        challenge_id = hashlib.md5(
            f"{template['title']}{datetime.now().isoformat()}".encode()
        ).hexdigest()[:12]
        
        # Generate test cases based on the challenge type
        test_cases = self.generate_test_cases(challenge_type, template)
        
        return Challenge(
            id=challenge_id,
            title=template["title"],
            description=template["description"],
            difficulty=difficulty,
            challenge_type=challenge_type,
            requirements=template["requirements"],
            test_cases=test_cases,
            expected_files=template["expected_files"],
            time_limit=template["time_limit"],
            points=template["points"],
            tags=[challenge_type.value, difficulty.value],
            created_at=datetime.now(),
            updated_at=datetime.now()
        )
    
    def generate_custom_challenge(self, difficulty: DifficultyLevel, 
                                 challenge_type: ChallengeType) -> Challenge:
        """Generate a custom challenge using the orchestrator"""
        if not self.orchestrator:
            raise ValueError("Orchestrator not available for custom challenge generation")
        
        prompt = f"""
        Generate a {difficulty.value} level {challenge_type.value} coding challenge.
        
        Include:
        1. A clear title
        2. Detailed description
        3. List of requirements
        4. Expected file names
        5. Appropriate time limit (in minutes)
        6. Point value based on difficulty
        
        Format the response as JSON with the following structure:
        {{
            "title": "Challenge Title",
            "description": "Detailed description...",
            "requirements": ["req1", "req2", ...],
            "expected_files": ["file1.py", "file2.py"],
            "time_limit": 60,
            "points": 150
        }}
        """
        
        try:
            response = self.orchestrator.generate_response(prompt)
            challenge_data = json.loads(response)
            
            challenge_id = hashlib.md5(
                f"{challenge_data['title']}{datetime.now().isoformat()}".encode()
            ).hexdigest()[:12]
            
            test_cases = self.generate_test_cases(challenge_type, challenge_data)
            
            return Challenge(
                id=challenge_id,
                title=challenge_data["title"],
                description=challenge_data["description"],
                difficulty=difficulty,
                challenge_type=challenge_type,
                requirements=challenge_data["requirements"],
                test_cases=test_cases,
                expected_files=challenge_data["expected_files"],
                time_limit=challenge_data["time_limit"],
                points=challenge_data["points"],
                tags=[challenge_type.value, difficulty.value, "custom"],
                created_at=datetime.now(),
                updated_at=datetime.now()
            )
        except Exception as e:
            logger.error(f"Error generating custom challenge: {e}")
            # Fallback to a simple challenge
            return self.generate_fallback_challenge(difficulty, challenge_type)
    
    def generate_fallback_challenge(self, difficulty: DifficultyLevel, 
                                   challenge_type: ChallengeType) -> Challenge:
        """Generate a simple fallback challenge"""
        challenge_id = hashlib.md5(
            f"fallback_{difficulty.value}_{challenge_type.value}_{datetime.now().isoformat()}".encode()
        ).hexdigest()[:12]
        
        return Challenge(
            id=challenge_id,
            title=f"{difficulty.value.title()} {challenge_type.value.replace('_', ' ').title()} Challenge",
            description=f"A {difficulty.value} level challenge focusing on {challenge_type.value.replace('_', ' ')}.",
            difficulty=difficulty,
            challenge_type=challenge_type,
            requirements=["Implement the required functionality", "Follow best practices", "Include error handling"],
            test_cases=[{"input": "test", "expected": "result"}],
            expected_files=["solution.py"],
            time_limit=60,
            points=100,
            tags=[challenge_type.value, difficulty.value, "fallback"],
            created_at=datetime.now(),
            updated_at=datetime.now()
        )
    
    def generate_test_cases(self, challenge_type: ChallengeType, template: Dict) -> List[Dict]:
        """Generate test cases for a challenge"""
        # This is a simplified version - in practice, you'd have more sophisticated test case generation
        if challenge_type == ChallengeType.ALGORITHM:
            return [
                {"input": [2, 7, 11, 15], "target": 9, "expected": [0, 1]},
                {"input": [3, 2, 4], "target": 6, "expected": [1, 2]},
                {"input": [3, 3], "target": 6, "expected": [0, 1]}
            ]
        elif challenge_type == ChallengeType.WEB_DEVELOPMENT:
            return [
                {"method": "GET", "endpoint": "/todos", "expected_status": 200},
                {"method": "POST", "endpoint": "/todos", "data": {"title": "Test"}, "expected_status": 201},
                {"method": "DELETE", "endpoint": "/todos/1", "expected_status": 204}
            ]
        else:
            return [{"input": "test_input", "expected": "test_output"}]

class ChallengeEvaluator:
    """Evaluates challenge submissions"""
    
    def __init__(self, system_integrator=None):
        self.system_integrator = system_integrator
    
    def evaluate_submission(self, challenge: Challenge, 
                          submitted_files: Dict[str, str]) -> Tuple[float, Dict, str]:
        """Evaluate a challenge submission"""
        try:
            # Check if all required files are submitted
            missing_files = set(challenge.expected_files) - set(submitted_files.keys())
            if missing_files:
                return 0.0, {"error": f"Missing files: {missing_files}"}, "Missing required files"
            
            # Run static analysis if available
            analysis_results = {}
            if self.system_integrator:
                for filename, content in submitted_files.items():
                    if filename.endswith('.py'):
                        # Save file temporarily for analysis
                        temp_path = f"/tmp/{filename}"
                        with open(temp_path, 'w') as f:
                            f.write(content)
                        
                        # Run static analysis
                        analysis_results[filename] = self.system_integrator.run_static_analysis(temp_path)
                        
                        # Clean up
                        os.remove(temp_path)
            
            # Run test cases
            test_results = self.run_test_cases(challenge, submitted_files)
            
            # Calculate score
            score = self.calculate_score(challenge, test_results, analysis_results)
            
            # Generate feedback
            feedback = self.generate_feedback(challenge, test_results, analysis_results)
            
            return score, test_results, feedback
            
        except Exception as e:
            logger.error(f"Error evaluating submission: {e}")
            return 0.0, {"error": str(e)}, f"Evaluation error: {e}"
    
    def run_test_cases(self, challenge: Challenge, 
                      submitted_files: Dict[str, str]) -> Dict:
        """Run test cases against the submission"""
        results = {
            "passed": 0,
            "total": len(challenge.test_cases),
            "details": []
        }
        
        for i, test_case in enumerate(challenge.test_cases):
            try:
                # This is a simplified test runner
                # In practice, you'd have more sophisticated test execution
                if challenge.challenge_type == ChallengeType.ALGORITHM:
                    result = self.run_algorithm_test(submitted_files, test_case)
                elif challenge.challenge_type == ChallengeType.WEB_DEVELOPMENT:
                    result = self.run_web_test(submitted_files, test_case)
                else:
                    result = {"passed": True, "message": "Test passed"}
                
                if result.get("passed", False):
                    results["passed"] += 1
                
                results["details"].append({
                    "test_case": i + 1,
                    "passed": result.get("passed", False),
                    "message": result.get("message", ""),
                    "expected": test_case.get("expected"),
                    "actual": result.get("actual")
                })
                
            except Exception as e:
                results["details"].append({
                    "test_case": i + 1,
                    "passed": False,
                    "message": f"Test execution error: {e}",
                    "expected": test_case.get("expected"),
                    "actual": None
                })
        
        return results
    
    def run_algorithm_test(self, submitted_files: Dict[str, str], 
                          test_case: Dict) -> Dict:
        """Run algorithm test case"""
        # This is a simplified implementation
        # In practice, you'd execute the code in a sandboxed environment
        return {
            "passed": True,
            "message": "Algorithm test passed",
            "actual": test_case.get("expected")
        }
    
    def run_web_test(self, submitted_files: Dict[str, str], 
                    test_case: Dict) -> Dict:
        """Run web development test case"""
        # This is a simplified implementation
        # In practice, you'd start the web server and make HTTP requests
        return {
            "passed": True,
            "message": "Web test passed",
            "actual": test_case.get("expected_status")
        }
    
    def calculate_score(self, challenge: Challenge, test_results: Dict, 
                       analysis_results: Dict) -> float:
        """Calculate the final score for a submission"""
        # Base score from test results
        test_score = (test_results["passed"] / test_results["total"]) * 0.8
        
        # Code quality score from static analysis
        quality_score = 0.2
        if analysis_results:
            # Simplified quality scoring
            total_issues = sum(
                len(result.get("issues", [])) 
                for result in analysis_results.values()
            )
            quality_score = max(0, 0.2 - (total_issues * 0.02))
        
        return min(1.0, test_score + quality_score)
    
    def generate_feedback(self, challenge: Challenge, test_results: Dict, 
                         analysis_results: Dict) -> str:
        """Generate feedback for the submission"""
        feedback_parts = []
        
        # Test results feedback
        passed_tests = test_results["passed"]
        total_tests = test_results["total"]
        feedback_parts.append(f"Test Results: {passed_tests}/{total_tests} tests passed")
        
        if passed_tests < total_tests:
            failed_tests = [
                detail for detail in test_results["details"] 
                if not detail["passed"]
            ]
            feedback_parts.append("Failed tests:")
            for test in failed_tests[:3]:  # Show first 3 failed tests
                feedback_parts.append(f"  - Test {test['test_case']}: {test['message']}")
        
        # Code quality feedback
        if analysis_results:
            feedback_parts.append("\nCode Quality:")
            for filename, result in analysis_results.items():
                issues = result.get("issues", [])
                if issues:
                    feedback_parts.append(f"  {filename}:")
                    for issue in issues[:3]:  # Show first 3 issues
                        feedback_parts.append(f"    - {issue}")
                else:
                    feedback_parts.append(f"  {filename}: No issues found")
        
        return "\n".join(feedback_parts)

class ReportGenerator:
    """Generates performance reports"""
    
    def __init__(self, database: ChallengeDatabase):
        self.database = database
    
    def generate_user_report(self, user_id: str, days: int = 30) -> PerformanceReport:
        """Generate a performance report for a user"""
        end_date = datetime.now()
        start_date = end_date - timedelta(days=days)
        
        # Get user's attempts in the period
        with sqlite3.connect(self.database.db_path) as conn:
            cursor = conn.execute("""
                SELECT * FROM challenge_attempts 
                WHERE user_id = ? AND started_at BETWEEN ? AND ?
                ORDER BY started_at DESC
            """, (user_id, start_date.isoformat(), end_date.isoformat()))
            
            attempts = cursor.fetchall()
        
        if not attempts:
            return PerformanceReport(
                user_id=user_id,
                period_start=start_date,
                period_end=end_date,
                challenges_attempted=0,
                challenges_completed=0,
                average_score=0.0,
                total_points=0,
                improvement_areas=["Start attempting challenges"],
                strengths=[],
                recommendations=["Begin with beginner-level challenges"],
                generated_at=datetime.now()
            )
        
        # Calculate metrics
        challenges_attempted = len(attempts)
        challenges_completed = len([a for a in attempts if a[3] == "completed"])
        scores = [a[6] for a in attempts if a[6] > 0]
        average_score = sum(scores) / len(scores) if scores else 0.0
        
        # Calculate total points (simplified)
        total_points = int(sum(scores) * 100)
        
        # Analyze performance patterns
        improvement_areas = self.identify_improvement_areas(attempts)
        strengths = self.identify_strengths(attempts)
        recommendations = self.generate_recommendations(attempts, average_score)
        
        return PerformanceReport(
            user_id=user_id,
            period_start=start_date,
            period_end=end_date,
            challenges_attempted=challenges_attempted,
            challenges_completed=challenges_completed,
            average_score=average_score,
            total_points=total_points,
            improvement_areas=improvement_areas,
            strengths=strengths,
            recommendations=recommendations,
            generated_at=datetime.now()
        )
    
    def identify_improvement_areas(self, attempts: List) -> List[str]:
        """Identify areas for improvement based on attempts"""
        areas = []
        
        # Analyze completion rate
        completion_rate = len([a for a in attempts if a[3] == "completed"]) / len(attempts)
        if completion_rate < 0.5:
            areas.append("Challenge completion rate")
        
        # Analyze average score
        scores = [a[6] for a in attempts if a[6] > 0]
        if scores and sum(scores) / len(scores) < 0.7:
            areas.append("Code quality and correctness")
        
        # Analyze time management
        times = [a[8] for a in attempts if a[8] > 0]
        if times:
            avg_time = sum(times) / len(times)
            # This would need challenge time limits to be meaningful
            # For now, just check if taking too long on average
            if avg_time > 90:  # More than 90 minutes average
                areas.append("Time management")
        
        return areas if areas else ["Continue practicing to identify specific areas"]
    
    def identify_strengths(self, attempts: List) -> List[str]:
        """Identify strengths based on attempts"""
        strengths = []
        
        # Analyze completion rate
        completion_rate = len([a for a in attempts if a[3] == "completed"]) / len(attempts)
        if completion_rate > 0.8:
            strengths.append("High challenge completion rate")
        
        # Analyze average score
        scores = [a[6] for a in attempts if a[6] > 0]
        if scores and sum(scores) / len(scores) > 0.8:
            strengths.append("Excellent code quality")
        
        # Analyze consistency
        if len(attempts) > 5 and all(a[6] > 0.6 for a in attempts[-5:]):
            strengths.append("Consistent performance")
        
        return strengths if strengths else ["Building foundational skills"]
    
    def generate_recommendations(self, attempts: List, average_score: float) -> List[str]:
        """Generate recommendations based on performance"""
        recommendations = []
        
        if not attempts:
            return ["Start with beginner-level algorithm challenges"]
        
        if average_score < 0.5:
            recommendations.extend([
                "Focus on understanding problem requirements thoroughly",
                "Practice basic programming concepts",
                "Review solutions to similar problems"
            ])
        elif average_score < 0.7:
            recommendations.extend([
                "Work on code optimization and edge case handling",
                "Practice more challenging problems",
                "Focus on writing clean, readable code"
            ])
        else:
            recommendations.extend([
                "Try advanced challenges to push your limits",
                "Explore new problem domains",
                "Consider mentoring others or contributing to open source"
            ])
        
        return recommendations

class ChallengeScheduler:
    """Schedules periodic challenge generation and reporting"""
    
    def __init__(self, challenge_generator: ChallengeGenerator, 
                 report_generator: ReportGenerator,
                 database: ChallengeDatabase):
        self.challenge_generator = challenge_generator
        self.report_generator = report_generator
        self.database = database
        self.scheduler_thread = None
        self.running = False
    
    def start_scheduler(self):
        """Start the challenge scheduler"""
        if self.running:
            return
        
        self.running = True
        
        # Schedule daily challenge generation
        schedule.every().day.at("09:00").do(self.generate_daily_challenges)
        
        # Schedule weekly reports
        schedule.every().monday.at("10:00").do(self.generate_weekly_reports)
        
        # Schedule monthly comprehensive reports
        schedule.every().month.do(self.generate_monthly_reports)
        
        def run_scheduler():
            while self.running:
                schedule.run_pending()
                time.sleep(60)  # Check every minute
        
        self.scheduler_thread = threading.Thread(target=run_scheduler, daemon=True)
        self.scheduler_thread.start()
        
        logger.info("Challenge scheduler started")
    
    def stop_scheduler(self):
        """Stop the challenge scheduler"""
        self.running = False
        if self.scheduler_thread:
            self.scheduler_thread.join()
        logger.info("Challenge scheduler stopped")
    
    def generate_daily_challenges(self):
        """Generate daily challenges"""
        try:
            # Generate one challenge for each difficulty level
            difficulties = [DifficultyLevel.BEGINNER, DifficultyLevel.INTERMEDIATE, DifficultyLevel.ADVANCED]
            challenge_types = [ChallengeType.ALGORITHM, ChallengeType.WEB_DEVELOPMENT, ChallengeType.MACHINE_LEARNING]
            
            for difficulty in difficulties:
                challenge_type = random.choice(challenge_types)
                challenge = self.challenge_generator.generate_challenge(difficulty, challenge_type)
                self.database.save_challenge(challenge)
                logger.info(f"Generated daily challenge: {challenge.title}")
        
        except Exception as e:
            logger.error(f"Error generating daily challenges: {e}")
    
    def generate_weekly_reports(self):
        """Generate weekly performance reports"""
        try:
            # This would typically get all active users
            # For now, we'll just log that reports would be generated
            logger.info("Weekly reports would be generated for all users")
        except Exception as e:
            logger.error(f"Error generating weekly reports: {e}")
    
    def generate_monthly_reports(self):
        """Generate monthly comprehensive reports"""
        try:
            logger.info("Monthly comprehensive reports would be generated")
        except Exception as e:
            logger.error(f"Error generating monthly reports: {e}")

class ChallengeManager:
    """Main manager for the challenges and reports system"""
    
    def __init__(self, orchestrator=None, system_integrator=None):
        self.database = ChallengeDatabase()
        self.generator = ChallengeGenerator(orchestrator)
        self.evaluator = ChallengeEvaluator(system_integrator)
        self.report_generator = ReportGenerator(self.database)
        self.scheduler = ChallengeScheduler(self.generator, self.report_generator, self.database)
    
    def start(self):
        """Start the challenge management system"""
        self.scheduler.start_scheduler()
        logger.info("Challenge management system started")
    
    def stop(self):
        """Stop the challenge management system"""
        self.scheduler.stop_scheduler()
        logger.info("Challenge management system stopped")
    
    def create_challenge(self, difficulty: DifficultyLevel, 
                        challenge_type: ChallengeType) -> Challenge:
        """Create a new challenge"""
        challenge = self.generator.generate_challenge(difficulty, challenge_type)
        self.database.save_challenge(challenge)
        return challenge
    
    def submit_solution(self, challenge_id: str, user_id: str, 
                       submitted_files: Dict[str, str]) -> ChallengeAttempt:
        """Submit a solution for evaluation"""
        challenge = self.database.get_challenge(challenge_id)
        if not challenge:
            raise ValueError(f"Challenge {challenge_id} not found")
        
        # Evaluate the submission
        score, test_results, feedback = self.evaluator.evaluate_submission(
            challenge, submitted_files
        )
        
        # Create attempt record
        attempt = ChallengeAttempt(
            id=hashlib.md5(f"{challenge_id}{user_id}{datetime.now().isoformat()}".encode()).hexdigest()[:12],
            challenge_id=challenge_id,
            user_id=user_id,
            status=ChallengeStatus.COMPLETED if score > 0.5 else ChallengeStatus.FAILED,
            submitted_files=submitted_files,
            test_results=test_results,
            score=score,
            feedback=feedback,
            time_taken=0,  # Would be calculated based on start/end times
            started_at=datetime.now(),
            completed_at=datetime.now()
        )
        
        self.database.save_attempt(attempt)
        return attempt
    
    def get_user_report(self, user_id: str, days: int = 30) -> PerformanceReport:
        """Get performance report for a user"""
        return self.report_generator.generate_user_report(user_id, days)
    
    def get_available_challenges(self, difficulty: DifficultyLevel = None, 
                               challenge_type: ChallengeType = None) -> List[Challenge]:
        """Get available challenges with optional filtering"""
        # This would query the database for available challenges
        # For now, return empty list as placeholder
        return []

if __name__ == "__main__":
    # Example usage
    manager = ChallengeManager()
    
    try:
        # Start the system
        manager.start()
        
        # Create a sample challenge
        challenge = manager.create_challenge(
            DifficultyLevel.BEGINNER, 
            ChallengeType.ALGORITHM
        )
        print(f"Created challenge: {challenge.title}")
        
        # Simulate a solution submission
        sample_solution = {
            "solution.py": """
def two_sum(nums, target):
    num_map = {}
    for i, num in enumerate(nums):
        complement = target - num
        if complement in num_map:
            return [num_map[complement], i]
        num_map[num] = i
    return []
"""
        }
        
        attempt = manager.submit_solution(
            challenge.id, 
            "user123", 
            sample_solution
        )
        print(f"Submission score: {attempt.score}")
        print(f"Feedback: {attempt.feedback}")
        
        # Generate user report
        report = manager.get_user_report("user123")
        print(f"User report: {report.challenges_attempted} challenges attempted")
        
    except KeyboardInterrupt:
        print("Shutting down...")
    finally:
        manager.stop()

