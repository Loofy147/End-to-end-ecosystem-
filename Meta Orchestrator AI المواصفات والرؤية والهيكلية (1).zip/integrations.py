import os
import json
import requests
import subprocess
import docker
from typing import Dict, List, Any, Optional
from dataclasses import dataclass
from datetime import datetime
import logging

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

@dataclass
class IntegrationConfig:
    """Configuration for external integrations"""
    name: str
    api_key: Optional[str] = None
    base_url: Optional[str] = None
    enabled: bool = True
    config: Dict[str, Any] = None

class HuggingFaceIntegration:
    """Integration with Hugging Face Hub"""
    
    def __init__(self, api_key: str):
        self.api_key = api_key
        self.base_url = "https://api-inference.huggingface.co"
        self.headers = {"Authorization": f"Bearer {api_key}"}
    
    def search_models(self, query: str, task: str = None, limit: int = 10) -> List[Dict]:
        """Search for models on Hugging Face Hub"""
        try:
            url = "https://huggingface.co/api/models"
            params = {
                "search": query,
                "limit": limit
            }
            if task:
                params["filter"] = task
            
            response = requests.get(url, params=params)
            response.raise_for_status()
            return response.json()
        except Exception as e:
            logger.error(f"Error searching HuggingFace models: {e}")
            return []
    
    def download_model(self, model_name: str, local_path: str) -> bool:
        """Download a model from Hugging Face Hub"""
        try:
            from huggingface_hub import snapshot_download
            snapshot_download(
                repo_id=model_name,
                local_dir=local_path,
                token=self.api_key
            )
            return True
        except Exception as e:
            logger.error(f"Error downloading model {model_name}: {e}")
            return False
    
    def inference(self, model_name: str, inputs: Dict) -> Dict:
        """Run inference on a Hugging Face model"""
        try:
            url = f"{self.base_url}/models/{model_name}"
            response = requests.post(url, headers=self.headers, json=inputs)
            response.raise_for_status()
            return response.json()
        except Exception as e:
            logger.error(f"Error running inference on {model_name}: {e}")
            return {}

class KaggleIntegration:
    """Integration with Kaggle API"""
    
    def __init__(self, username: str, key: str):
        self.username = username
        self.key = key
        os.environ['KAGGLE_USERNAME'] = username
        os.environ['KAGGLE_KEY'] = key
    
    def search_datasets(self, query: str, limit: int = 10) -> List[Dict]:
        """Search for datasets on Kaggle"""
        try:
            import kaggle
            datasets = kaggle.api.dataset_list(search=query, max_size=limit)
            return [
                {
                    "ref": dataset.ref,
                    "title": dataset.title,
                    "size": dataset.size,
                    "downloadCount": dataset.downloadCount,
                    "voteCount": dataset.voteCount,
                    "creationDate": dataset.creationDate
                }
                for dataset in datasets
            ]
        except Exception as e:
            logger.error(f"Error searching Kaggle datasets: {e}")
            return []
    
    def download_dataset(self, dataset_ref: str, path: str) -> bool:
        """Download a dataset from Kaggle"""
        try:
            import kaggle
            kaggle.api.dataset_download_files(dataset_ref, path=path, unzip=True)
            return True
        except Exception as e:
            logger.error(f"Error downloading dataset {dataset_ref}: {e}")
            return False
    
    def search_competitions(self, query: str = None) -> List[Dict]:
        """Search for competitions on Kaggle"""
        try:
            import kaggle
            competitions = kaggle.api.competitions_list(search=query)
            return [
                {
                    "ref": comp.ref,
                    "title": comp.title,
                    "category": comp.category,
                    "reward": comp.reward,
                    "deadline": comp.deadline,
                    "description": comp.description
                }
                for comp in competitions
            ]
        except Exception as e:
            logger.error(f"Error searching Kaggle competitions: {e}")
            return []

class DockerIntegration:
    """Integration with Docker for containerization"""
    
    def __init__(self):
        try:
            self.client = docker.from_env()
        except Exception as e:
            logger.error(f"Error connecting to Docker: {e}")
            self.client = None
    
    def build_image(self, dockerfile_path: str, tag: str, context_path: str = ".") -> bool:
        """Build a Docker image"""
        try:
            if not self.client:
                return False
            
            image, logs = self.client.images.build(
                path=context_path,
                dockerfile=dockerfile_path,
                tag=tag
            )
            logger.info(f"Successfully built image: {tag}")
            return True
        except Exception as e:
            logger.error(f"Error building Docker image: {e}")
            return False
    
    def run_container(self, image: str, command: str = None, volumes: Dict = None, 
                     environment: Dict = None, ports: Dict = None) -> Optional[str]:
        """Run a Docker container"""
        try:
            if not self.client:
                return None
            
            container = self.client.containers.run(
                image=image,
                command=command,
                volumes=volumes or {},
                environment=environment or {},
                ports=ports or {},
                detach=True
            )
            logger.info(f"Started container: {container.id}")
            return container.id
        except Exception as e:
            logger.error(f"Error running Docker container: {e}")
            return None
    
    def list_containers(self, all_containers: bool = False) -> List[Dict]:
        """List Docker containers"""
        try:
            if not self.client:
                return []
            
            containers = self.client.containers.list(all=all_containers)
            return [
                {
                    "id": container.id,
                    "name": container.name,
                    "status": container.status,
                    "image": container.image.tags[0] if container.image.tags else "unknown"
                }
                for container in containers
            ]
        except Exception as e:
            logger.error(f"Error listing Docker containers: {e}")
            return []
    
    def create_dockerfile(self, project_path: str, language: str, dependencies: List[str]) -> str:
        """Generate a Dockerfile for a project"""
        dockerfile_content = ""
        
        if language.lower() == "python":
            dockerfile_content = f"""FROM python:3.11-slim

WORKDIR /app

COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt

COPY . .

EXPOSE 8000

CMD ["python", "app.py"]
"""
        elif language.lower() == "node" or language.lower() == "javascript":
            dockerfile_content = f"""FROM node:18-alpine

WORKDIR /app

COPY package*.json ./
RUN npm ci --only=production

COPY . .

EXPOSE 3000

CMD ["npm", "start"]
"""
        
        dockerfile_path = os.path.join(project_path, "Dockerfile")
        with open(dockerfile_path, 'w') as f:
            f.write(dockerfile_content)
        
        return dockerfile_path

class GitHubIntegration:
    """Integration with GitHub API"""
    
    def __init__(self, token: str):
        self.token = token
        self.headers = {
            "Authorization": f"token {token}",
            "Accept": "application/vnd.github.v3+json"
        }
        self.base_url = "https://api.github.com"
    
    def create_repository(self, name: str, description: str = "", private: bool = False) -> Dict:
        """Create a new GitHub repository"""
        try:
            url = f"{self.base_url}/user/repos"
            data = {
                "name": name,
                "description": description,
                "private": private,
                "auto_init": True
            }
            response = requests.post(url, headers=self.headers, json=data)
            response.raise_for_status()
            return response.json()
        except Exception as e:
            logger.error(f"Error creating GitHub repository: {e}")
            return {}
    
    def push_code(self, repo_path: str, commit_message: str = "Auto-generated code") -> bool:
        """Push code to GitHub repository"""
        try:
            # Git commands
            subprocess.run(["git", "add", "."], cwd=repo_path, check=True)
            subprocess.run(["git", "commit", "-m", commit_message], cwd=repo_path, check=True)
            subprocess.run(["git", "push"], cwd=repo_path, check=True)
            return True
        except Exception as e:
            logger.error(f"Error pushing to GitHub: {e}")
            return False
    
    def search_repositories(self, query: str, language: str = None, limit: int = 10) -> List[Dict]:
        """Search for repositories on GitHub"""
        try:
            url = f"{self.base_url}/search/repositories"
            params = {
                "q": query,
                "per_page": limit
            }
            if language:
                params["q"] += f" language:{language}"
            
            response = requests.get(url, headers=self.headers, params=params)
            response.raise_for_status()
            return response.json().get("items", [])
        except Exception as e:
            logger.error(f"Error searching GitHub repositories: {e}")
            return []

class IntegrationManager:
    """Manages all external integrations"""
    
    def __init__(self, config_path: str = "integrations_config.json"):
        self.config_path = config_path
        self.integrations = {}
        self.load_config()
        self.initialize_integrations()
    
    def load_config(self):
        """Load integration configurations"""
        try:
            if os.path.exists(self.config_path):
                with open(self.config_path, 'r') as f:
                    config_data = json.load(f)
                    self.config = {
                        name: IntegrationConfig(**cfg) 
                        for name, cfg in config_data.items()
                    }
            else:
                self.config = self.create_default_config()
                self.save_config()
        except Exception as e:
            logger.error(f"Error loading integration config: {e}")
            self.config = self.create_default_config()
    
    def create_default_config(self) -> Dict[str, IntegrationConfig]:
        """Create default integration configuration"""
        return {
            "huggingface": IntegrationConfig(
                name="huggingface",
                api_key=os.getenv("HUGGINGFACE_API_KEY"),
                enabled=bool(os.getenv("HUGGINGFACE_API_KEY"))
            ),
            "kaggle": IntegrationConfig(
                name="kaggle",
                config={
                    "username": os.getenv("KAGGLE_USERNAME"),
                    "key": os.getenv("KAGGLE_KEY")
                },
                enabled=bool(os.getenv("KAGGLE_USERNAME") and os.getenv("KAGGLE_KEY"))
            ),
            "docker": IntegrationConfig(
                name="docker",
                enabled=True
            ),
            "github": IntegrationConfig(
                name="github",
                api_key=os.getenv("GITHUB_TOKEN"),
                enabled=bool(os.getenv("GITHUB_TOKEN"))
            )
        }
    
    def save_config(self):
        """Save integration configurations"""
        try:
            config_data = {
                name: {
                    "name": cfg.name,
                    "api_key": cfg.api_key,
                    "base_url": cfg.base_url,
                    "enabled": cfg.enabled,
                    "config": cfg.config
                }
                for name, cfg in self.config.items()
            }
            with open(self.config_path, 'w') as f:
                json.dump(config_data, f, indent=2)
        except Exception as e:
            logger.error(f"Error saving integration config: {e}")
    
    def initialize_integrations(self):
        """Initialize all enabled integrations"""
        for name, config in self.config.items():
            if not config.enabled:
                continue
            
            try:
                if name == "huggingface" and config.api_key:
                    self.integrations[name] = HuggingFaceIntegration(config.api_key)
                elif name == "kaggle" and config.config:
                    self.integrations[name] = KaggleIntegration(
                        config.config.get("username"),
                        config.config.get("key")
                    )
                elif name == "docker":
                    self.integrations[name] = DockerIntegration()
                elif name == "github" and config.api_key:
                    self.integrations[name] = GitHubIntegration(config.api_key)
                
                logger.info(f"Initialized {name} integration")
            except Exception as e:
                logger.error(f"Error initializing {name} integration: {e}")
    
    def get_integration(self, name: str):
        """Get a specific integration"""
        return self.integrations.get(name)
    
    def list_integrations(self) -> Dict[str, bool]:
        """List all integrations and their status"""
        return {
            name: name in self.integrations 
            for name in self.config.keys()
        }
    
    def enable_integration(self, name: str) -> bool:
        """Enable a specific integration"""
        if name in self.config:
            self.config[name].enabled = True
            self.save_config()
            self.initialize_integrations()
            return True
        return False
    
    def disable_integration(self, name: str) -> bool:
        """Disable a specific integration"""
        if name in self.config:
            self.config[name].enabled = False
            if name in self.integrations:
                del self.integrations[name]
            self.save_config()
            return True
        return False
    
    def test_integrations(self) -> Dict[str, bool]:
        """Test all integrations"""
        results = {}
        
        for name, integration in self.integrations.items():
            try:
                if name == "huggingface":
                    # Test by searching for a simple model
                    result = integration.search_models("bert", limit=1)
                    results[name] = len(result) > 0
                elif name == "kaggle":
                    # Test by searching for datasets
                    result = integration.search_datasets("titanic", limit=1)
                    results[name] = len(result) > 0
                elif name == "docker":
                    # Test by listing containers
                    result = integration.list_containers()
                    results[name] = isinstance(result, list)
                elif name == "github":
                    # Test by searching repositories
                    result = integration.search_repositories("python", limit=1)
                    results[name] = len(result) > 0
                else:
                    results[name] = False
            except Exception as e:
                logger.error(f"Error testing {name} integration: {e}")
                results[name] = False
        
        return results

# Utility functions for common integration tasks
def setup_project_environment(project_path: str, language: str, integrations: IntegrationManager):
    """Set up a complete project environment with integrations"""
    try:
        # Create Dockerfile if Docker integration is available
        docker_integration = integrations.get_integration("docker")
        if docker_integration:
            dockerfile_path = docker_integration.create_dockerfile(
                project_path, language, []
            )
            logger.info(f"Created Dockerfile at {dockerfile_path}")
        
        # Initialize Git repository if GitHub integration is available
        github_integration = integrations.get_integration("github")
        if github_integration:
            subprocess.run(["git", "init"], cwd=project_path, check=True)
            logger.info("Initialized Git repository")
        
        return True
    except Exception as e:
        logger.error(f"Error setting up project environment: {e}")
        return False

def deploy_to_container(project_path: str, integrations: IntegrationManager, 
                       image_name: str = "orchestrator-project") -> Optional[str]:
    """Deploy a project to a Docker container"""
    try:
        docker_integration = integrations.get_integration("docker")
        if not docker_integration:
            logger.error("Docker integration not available")
            return None
        
        # Build the image
        dockerfile_path = os.path.join(project_path, "Dockerfile")
        if not os.path.exists(dockerfile_path):
            logger.error("Dockerfile not found")
            return None
        
        success = docker_integration.build_image(dockerfile_path, image_name, project_path)
        if not success:
            return None
        
        # Run the container
        container_id = docker_integration.run_container(
            image_name,
            ports={"8000/tcp": 8000}
        )
        
        return container_id
    except Exception as e:
        logger.error(f"Error deploying to container: {e}")
        return None

if __name__ == "__main__":
    # Example usage
    manager = IntegrationManager()
    
    # Test all integrations
    test_results = manager.test_integrations()
    print("Integration test results:")
    for name, status in test_results.items():
        print(f"  {name}: {'✓' if status else '✗'}")
    
    # List available integrations
    integrations_status = manager.list_integrations()
    print("\nAvailable integrations:")
    for name, enabled in integrations_status.items():
        print(f"  {name}: {'Enabled' if enabled else 'Disabled'}")

