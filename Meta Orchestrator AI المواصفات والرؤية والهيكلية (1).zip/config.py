import os

class Config:
    OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")
    SLACK_BOT_TOKEN = os.getenv("SLACK_BOT_TOKEN")
    SLACK_SIGNING_SECRET = os.getenv("SLACK_SIGNING_SECRET")

    # Internal MCP (Meta-Context Processor) - Initial simple version
    # This will be expanded significantly in later phases
    MCP_CONTEXT = {
        "project_name": "Meta Orchestrator AI",
        "default_language": "Python",
        "style_guides": {
            "Python": "PEP8",
            "JavaScript": "Airbnb"
        },
        "test_frameworks": {
            "Python": "pytest",
            "JavaScript": "Jest"
        }
    }

    # Paths
    PROMPTS_DIR = "prompts"
    EXAMPLES_DIR = "examples"
    LOGS_DIR = "logs"

    # Code Generation Settings
    CODE_COVERAGE_TARGET = 0.90 # 90%



