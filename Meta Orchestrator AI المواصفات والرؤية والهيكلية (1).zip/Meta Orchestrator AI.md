# Meta Orchestrator AI

نظام ذكي متطور لتوليد الأكواد البرمجية مع قدرات التحسين الذاتي والتعلم المستمر.

## 🚀 الميزات الرئيسية

- **توليد كود ذكي**: استخدام GPT-4 لتوليد كود عالي الجودة
- **Knowledge Graph**: إدارة المعرفة والعلاقات بين مكونات الكود
- **RAG System**: استرجاع السياق الذكي لتحسين التوليد
- **Self-Improvement**: تعلم مستمر من التغذية الراجعة
- **دورة مراجعة ذاتية**: تحليل ثابت واختبارات تلقائية
- **واجهة ويب تفاعلية**: سهولة الاستخدام والإدارة

## 🏗️ الهيكل المعماري

```
meta-orchestrator/
├── config.py              # إعدادات النظام
├── orchestrator.py         # المحرك الرئيسي
├── knowledge_graph.py      # رسم بياني للمعرفة
├── rag_system.py          # نظام RAG
├── self_improvement.py    # التحسين الذاتي
├── system_integrator.py   # أدوات التحليل
└── prompts/               # قوالب البرومبتات
```

## 🛠️ التثبيت والإعداد

### المتطلبات
- Python 3.11+
- OpenAI API key

### خطوات التثبيت

1. **استنساخ المشروع**
```bash
git clone <repository-url>
cd meta-orchestrator
```

2. **تثبيت التبعيات**
```bash
pip install -r requirements.txt
```

3. **تكوين البيئة**
```bash
cp .env.example .env
# قم بتحرير .env وإضافة مفتاح OpenAI API
```

4. **تشغيل النظام**
```bash
# تشغيل الخادم
cd ../meta_orchestrator_api
source venv/bin/activate
python src/main.py
```

5. **الوصول للواجهة**
افتح المتصفح على: `http://localhost:5000`

## 📖 الاستخدام

### توليد كود جديد

1. أدخل وصف المهمة في الواجهة
2. اختر لغة البرمجة
3. اضغط "توليد الكود"
4. راجع النتائج وقدم تقييمك

### استخدام API

```python
import requests

response = requests.post('http://localhost:5000/api/generate-code', json={
    'task_description': 'Create a function to calculate factorial',
    'language': 'Python',
    'module_name': 'math_utils'
})

result = response.json()
print(result['generated_code'])
```

## 🧠 المكونات الذكية

### Knowledge Graph
- استخراج الكيانات من الكود
- تتبع العلاقات والتبعيات
- توفير سياق شامل للتوليد

### RAG System
- فهرسة قاعدة الكود الموجودة
- البحث الدلالي عن الأنماط المشابهة
- تحسين البرومبتات بالسياق ذي الصلة

### Self-Improvement
- تعلم من تقييمات المستخدمين
- تحليل الأخطاء والتصحيحات
- تحسين الأداء مع الوقت

## 📊 مراقبة الأداء

### إحصائيات النظام
```bash
curl http://localhost:5000/api/knowledge-graph/stats
curl http://localhost:5000/api/health
```

### مقاييس الجودة
- معدل نجاح الاختبارات
- تغطية الاختبارات
- تقييمات المستخدمين
- وقت التوليد

## 🔧 التخصيص والتطوير

### إضافة برومبت مخصص
```markdown
<!-- prompts/custom_prompt.md -->
You are an expert {{domain}} developer.
Generate {{output_type}} for: {{requirement}}
```

### إضافة محلل جديد
```python
class CustomAnalyzer:
    def analyze(self, code):
        # تنفيذ التحليل المخصص
        return analysis_results
```

## 🚀 التطويرات المستقبلية

- دعم لغات برمجة إضافية
- تكامل مع IDEs
- نشر سحابي
- ذكاء اصطناعي متعدد الوسائط

## 📄 الترخيص

هذا المشروع مرخص تحت [MIT License](LICENSE).

## 🤝 المساهمة

نرحب بالمساهمات! يرجى قراءة [دليل المساهمة](CONTRIBUTING.md) للمزيد من التفاصيل.

## 📞 الدعم

- التوثيق الكامل: [Meta_Orchestrator_AI_Complete_Documentation.md](Meta_Orchestrator_AI_Complete_Documentation.md)
- تقرير الأخطاء: [GitHub Issues](issues)
- المناقشات: [GitHub Discussions](discussions)

---

**Meta Orchestrator AI - مستقبل توليد الأكواد الذكي** 🤖✨

