import os
import json
import sqlite3
import asyncio
import aiohttp
import aiofiles
from datetime import datetime, timedelta
from typing import Dict, List, Any, Optional, Tuple, AsyncGenerator
from dataclasses import dataclass, asdict
import logging
import threading
import time
import hashlib
import pickle
import gzip
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

import requests
import pandas as pd
import numpy as np
from bs4 import BeautifulSoup
import feedparser

from ai_seed import AISeed, Experience, TaskType
from mcp_dynamic import MCPManager
from knowledge_graph import KnowledgeGraph

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

@dataclass
class DataSource:
    """مصدر البيانات"""
    source_id: str
    name: str
    source_type: str  # api, file, web, database, stream
    url: Optional[str] = None
    config: Dict[str, Any] = None
    last_updated: Optional[datetime] = None
    status: str = "active"  # active, inactive, error
    data_format: str = "json"  # json, csv, xml, text, binary
    update_frequency: str = "daily"  # realtime, hourly, daily, weekly
    priority: int = 1  # 1-10, higher is more important

@dataclass
class DataBatch:
    """دفعة البيانات"""
    batch_id: str
    source_id: str
    timestamp: datetime
    data_type: str
    data_size: int
    data_hash: str
    processed: bool = False
    quality_score: float = 0.0
    metadata: Dict[str, Any] = None

@dataclass
class LearningDataPoint:
    """نقطة بيانات التعلم"""
    data_id: str
    source_id: str
    content: Any
    data_type: str
    complexity_level: float
    relevance_score: float
    learning_value: float
    extracted_patterns: List[str]
    timestamp: datetime

class DataIngestionEngine:
    """محرك استيعاب البيانات لبذرة الذكاء الاصطناعي"""
    
    def __init__(self, orchestrator=None):
        self.orchestrator = orchestrator
        self.mcp_manager = MCPManager()
        self.knowledge_graph = KnowledgeGraph()
        
        # مصادر البيانات
        self.data_sources = {}  # source_id -> DataSource
        self.active_streams = {}  # source_id -> stream_handler
        
        # معالجة البيانات
        self.data_processors = {}
        self.data_cache = {}
        self.processing_queue = asyncio.Queue()
        
        # إعدادات الاستيعاب
        self.ingestion_config = {
            "max_concurrent_sources": 10,
            "batch_size": 100,
            "cache_size_mb": 500,
            "quality_threshold": 0.6,
            "relevance_threshold": 0.5,
            "auto_discovery": True,
            "real_time_processing": True
        }
        
        # قاعدة بيانات الاستيعاب
        self.ingestion_db_path = "ai_seed_data_ingestion.db"
        self.init_ingestion_database()
        
        # مجلد البيانات
        self.data_dir = Path("ai_seed_data")
        self.data_dir.mkdir(exist_ok=True)
        
        # حالة المحرك
        self.is_running = False
        self.ingestion_tasks = []
        
        # إحصائيات
        self.ingestion_stats = {
            "total_sources": 0,
            "active_sources": 0,
            "data_points_processed": 0,
            "learning_points_extracted": 0,
            "average_quality": 0.0,
            "processing_rate": 0.0
        }
        
        logger.info("تم تهيئة محرك استيعاب البيانات")
    
    def init_ingestion_database(self):
        """تهيئة قاعدة بيانات الاستيعاب"""
        with sqlite3.connect(self.ingestion_db_path) as conn:
            # جدول مصادر البيانات
            conn.execute("""
                CREATE TABLE IF NOT EXISTS data_sources (
                    source_id TEXT PRIMARY KEY,
                    name TEXT NOT NULL,
                    source_type TEXT NOT NULL,
                    url TEXT,
                    config TEXT,
                    last_updated TEXT,
                    status TEXT DEFAULT 'active',
                    data_format TEXT DEFAULT 'json',
                    update_frequency TEXT DEFAULT 'daily',
                    priority INTEGER DEFAULT 1
                )
            """)
            
            # جدول دفعات البيانات
            conn.execute("""
                CREATE TABLE IF NOT EXISTS data_batches (
                    batch_id TEXT PRIMARY KEY,
                    source_id TEXT NOT NULL,
                    timestamp TEXT NOT NULL,
                    data_type TEXT NOT NULL,
                    data_size INTEGER NOT NULL,
                    data_hash TEXT NOT NULL,
                    processed BOOLEAN DEFAULT FALSE,
                    quality_score REAL DEFAULT 0.0,
                    metadata TEXT
                )
            """)
            
            # جدول نقاط التعلم
            conn.execute("""
                CREATE TABLE IF NOT EXISTS learning_data_points (
                    data_id TEXT PRIMARY KEY,
                    source_id TEXT NOT NULL,
                    content TEXT NOT NULL,
                    data_type TEXT NOT NULL,
                    complexity_level REAL NOT NULL,
                    relevance_score REAL NOT NULL,
                    learning_value REAL NOT NULL,
                    extracted_patterns TEXT,
                    timestamp TEXT NOT NULL
                )
            """)
            
            # جدول إحصائيات الاستيعاب
            conn.execute("""
                CREATE TABLE IF NOT EXISTS ingestion_stats (
                    timestamp TEXT PRIMARY KEY,
                    total_sources INTEGER,
                    active_sources INTEGER,
                    data_points_processed INTEGER,
                    learning_points_extracted INTEGER,
                    average_quality REAL,
                    processing_rate REAL
                )
            """)
    
    def register_data_source(self, source: DataSource) -> bool:
        """تسجيل مصدر بيانات جديد"""
        try:
            # التحقق من صحة المصدر
            if not self.validate_data_source(source):
                logger.error(f"مصدر البيانات غير صالح: {source.source_id}")
                return False
            
            # حفظ المصدر
            self.data_sources[source.source_id] = source
            self.save_data_source(source)
            
            # بدء الاستيعاب إذا كان المحرك يعمل
            if self.is_running and source.status == "active":
                self.start_source_ingestion(source.source_id)
            
            logger.info(f"تم تسجيل مصدر البيانات: {source.source_id}")
            return True
            
        except Exception as e:
            logger.error(f"خطأ في تسجيل مصدر البيانات: {e}")
            return False
    
    def validate_data_source(self, source: DataSource) -> bool:
        """التحقق من صحة مصدر البيانات"""
        try:
            # فحص المعرف
            if not source.source_id or not source.name:
                return False
            
            # فحص النوع
            valid_types = ["api", "file", "web", "database", "stream", "github", "kaggle", "huggingface"]
            if source.source_type not in valid_types:
                return False
            
            # فحص URL للمصادر التي تتطلبه
            if source.source_type in ["api", "web", "stream"] and not source.url:
                return False
            
            # فحص الإعدادات
            if source.source_type == "api" and source.config:
                required_keys = ["method", "headers"]
                if not all(key in source.config for key in required_keys if source.config.get("auth_required", False)):
                    pass  # يمكن أن تكون بعض APIs عامة
            
            return True
            
        except Exception as e:
            logger.error(f"خطأ في التحقق من المصدر: {e}")
            return False
    
    def save_data_source(self, source: DataSource):
        """حفظ مصدر البيانات في قاعدة البيانات"""
        with sqlite3.connect(self.ingestion_db_path) as conn:
            conn.execute("""
                INSERT OR REPLACE INTO data_sources 
                (source_id, name, source_type, url, config, last_updated, 
                 status, data_format, update_frequency, priority)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                source.source_id,
                source.name,
                source.source_type,
                source.url,
                json.dumps(source.config or {}),
                source.last_updated.isoformat() if source.last_updated else None,
                source.status,
                source.data_format,
                source.update_frequency,
                source.priority
            ))
    
    async def start_ingestion(self):
        """بدء محرك الاستيعاب"""
        if self.is_running:
            logger.warning("محرك الاستيعاب يعمل بالفعل")
            return
        
        self.is_running = True
        logger.info("بدء محرك استيعاب البيانات")
        
        # بدء المعالج الرئيسي
        self.ingestion_tasks.append(
            asyncio.create_task(self.main_processing_loop())
        )
        
        # بدء مراقب الإحصائيات
        self.ingestion_tasks.append(
            asyncio.create_task(self.stats_monitor())
        )
        
        # بدء استيعاب المصادر النشطة
        for source_id, source in self.data_sources.items():
            if source.status == "active":
                self.start_source_ingestion(source_id)
        
        # اكتشاف مصادر جديدة إذا كان مفعلاً
        if self.ingestion_config["auto_discovery"]:
            self.ingestion_tasks.append(
                asyncio.create_task(self.auto_discover_sources())
            )
    
    def start_source_ingestion(self, source_id: str):
        """بدء استيعاب مصدر محدد"""
        if source_id not in self.data_sources:
            logger.error(f"مصدر البيانات غير موجود: {source_id}")
            return
        
        source = self.data_sources[source_id]
        
        # إنشاء مهمة الاستيعاب
        task = asyncio.create_task(
            self.ingest_from_source(source)
        )
        self.ingestion_tasks.append(task)
        
        logger.info(f"تم بدء استيعاب المصدر: {source_id}")
    
    async def ingest_from_source(self, source: DataSource):
        """استيعاب البيانات من مصدر محدد"""
        try:
            while self.is_running and source.status == "active":
                try:
                    # جلب البيانات
                    data = await self.fetch_data_from_source(source)
                    
                    if data:
                        # إنشاء دفعة بيانات
                        batch = self.create_data_batch(source, data)
                        
                        # إضافة للمعالجة
                        await self.processing_queue.put(batch)
                        
                        # تحديث وقت آخر تحديث
                        source.last_updated = datetime.now()
                        self.save_data_source(source)
                    
                    # انتظار بناءً على تكرار التحديث
                    await self.wait_for_next_update(source)
                    
                except Exception as e:
                    logger.error(f"خطأ في استيعاب البيانات من {source.source_id}: {e}")
                    source.status = "error"
                    await asyncio.sleep(300)  # انتظار 5 دقائق قبل المحاولة مرة أخرى
                
        except Exception as e:
            logger.error(f"خطأ عام في استيعاب المصدر {source.source_id}: {e}")
    
    async def fetch_data_from_source(self, source: DataSource) -> Optional[Any]:
        """جلب البيانات من المصدر"""
        try:
            if source.source_type == "api":
                return await self.fetch_from_api(source)
            elif source.source_type == "web":
                return await self.fetch_from_web(source)
            elif source.source_type == "file":
                return await self.fetch_from_file(source)
            elif source.source_type == "github":
                return await self.fetch_from_github(source)
            elif source.source_type == "kaggle":
                return await self.fetch_from_kaggle(source)
            elif source.source_type == "huggingface":
                return await self.fetch_from_huggingface(source)
            else:
                logger.warning(f"نوع مصدر غير مدعوم: {source.source_type}")
                return None
                
        except Exception as e:
            logger.error(f"خطأ في جلب البيانات من {source.source_id}: {e}")
            return None
    
    async def fetch_from_api(self, source: DataSource) -> Optional[Dict[str, Any]]:
        """جلب البيانات من API"""
        try:
            config = source.config or {}
            method = config.get("method", "GET")
            headers = config.get("headers", {})
            params = config.get("params", {})
            
            async with aiohttp.ClientSession() as session:
                async with session.request(
                    method=method,
                    url=source.url,
                    headers=headers,
                    params=params,
                    timeout=aiohttp.ClientTimeout(total=30)
                ) as response:
                    if response.status == 200:
                        if source.data_format == "json":
                            return await response.json()
                        else:
                            return {"content": await response.text()}
                    else:
                        logger.warning(f"API استجابة غير ناجحة {response.status} من {source.source_id}")
                        return None
                        
        except Exception as e:
            logger.error(f"خطأ في جلب البيانات من API {source.source_id}: {e}")
            return None
    
    async def fetch_from_web(self, source: DataSource) -> Optional[Dict[str, Any]]:
        """جلب البيانات من موقع ويب"""
        try:
            async with aiohttp.ClientSession() as session:
                async with session.get(source.url, timeout=aiohttp.ClientTimeout(total=30)) as response:
                    if response.status == 200:
                        content = await response.text()
                        
                        # تحليل HTML
                        soup = BeautifulSoup(content, 'html.parser')
                        
                        # استخراج النص
                        text_content = soup.get_text(strip=True)
                        
                        # استخراج الروابط
                        links = [a.get('href') for a in soup.find_all('a', href=True)]
                        
                        return {
                            "content": text_content,
                            "links": links,
                            "title": soup.title.string if soup.title else "",
                            "meta": {
                                "url": source.url,
                                "timestamp": datetime.now().isoformat()
                            }
                        }
                    else:
                        logger.warning(f"فشل في جلب الصفحة {response.status} من {source.source_id}")
                        return None
                        
        except Exception as e:
            logger.error(f"خطأ في جلب البيانات من الويب {source.source_id}: {e}")
            return None
    
    async def fetch_from_file(self, source: DataSource) -> Optional[Any]:
        """جلب البيانات من ملف"""
        try:
            file_path = source.url or source.config.get("file_path")
            if not file_path or not os.path.exists(file_path):
                logger.error(f"الملف غير موجود: {file_path}")
                return None
            
            async with aiofiles.open(file_path, 'r', encoding='utf-8') as file:
                content = await file.read()
                
                if source.data_format == "json":
                    return json.loads(content)
                elif source.data_format == "csv":
                    # يمكن استخدام pandas هنا
                    return {"content": content, "format": "csv"}
                else:
                    return {"content": content}
                    
        except Exception as e:
            logger.error(f"خطأ في قراءة الملف {source.source_id}: {e}")
            return None
    
    async def fetch_from_github(self, source: DataSource) -> Optional[Dict[str, Any]]:
        """جلب البيانات من GitHub"""
        try:
            # استخدام GitHub API
            config = source.config or {}
            repo = config.get("repository")
            path = config.get("path", "")
            
            if not repo:
                logger.error(f"مستودع GitHub غير محدد في {source.source_id}")
                return None
            
            api_url = f"https://api.github.com/repos/{repo}/contents/{path}"
            
            async with aiohttp.ClientSession() as session:
                headers = {}
                if config.get("token"):
                    headers["Authorization"] = f"token {config['token']}"
                
                async with session.get(api_url, headers=headers) as response:
                    if response.status == 200:
                        return await response.json()
                    else:
                        logger.warning(f"فشل في جلب البيانات من GitHub {response.status}")
                        return None
                        
        except Exception as e:
            logger.error(f"خطأ في جلب البيانات من GitHub {source.source_id}: {e}")
            return None
    
    async def fetch_from_kaggle(self, source: DataSource) -> Optional[Dict[str, Any]]:
        """جلب البيانات من Kaggle"""
        try:
            # استخدام Kaggle API
            config = source.config or {}
            dataset = config.get("dataset")
            
            if not dataset:
                logger.error(f"مجموعة بيانات Kaggle غير محددة في {source.source_id}")
                return None
            
            # هذا يتطلب تثبيت kaggle package وإعداد API credentials
            # يمكن تنفيذه لاحقاً بناءً على الحاجة
            
            return {"message": "Kaggle integration placeholder", "dataset": dataset}
            
        except Exception as e:
            logger.error(f"خطأ في جلب البيانات من Kaggle {source.source_id}: {e}")
            return None
    
    async def fetch_from_huggingface(self, source: DataSource) -> Optional[Dict[str, Any]]:
        """جلب البيانات من Hugging Face"""
        try:
            config = source.config or {}
            model_id = config.get("model_id")
            dataset_id = config.get("dataset_id")
            
            if model_id:
                # جلب معلومات النموذج
                api_url = f"https://huggingface.co/api/models/{model_id}"
            elif dataset_id:
                # جلب معلومات مجموعة البيانات
                api_url = f"https://huggingface.co/api/datasets/{dataset_id}"
            else:
                logger.error(f"معرف النموذج أو مجموعة البيانات غير محدد في {source.source_id}")
                return None
            
            async with aiohttp.ClientSession() as session:
                async with session.get(api_url) as response:
                    if response.status == 200:
                        return await response.json()
                    else:
                        logger.warning(f"فشل في جلب البيانات من Hugging Face {response.status}")
                        return None
                        
        except Exception as e:
            logger.error(f"خطأ في جلب البيانات من Hugging Face {source.source_id}: {e}")
            return None
    
    def create_data_batch(self, source: DataSource, data: Any) -> DataBatch:
        """إنشاء دفعة بيانات"""
        # حساب hash للبيانات
        data_str = json.dumps(data, sort_keys=True, default=str)
        data_hash = hashlib.sha256(data_str.encode()).hexdigest()
        
        # إنشاء معرف الدفعة
        batch_id = f"batch_{source.source_id}_{datetime.now().strftime('%Y%m%d_%H%M%S')}_{data_hash[:8]}"
        
        # تحديد نوع البيانات
        data_type = self.determine_data_type(data)
        
        return DataBatch(
            batch_id=batch_id,
            source_id=source.source_id,
            timestamp=datetime.now(),
            data_type=data_type,
            data_size=len(data_str),
            data_hash=data_hash,
            metadata={
                "source_type": source.source_type,
                "data_format": source.data_format,
                "priority": source.priority
            }
        )
    
    def determine_data_type(self, data: Any) -> str:
        """تحديد نوع البيانات"""
        if isinstance(data, dict):
            if "code" in data or "function" in data:
                return "code"
            elif "content" in data and isinstance(data["content"], str):
                if len(data["content"]) > 1000:
                    return "document"
                else:
                    return "text"
            elif "links" in data:
                return "web_content"
            else:
                return "structured_data"
        elif isinstance(data, list):
            return "list_data"
        elif isinstance(data, str):
            if len(data) > 1000:
                return "document"
            else:
                return "text"
        else:
            return "unknown"
    
    async def wait_for_next_update(self, source: DataSource):
        """انتظار التحديث التالي"""
        frequency_map = {
            "realtime": 1,      # ثانية واحدة
            "hourly": 3600,     # ساعة
            "daily": 86400,     # يوم
            "weekly": 604800    # أسبوع
        }
        
        wait_time = frequency_map.get(source.update_frequency, 86400)
        await asyncio.sleep(wait_time)
    
    async def main_processing_loop(self):
        """حلقة المعالجة الرئيسية"""
        while self.is_running:
            try:
                # انتظار دفعة بيانات
                batch = await asyncio.wait_for(
                    self.processing_queue.get(),
                    timeout=10.0
                )
                
                # معالجة الدفعة
                await self.process_data_batch(batch)
                
                # تحديث الإحصائيات
                self.update_processing_stats()
                
            except asyncio.TimeoutError:
                # لا توجد دفعات للمعالجة
                continue
            except Exception as e:
                logger.error(f"خطأ في حلقة المعالجة: {e}")
                await asyncio.sleep(5)
    
    async def process_data_batch(self, batch: DataBatch):
        """معالجة دفعة البيانات"""
        try:
            logger.info(f"معالجة دفعة البيانات: {batch.batch_id}")
            
            # جلب البيانات الفعلية (من الذاكرة المؤقتة أو المصدر)
            data = await self.get_batch_data(batch)
            
            if not data:
                logger.warning(f"لا توجد بيانات للدفعة: {batch.batch_id}")
                return
            
            # تقييم جودة البيانات
            quality_score = self.evaluate_data_quality(data, batch)
            batch.quality_score = quality_score
            
            # فلترة البيانات منخفضة الجودة
            if quality_score < self.ingestion_config["quality_threshold"]:
                logger.info(f"تم تجاهل دفعة منخفضة الجودة: {batch.batch_id}")
                return
            
            # استخراج نقاط التعلم
            learning_points = await self.extract_learning_points(data, batch)
            
            # حفظ نقاط التعلم
            for point in learning_points:
                await self.save_learning_point(point)
            
            # تحديث Knowledge Graph
            await self.update_knowledge_graph(learning_points)
            
            # وضع علامة على الدفعة كمعالجة
            batch.processed = True
            self.save_data_batch(batch)
            
            logger.info(f"تم معالجة الدفعة {batch.batch_id}: {len(learning_points)} نقطة تعلم")
            
        except Exception as e:
            logger.error(f"خطأ في معالجة الدفعة {batch.batch_id}: {e}")
    
    async def get_batch_data(self, batch: DataBatch) -> Optional[Any]:
        """الحصول على بيانات الدفعة"""
        # يمكن تحسين هذا بحفظ البيانات في ملفات مؤقتة
        # للآن، نفترض أن البيانات محفوظة في الذاكرة المؤقتة
        return self.data_cache.get(batch.batch_id)
    
    def evaluate_data_quality(self, data: Any, batch: DataBatch) -> float:
        """تقييم جودة البيانات"""
        try:
            quality_score = 0.0
            
            # فحص وجود البيانات
            if data:
                quality_score += 0.3
            
            # فحص حجم البيانات
            if batch.data_size > 100:  # أكثر من 100 حرف
                quality_score += 0.2
            
            # فحص نوع البيانات
            if batch.data_type in ["code", "document", "structured_data"]:
                quality_score += 0.3
            
            # فحص التنوع
            if isinstance(data, dict) and len(data) > 3:
                quality_score += 0.2
            
            # فحص خاص بنوع البيانات
            if batch.data_type == "code":
                if isinstance(data, dict) and "code" in data:
                    code = data["code"]
                    if "def " in code or "class " in code:
                        quality_score += 0.2
            
            elif batch.data_type == "document":
                if isinstance(data, dict) and "content" in data:
                    content = data["content"]
                    if len(content.split()) > 50:  # أكثر من 50 كلمة
                        quality_score += 0.2
            
            return min(quality_score, 1.0)
            
        except Exception as e:
            logger.error(f"خطأ في تقييم جودة البيانات: {e}")
            return 0.0
    
    async def extract_learning_points(self, data: Any, batch: DataBatch) -> List[LearningDataPoint]:
        """استخراج نقاط التعلم من البيانات"""
        try:
            learning_points = []
            
            if batch.data_type == "code":
                points = await self.extract_code_learning_points(data, batch)
                learning_points.extend(points)
            
            elif batch.data_type == "document":
                points = await self.extract_document_learning_points(data, batch)
                learning_points.extend(points)
            
            elif batch.data_type == "structured_data":
                points = await self.extract_structured_learning_points(data, batch)
                learning_points.extend(points)
            
            elif batch.data_type == "web_content":
                points = await self.extract_web_learning_points(data, batch)
                learning_points.extend(points)
            
            return learning_points
            
        except Exception as e:
            logger.error(f"خطأ في استخراج نقاط التعلم: {e}")
            return []
    
    async def extract_code_learning_points(self, data: Dict[str, Any], batch: DataBatch) -> List[LearningDataPoint]:
        """استخراج نقاط التعلم من الكود"""
        points = []
        
        try:
            code_content = data.get("code", "")
            if not code_content:
                return points
            
            # تحليل الكود
            patterns = []
            complexity = 0.5
            
            # فحص الدوال
            if "def " in code_content:
                patterns.append("function_definition")
                complexity += 0.2
            
            # فحص الفئات
            if "class " in code_content:
                patterns.append("class_definition")
                complexity += 0.3
            
            # فحص الحلقات
            if any(keyword in code_content for keyword in ["for ", "while "]):
                patterns.append("loops")
                complexity += 0.1
            
            # فحص الشروط
            if "if " in code_content:
                patterns.append("conditionals")
                complexity += 0.1
            
            # فحص المكتبات
            if "import " in code_content:
                patterns.append("imports")
                complexity += 0.1
            
            # حساب قيمة التعلم
            learning_value = min(complexity * len(patterns) * 0.2, 1.0)
            
            # حساب الصلة
            relevance_score = 0.8  # الكود عادة مفيد للتعلم
            
            # إنشاء نقطة التعلم
            point = LearningDataPoint(
                data_id=f"code_{batch.batch_id}_{hashlib.md5(code_content.encode()).hexdigest()[:8]}",
                source_id=batch.source_id,
                content=code_content,
                data_type="code",
                complexity_level=complexity,
                relevance_score=relevance_score,
                learning_value=learning_value,
                extracted_patterns=patterns,
                timestamp=datetime.now()
            )
            
            points.append(point)
            
        except Exception as e:
            logger.error(f"خطأ في استخراج نقاط التعلم من الكود: {e}")
        
        return points
    
    async def extract_document_learning_points(self, data: Dict[str, Any], batch: DataBatch) -> List[LearningDataPoint]:
        """استخراج نقاط التعلم من الوثائق"""
        points = []
        
        try:
            content = data.get("content", "")
            if not content:
                return points
            
            # تحليل النص
            words = content.split()
            sentences = content.split('.')
            
            patterns = []
            complexity = 0.3
            
            # تحليل الطول
            if len(words) > 100:
                patterns.append("long_document")
                complexity += 0.2
            
            # فحص المصطلحات التقنية
            tech_keywords = ["algorithm", "function", "variable", "loop", "condition", "class", "object"]
            tech_count = sum(1 for word in words if word.lower() in tech_keywords)
            if tech_count > 5:
                patterns.append("technical_content")
                complexity += 0.3
            
            # فحص الأمثلة
            if "example" in content.lower() or "for instance" in content.lower():
                patterns.append("contains_examples")
                complexity += 0.2
            
            # حساب قيمة التعلم
            learning_value = min(complexity * len(patterns) * 0.15, 1.0)
            
            # حساب الصلة بناءً على المحتوى التقنى
            relevance_score = min(tech_count / len(words) * 10, 1.0)
            
            # تقسيم الوثيقة إلى أجزاء إذا كانت طويلة
            if len(content) > 2000:
                # تقسيم إلى فقرات
                paragraphs = content.split('\n\n')
                for i, paragraph in enumerate(paragraphs):
                    if len(paragraph.strip()) > 100:
                        point = LearningDataPoint(
                            data_id=f"doc_{batch.batch_id}_part_{i}",
                            source_id=batch.source_id,
                            content=paragraph.strip(),
                            data_type="document_part",
                            complexity_level=complexity,
                            relevance_score=relevance_score,
                            learning_value=learning_value,
                            extracted_patterns=patterns,
                            timestamp=datetime.now()
                        )
                        points.append(point)
            else:
                # وثيقة واحدة
                point = LearningDataPoint(
                    data_id=f"doc_{batch.batch_id}",
                    source_id=batch.source_id,
                    content=content,
                    data_type="document",
                    complexity_level=complexity,
                    relevance_score=relevance_score,
                    learning_value=learning_value,
                    extracted_patterns=patterns,
                    timestamp=datetime.now()
                )
                points.append(point)
            
        except Exception as e:
            logger.error(f"خطأ في استخراج نقاط التعلم من الوثيقة: {e}")
        
        return points
    
    async def extract_structured_learning_points(self, data: Any, batch: DataBatch) -> List[LearningDataPoint]:
        """استخراج نقاط التعلم من البيانات المنظمة"""
        points = []
        
        try:
            if not isinstance(data, dict):
                return points
            
            patterns = []
            complexity = 0.4
            
            # تحليل البنية
            if len(data) > 5:
                patterns.append("complex_structure")
                complexity += 0.2
            
            # فحص الأنواع المختلفة
            value_types = set(type(v).__name__ for v in data.values())
            if len(value_types) > 2:
                patterns.append("diverse_data_types")
                complexity += 0.1
            
            # فحص البيانات المتداخلة
            nested_count = sum(1 for v in data.values() if isinstance(v, (dict, list)))
            if nested_count > 0:
                patterns.append("nested_data")
                complexity += 0.2
            
            # حساب قيمة التعلم
            learning_value = min(complexity * len(patterns) * 0.2, 1.0)
            
            # حساب الصلة
            relevance_score = 0.6  # البيانات المنظمة مفيدة بشكل معتدل
            
            # إنشاء نقطة التعلم
            point = LearningDataPoint(
                data_id=f"struct_{batch.batch_id}",
                source_id=batch.source_id,
                content=json.dumps(data, ensure_ascii=False, indent=2),
                data_type="structured_data",
                complexity_level=complexity,
                relevance_score=relevance_score,
                learning_value=learning_value,
                extracted_patterns=patterns,
                timestamp=datetime.now()
            )
            
            points.append(point)
            
        except Exception as e:
            logger.error(f"خطأ في استخراج نقاط التعلم من البيانات المنظمة: {e}")
        
        return points
    
    async def extract_web_learning_points(self, data: Dict[str, Any], batch: DataBatch) -> List[LearningDataPoint]:
        """استخراج نقاط التعلم من محتوى الويب"""
        points = []
        
        try:
            content = data.get("content", "")
            links = data.get("links", [])
            title = data.get("title", "")
            
            if not content:
                return points
            
            patterns = []
            complexity = 0.3
            
            # تحليل المحتوى
            if len(content) > 500:
                patterns.append("substantial_content")
                complexity += 0.2
            
            # فحص الروابط
            if len(links) > 10:
                patterns.append("rich_links")
                complexity += 0.1
            
            # فحص العنوان
            if title and any(keyword in title.lower() for keyword in ["tutorial", "guide", "documentation", "api"]):
                patterns.append("educational_content")
                complexity += 0.3
            
            # حساب قيمة التعلم
            learning_value = min(complexity * len(patterns) * 0.15, 1.0)
            
            # حساب الصلة
            tech_keywords = ["programming", "code", "development", "software", "algorithm"]
            relevance_score = 0.4
            if any(keyword in content.lower() for keyword in tech_keywords):
                relevance_score = 0.7
            
            # إنشاء نقطة التعلم
            point = LearningDataPoint(
                data_id=f"web_{batch.batch_id}",
                source_id=batch.source_id,
                content=content[:2000],  # تحديد الطول
                data_type="web_content",
                complexity_level=complexity,
                relevance_score=relevance_score,
                learning_value=learning_value,
                extracted_patterns=patterns,
                timestamp=datetime.now()
            )
            
            points.append(point)
            
        except Exception as e:
            logger.error(f"خطأ في استخراج نقاط التعلم من محتوى الويب: {e}")
        
        return points
    
    async def save_learning_point(self, point: LearningDataPoint):
        """حفظ نقطة التعلم"""
        try:
            # فلترة بناءً على الصلة
            if point.relevance_score < self.ingestion_config["relevance_threshold"]:
                return
            
            # حفظ في قاعدة البيانات
            with sqlite3.connect(self.ingestion_db_path) as conn:
                conn.execute("""
                    INSERT OR REPLACE INTO learning_data_points 
                    (data_id, source_id, content, data_type, complexity_level,
                     relevance_score, learning_value, extracted_patterns, timestamp)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                """, (
                    point.data_id,
                    point.source_id,
                    point.content,
                    point.data_type,
                    point.complexity_level,
                    point.relevance_score,
                    point.learning_value,
                    json.dumps(point.extracted_patterns),
                    point.timestamp.isoformat()
                ))
            
            # حفظ في ملف منفصل للوصول السريع
            point_file = self.data_dir / f"{point.data_id}.json"
            async with aiofiles.open(point_file, 'w', encoding='utf-8') as f:
                await f.write(json.dumps(asdict(point), default=str, ensure_ascii=False, indent=2))
            
            logger.debug(f"تم حفظ نقطة التعلم: {point.data_id}")
            
        except Exception as e:
            logger.error(f"خطأ في حفظ نقطة التعلم: {e}")
    
    async def update_knowledge_graph(self, learning_points: List[LearningDataPoint]):
        """تحديث شبكة المعرفة بنقاط التعلم الجديدة"""
        try:
            for point in learning_points:
                # إضافة كيان للنقطة
                entity_id = f"learning_point_{point.data_id}"
                
                self.knowledge_graph.add_entity(
                    entity_id=entity_id,
                    entity_type="learning_data",
                    properties={
                        "data_type": point.data_type,
                        "complexity": point.complexity_level,
                        "relevance": point.relevance_score,
                        "learning_value": point.learning_value,
                        "source": point.source_id,
                        "timestamp": point.timestamp.isoformat()
                    }
                )
                
                # إضافة علاقات للأنماط
                for pattern in point.extracted_patterns:
                    pattern_entity = f"pattern_{pattern}"
                    
                    # إضافة كيان النمط إذا لم يكن موجوداً
                    if not self.knowledge_graph.has_entity(pattern_entity):
                        self.knowledge_graph.add_entity(
                            entity_id=pattern_entity,
                            entity_type="pattern",
                            properties={"pattern_name": pattern}
                        )
                    
                    # إضافة علاقة
                    self.knowledge_graph.add_relationship(
                        entity1_id=entity_id,
                        entity2_id=pattern_entity,
                        relationship_type="contains_pattern",
                        properties={"strength": point.learning_value}
                    )
                
                # إضافة علاقة بالمصدر
                source_entity = f"data_source_{point.source_id}"
                if not self.knowledge_graph.has_entity(source_entity):
                    self.knowledge_graph.add_entity(
                        entity_id=source_entity,
                        entity_type="data_source",
                        properties={"source_id": point.source_id}
                    )
                
                self.knowledge_graph.add_relationship(
                    entity1_id=entity_id,
                    entity2_id=source_entity,
                    relationship_type="sourced_from",
                    properties={"timestamp": point.timestamp.isoformat()}
                )
            
        except Exception as e:
            logger.error(f"خطأ في تحديث شبكة المعرفة: {e}")
    
    def save_data_batch(self, batch: DataBatch):
        """حفظ دفعة البيانات"""
        with sqlite3.connect(self.ingestion_db_path) as conn:
            conn.execute("""
                INSERT OR REPLACE INTO data_batches 
                (batch_id, source_id, timestamp, data_type, data_size,
                 data_hash, processed, quality_score, metadata)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                batch.batch_id,
                batch.source_id,
                batch.timestamp.isoformat(),
                batch.data_type,
                batch.data_size,
                batch.data_hash,
                batch.processed,
                batch.quality_score,
                json.dumps(batch.metadata or {})
            ))
    
    def update_processing_stats(self):
        """تحديث إحصائيات المعالجة"""
        try:
            self.ingestion_stats["total_sources"] = len(self.data_sources)
            self.ingestion_stats["active_sources"] = len([s for s in self.data_sources.values() if s.status == "active"])
            self.ingestion_stats["data_points_processed"] += 1
            
            # حساب معدل المعالجة (نقاط في الدقيقة)
            # يمكن تحسين هذا بتتبع الوقت
            
        except Exception as e:
            logger.error(f"خطأ في تحديث الإحصائيات: {e}")
    
    async def stats_monitor(self):
        """مراقب الإحصائيات"""
        while self.is_running:
            try:
                # حفظ الإحصائيات كل 5 دقائق
                await asyncio.sleep(300)
                
                with sqlite3.connect(self.ingestion_db_path) as conn:
                    conn.execute("""
                        INSERT INTO ingestion_stats 
                        (timestamp, total_sources, active_sources, data_points_processed,
                         learning_points_extracted, average_quality, processing_rate)
                        VALUES (?, ?, ?, ?, ?, ?, ?)
                    """, (
                        datetime.now().isoformat(),
                        self.ingestion_stats["total_sources"],
                        self.ingestion_stats["active_sources"],
                        self.ingestion_stats["data_points_processed"],
                        self.ingestion_stats["learning_points_extracted"],
                        self.ingestion_stats["average_quality"],
                        self.ingestion_stats["processing_rate"]
                    ))
                
            except Exception as e:
                logger.error(f"خطأ في مراقب الإحصائيات: {e}")
    
    async def auto_discover_sources(self):
        """اكتشاف مصادر البيانات تلقائياً"""
        while self.is_running:
            try:
                # اكتشاف مصادر جديدة كل ساعة
                await asyncio.sleep(3600)
                
                # يمكن إضافة منطق اكتشاف مصادر جديدة هنا
                # مثل البحث في GitHub عن مستودعات جديدة
                # أو اكتشاف APIs جديدة
                
                logger.info("تم تشغيل اكتشاف المصادر التلقائي")
                
            except Exception as e:
                logger.error(f"خطأ في اكتشاف المصادر: {e}")
    
    async def stop_ingestion(self):
        """إيقاف محرك الاستيعاب"""
        logger.info("إيقاف محرك استيعاب البيانات")
        
        self.is_running = False
        
        # إلغاء جميع المهام
        for task in self.ingestion_tasks:
            task.cancel()
        
        # انتظار انتهاء المهام
        if self.ingestion_tasks:
            await asyncio.gather(*self.ingestion_tasks, return_exceptions=True)
        
        # حفظ الإحصائيات النهائية
        self.save_final_stats()
        
        logger.info("تم إيقاف محرك الاستيعاب")
    
    def save_final_stats(self):
        """حفظ الإحصائيات النهائية"""
        try:
            with sqlite3.connect(self.ingestion_db_path) as conn:
                conn.execute("""
                    INSERT INTO ingestion_stats 
                    (timestamp, total_sources, active_sources, data_points_processed,
                     learning_points_extracted, average_quality, processing_rate)
                    VALUES (?, ?, ?, ?, ?, ?, ?)
                """, (
                    datetime.now().isoformat(),
                    self.ingestion_stats["total_sources"],
                    self.ingestion_stats["active_sources"],
                    self.ingestion_stats["data_points_processed"],
                    self.ingestion_stats["learning_points_extracted"],
                    self.ingestion_stats["average_quality"],
                    self.ingestion_stats["processing_rate"]
                ))
        except Exception as e:
            logger.error(f"خطأ في حفظ الإحصائيات النهائية: {e}")
    
    def get_learning_data_for_seed(self, seed_id: str, limit: int = 100) -> List[LearningDataPoint]:
        """الحصول على بيانات التعلم للبذرة"""
        try:
            with sqlite3.connect(self.ingestion_db_path) as conn:
                cursor = conn.execute("""
                    SELECT * FROM learning_data_points 
                    WHERE relevance_score >= ? 
                    ORDER BY learning_value DESC, timestamp DESC 
                    LIMIT ?
                """, (self.ingestion_config["relevance_threshold"], limit))
                
                points = []
                for row in cursor.fetchall():
                    columns = [desc[0] for desc in cursor.description]
                    data = dict(zip(columns, row))
                    
                    # تحويل البيانات
                    point = LearningDataPoint(
                        data_id=data["data_id"],
                        source_id=data["source_id"],
                        content=data["content"],
                        data_type=data["data_type"],
                        complexity_level=data["complexity_level"],
                        relevance_score=data["relevance_score"],
                        learning_value=data["learning_value"],
                        extracted_patterns=json.loads(data["extracted_patterns"]),
                        timestamp=datetime.fromisoformat(data["timestamp"])
                    )
                    points.append(point)
                
                return points
                
        except Exception as e:
            logger.error(f"خطأ في الحصول على بيانات التعلم: {e}")
            return []
    
    def get_ingestion_statistics(self) -> Dict[str, Any]:
        """الحصول على إحصائيات الاستيعاب"""
        try:
            with sqlite3.connect(self.ingestion_db_path) as conn:
                # إحصائيات عامة
                cursor = conn.execute("""
                    SELECT 
                        COUNT(*) as total_batches,
                        COUNT(CASE WHEN processed = 1 THEN 1 END) as processed_batches,
                        AVG(quality_score) as avg_quality,
                        SUM(data_size) as total_data_size
                    FROM data_batches
                """)
                batch_stats = cursor.fetchone()
                
                # إحصائيات نقاط التعلم
                cursor = conn.execute("""
                    SELECT 
                        COUNT(*) as total_points,
                        AVG(learning_value) as avg_learning_value,
                        AVG(relevance_score) as avg_relevance,
                        AVG(complexity_level) as avg_complexity
                    FROM learning_data_points
                """)
                learning_stats = cursor.fetchone()
                
                # إحصائيات المصادر
                cursor = conn.execute("""
                    SELECT 
                        source_type,
                        COUNT(*) as count,
                        AVG(priority) as avg_priority
                    FROM data_sources
                    GROUP BY source_type
                """)
                source_stats = cursor.fetchall()
                
                return {
                    "batch_statistics": {
                        "total_batches": batch_stats[0] or 0,
                        "processed_batches": batch_stats[1] or 0,
                        "average_quality": batch_stats[2] or 0.0,
                        "total_data_size": batch_stats[3] or 0
                    },
                    "learning_statistics": {
                        "total_learning_points": learning_stats[0] or 0,
                        "average_learning_value": learning_stats[1] or 0.0,
                        "average_relevance": learning_stats[2] or 0.0,
                        "average_complexity": learning_stats[3] or 0.0
                    },
                    "source_statistics": [
                        {
                            "source_type": row[0],
                            "count": row[1],
                            "average_priority": row[2]
                        }
                        for row in source_stats
                    ],
                    "current_stats": self.ingestion_stats,
                    "is_running": self.is_running
                }
                
        except Exception as e:
            logger.error(f"خطأ في الحصول على إحصائيات الاستيعاب: {e}")
            return {}

# مثال على الاستخدام
async def main():
    """مثال على الاستخدام"""
    engine = DataIngestionEngine()
    
    try:
        # تسجيل مصادر البيانات
        sources = [
            DataSource(
                source_id="github_python_repos",
                name="مستودعات Python في GitHub",
                source_type="github",
                config={
                    "repository": "python/cpython",
                    "path": "Lib",
                    "token": None  # يمكن إضافة token للوصول المحسن
                },
                update_frequency="daily",
                priority=8
            ),
            DataSource(
                source_id="programming_tutorials",
                name="دروس البرمجة",
                source_type="web",
                url="https://docs.python.org/3/tutorial/",
                data_format="text",
                update_frequency="weekly",
                priority=7
            ),
            DataSource(
                source_id="stackoverflow_api",
                name="Stack Overflow API",
                source_type="api",
                url="https://api.stackexchange.com/2.3/questions",
                config={
                    "method": "GET",
                    "headers": {},
                    "params": {
                        "order": "desc",
                        "sort": "activity",
                        "tagged": "python",
                        "site": "stackoverflow"
                    }
                },
                data_format="json",
                update_frequency="hourly",
                priority=9
            )
        ]
        
        # تسجيل المصادر
        for source in sources:
            success = engine.register_data_source(source)
            print(f"تسجيل المصدر {source.source_id}: {'نجح' if success else 'فشل'}")
        
        # بدء الاستيعاب
        await engine.start_ingestion()
        
        # انتظار لمدة دقيقة لمشاهدة العمل
        await asyncio.sleep(60)
        
        # عرض الإحصائيات
        stats = engine.get_ingestion_statistics()
        print(f"إحصائيات الاستيعاب: {json.dumps(stats, indent=2, ensure_ascii=False)}")
        
        # الحصول على بيانات التعلم
        learning_data = engine.get_learning_data_for_seed("test_seed", limit=10)
        print(f"تم الحصول على {len(learning_data)} نقطة تعلم")
        
    except KeyboardInterrupt:
        print("إيقاف البرنامج...")
    finally:
        await engine.stop_ingestion()

if __name__ == "__main__":
    asyncio.run(main())

