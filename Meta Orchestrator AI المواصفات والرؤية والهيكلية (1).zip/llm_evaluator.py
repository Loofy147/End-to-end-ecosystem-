import os
import json
import sqlite3
import asyncio
import aiohttp
from datetime import datetime, timedelta
from typing import Dict, List, Any, Optional, Tuple, Union
from dataclasses import dataclass, asdict
import logging
import time
import hashlib
from enum import Enum

import openai
from openai import AsyncOpenAI

from ai_seed import AISeed, Experience, TaskType, LearningPhase
from ai_seed_challenge_integration import AISeedTrainer

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class EvaluationCriteria(Enum):
    """معايير التقييم"""
    CORRECTNESS = "correctness"
    EFFICIENCY = "efficiency"
    READABILITY = "readability"
    CREATIVITY = "creativity"
    BEST_PRACTICES = "best_practices"
    LEARNING_PROGRESS = "learning_progress"
    PROBLEM_SOLVING = "problem_solving"
    CODE_QUALITY = "code_quality"

class LLMProvider(Enum):
    """مقدمو خدمة LLM"""
    OPENAI_GPT4 = "openai_gpt4"
    OPENAI_GPT4O = "openai_gpt4o"
    OPENAI_GPT35 = "openai_gpt35"
    ANTHROPIC_CLAUDE = "anthropic_claude"
    GOOGLE_GEMINI = "google_gemini"
    LOCAL_MODEL = "local_model"

@dataclass
class EvaluationRequest:
    """طلب التقييم"""
    request_id: str
    seed_id: str
    task_description: str
    seed_solution: str
    expected_output: Optional[str] = None
    context: Dict[str, Any] = None
    criteria: List[EvaluationCriteria] = None
    llm_provider: LLMProvider = LLMProvider.OPENAI_GPT4O
    timestamp: datetime = None

@dataclass
class EvaluationResult:
    """نتيجة التقييم"""
    request_id: str
    seed_id: str
    overall_score: float  # 0.0 - 1.0
    criteria_scores: Dict[str, float]
    detailed_feedback: str
    suggestions: List[str]
    strengths: List[str]
    weaknesses: List[str]
    learning_insights: Dict[str, Any]
    confidence_level: float
    evaluation_time: float
    llm_provider: str
    timestamp: datetime

@dataclass
class LearningAssessment:
    """تقييم التعلم"""
    seed_id: str
    assessment_period: str  # daily, weekly, monthly
    total_evaluations: int
    average_score: float
    improvement_rate: float
    skill_progression: Dict[str, float]
    learning_velocity: float
    consistency_score: float
    challenge_level_progression: Dict[str, int]
    recommendations: List[str]
    timestamp: datetime

class LLMEvaluator:
    """مقيم بواسطة LLM خارجي"""
    
    def __init__(self, orchestrator=None):
        self.orchestrator = orchestrator
        
        # إعداد عملاء LLM
        self.openai_client = None
        self.anthropic_client = None
        self.gemini_client = None
        
        # تهيئة OpenAI
        if os.getenv("OPENAI_API_KEY"):
            self.openai_client = AsyncOpenAI(
                api_key=os.getenv("OPENAI_API_KEY"),
                base_url=os.getenv("OPENAI_API_BASE", "https://api.openai.com/v1")
            )
        
        # إعدادات التقييم
        self.evaluation_config = {
            "default_provider": LLMProvider.OPENAI_GPT4O,
            "max_retries": 3,
            "timeout_seconds": 60,
            "batch_size": 5,
            "evaluation_temperature": 0.3,
            "detailed_feedback": True,
            "multi_provider_consensus": False,
            "cache_evaluations": True
        }
        
        # قاعدة بيانات التقييم
        self.evaluation_db_path = "llm_evaluations.db"
        self.init_evaluation_database()
        
        # ذاكرة التقييم المؤقتة
        self.evaluation_cache = {}
        self.pending_evaluations = asyncio.Queue()
        
        # إحصائيات التقييم
        self.evaluation_stats = {
            "total_evaluations": 0,
            "average_score": 0.0,
            "provider_usage": {},
            "evaluation_time_avg": 0.0,
            "cache_hit_rate": 0.0
        }
        
        # حالة المقيم
        self.is_running = False
        self.evaluation_tasks = []
        
        logger.info("تم تهيئة مقيم LLM")
    
    def init_evaluation_database(self):
        """تهيئة قاعدة بيانات التقييم"""
        with sqlite3.connect(self.evaluation_db_path) as conn:
            # جدول طلبات التقييم
            conn.execute("""
                CREATE TABLE IF NOT EXISTS evaluation_requests (
                    request_id TEXT PRIMARY KEY,
                    seed_id TEXT NOT NULL,
                    task_description TEXT NOT NULL,
                    seed_solution TEXT NOT NULL,
                    expected_output TEXT,
                    context TEXT,
                    criteria TEXT,
                    llm_provider TEXT NOT NULL,
                    timestamp TEXT NOT NULL
                )
            """)
            
            # جدول نتائج التقييم
            conn.execute("""
                CREATE TABLE IF NOT EXISTS evaluation_results (
                    request_id TEXT PRIMARY KEY,
                    seed_id TEXT NOT NULL,
                    overall_score REAL NOT NULL,
                    criteria_scores TEXT NOT NULL,
                    detailed_feedback TEXT NOT NULL,
                    suggestions TEXT,
                    strengths TEXT,
                    weaknesses TEXT,
                    learning_insights TEXT,
                    confidence_level REAL NOT NULL,
                    evaluation_time REAL NOT NULL,
                    llm_provider TEXT NOT NULL,
                    timestamp TEXT NOT NULL
                )
            """)
            
            # جدول تقييمات التعلم
            conn.execute("""
                CREATE TABLE IF NOT EXISTS learning_assessments (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    seed_id TEXT NOT NULL,
                    assessment_period TEXT NOT NULL,
                    total_evaluations INTEGER NOT NULL,
                    average_score REAL NOT NULL,
                    improvement_rate REAL NOT NULL,
                    skill_progression TEXT,
                    learning_velocity REAL NOT NULL,
                    consistency_score REAL NOT NULL,
                    challenge_level_progression TEXT,
                    recommendations TEXT,
                    timestamp TEXT NOT NULL
                )
            """)
            
            # جدول إحصائيات التقييم
            conn.execute("""
                CREATE TABLE IF NOT EXISTS evaluation_statistics (
                    timestamp TEXT PRIMARY KEY,
                    total_evaluations INTEGER,
                    average_score REAL,
                    provider_usage TEXT,
                    evaluation_time_avg REAL,
                    cache_hit_rate REAL
                )
            """)
    
    async def start_evaluator(self):
        """بدء مقيم LLM"""
        if self.is_running:
            logger.warning("مقيم LLM يعمل بالفعل")
            return
        
        self.is_running = True
        logger.info("بدء مقيم LLM")
        
        # بدء معالج التقييمات
        self.evaluation_tasks.append(
            asyncio.create_task(self.evaluation_processor())
        )
        
        # بدء مراقب الإحصائيات
        self.evaluation_tasks.append(
            asyncio.create_task(self.stats_monitor())
        )
    
    async def evaluate_seed_performance(
        self, 
        seed_id: str, 
        task_description: str, 
        seed_solution: str,
        expected_output: Optional[str] = None,
        context: Optional[Dict[str, Any]] = None,
        criteria: Optional[List[EvaluationCriteria]] = None,
        llm_provider: Optional[LLMProvider] = None
    ) -> EvaluationResult:
        """تقييم أداء البذرة"""
        
        # إنشاء طلب التقييم
        request = EvaluationRequest(
            request_id=f"eval_{seed_id}_{datetime.now().strftime('%Y%m%d_%H%M%S')}_{hashlib.md5(seed_solution.encode()).hexdigest()[:8]}",
            seed_id=seed_id,
            task_description=task_description,
            seed_solution=seed_solution,
            expected_output=expected_output,
            context=context or {},
            criteria=criteria or [
                EvaluationCriteria.CORRECTNESS,
                EvaluationCriteria.CODE_QUALITY,
                EvaluationCriteria.LEARNING_PROGRESS
            ],
            llm_provider=llm_provider or self.evaluation_config["default_provider"],
            timestamp=datetime.now()
        )
        
        # فحص الذاكرة المؤقتة
        if self.evaluation_config["cache_evaluations"]:
            cached_result = self.get_cached_evaluation(request)
            if cached_result:
                logger.info(f"استخدام تقييم مخزن مؤقتاً: {request.request_id}")
                return cached_result
        
        # حفظ الطلب
        self.save_evaluation_request(request)
        
        # تنفيذ التقييم
        result = await self.perform_evaluation(request)
        
        # حفظ النتيجة
        self.save_evaluation_result(result)
        
        # تحديث الذاكرة المؤقتة
        if self.evaluation_config["cache_evaluations"]:
            self.cache_evaluation(request, result)
        
        # تحديث الإحصائيات
        self.update_evaluation_stats(result)
        
        logger.info(f"تم تقييم البذرة {seed_id}: {result.overall_score:.2f}")
        return result
    
    def get_cached_evaluation(self, request: EvaluationRequest) -> Optional[EvaluationResult]:
        """الحصول على تقييم مخزن مؤقتاً"""
        try:
            # إنشاء مفتاح الذاكرة المؤقتة
            cache_key = self.generate_cache_key(request)
            
            # البحث في الذاكرة المؤقتة
            if cache_key in self.evaluation_cache:
                cached_data = self.evaluation_cache[cache_key]
                
                # فحص انتهاء الصلاحية (24 ساعة)
                if datetime.now() - cached_data["timestamp"] < timedelta(hours=24):
                    return cached_data["result"]
                else:
                    # إزالة التقييم المنتهي الصلاحية
                    del self.evaluation_cache[cache_key]
            
            return None
            
        except Exception as e:
            logger.error(f"خطأ في الحصول على التقييم المخزن: {e}")
            return None
    
    def generate_cache_key(self, request: EvaluationRequest) -> str:
        """توليد مفتاح الذاكرة المؤقتة"""
        # استخدام hash للحل والمهمة
        content = f"{request.task_description}_{request.seed_solution}_{request.llm_provider.value}"
        return hashlib.sha256(content.encode()).hexdigest()
    
    def cache_evaluation(self, request: EvaluationRequest, result: EvaluationResult):
        """تخزين التقييم في الذاكرة المؤقتة"""
        try:
            cache_key = self.generate_cache_key(request)
            self.evaluation_cache[cache_key] = {
                "result": result,
                "timestamp": datetime.now()
            }
            
            # تنظيف الذاكرة المؤقتة إذا كانت كبيرة
            if len(self.evaluation_cache) > 1000:
                self.cleanup_cache()
                
        except Exception as e:
            logger.error(f"خطأ في تخزين التقييم: {e}")
    
    def cleanup_cache(self):
        """تنظيف الذاكرة المؤقتة"""
        try:
            current_time = datetime.now()
            expired_keys = []
            
            for key, data in self.evaluation_cache.items():
                if current_time - data["timestamp"] > timedelta(hours=24):
                    expired_keys.append(key)
            
            for key in expired_keys:
                del self.evaluation_cache[key]
            
            logger.info(f"تم تنظيف {len(expired_keys)} تقييم منتهي الصلاحية من الذاكرة المؤقتة")
            
        except Exception as e:
            logger.error(f"خطأ في تنظيف الذاكرة المؤقتة: {e}")
    
    async def perform_evaluation(self, request: EvaluationRequest) -> EvaluationResult:
        """تنفيذ التقييم الفعلي"""
        start_time = time.time()
        
        try:
            if request.llm_provider in [LLMProvider.OPENAI_GPT4, LLMProvider.OPENAI_GPT4O, LLMProvider.OPENAI_GPT35]:
                result = await self.evaluate_with_openai(request)
            elif request.llm_provider == LLMProvider.ANTHROPIC_CLAUDE:
                result = await self.evaluate_with_anthropic(request)
            elif request.llm_provider == LLMProvider.GOOGLE_GEMINI:
                result = await self.evaluate_with_gemini(request)
            else:
                # استخدام OpenAI كافتراضي
                result = await self.evaluate_with_openai(request)
            
            # حساب وقت التقييم
            evaluation_time = time.time() - start_time
            result.evaluation_time = evaluation_time
            
            return result
            
        except Exception as e:
            logger.error(f"خطأ في تنفيذ التقييم: {e}")
            
            # إنشاء نتيجة افتراضية في حالة الخطأ
            return EvaluationResult(
                request_id=request.request_id,
                seed_id=request.seed_id,
                overall_score=0.0,
                criteria_scores={},
                detailed_feedback=f"خطأ في التقييم: {e}",
                suggestions=[],
                strengths=[],
                weaknesses=["فشل في التقييم"],
                learning_insights={},
                confidence_level=0.0,
                evaluation_time=time.time() - start_time,
                llm_provider=request.llm_provider.value,
                timestamp=datetime.now()
            )
    
    async def evaluate_with_openai(self, request: EvaluationRequest) -> EvaluationResult:
        """التقييم باستخدام OpenAI"""
        if not self.openai_client:
            raise ValueError("عميل OpenAI غير مهيأ")
        
        # تحديد النموذج
        model_map = {
            LLMProvider.OPENAI_GPT4: "gpt-4",
            LLMProvider.OPENAI_GPT4O: "gpt-4o",
            LLMProvider.OPENAI_GPT35: "gpt-3.5-turbo"
        }
        model = model_map.get(request.llm_provider, "gpt-4o")
        
        # بناء البرومبت
        evaluation_prompt = self.build_evaluation_prompt(request)
        
        try:
            # استدعاء OpenAI API
            response = await self.openai_client.chat.completions.create(
                model=model,
                messages=[
                    {
                        "role": "system",
                        "content": "أنت خبير في تقييم أداء أنظمة الذكاء الاصطناعي وجودة الكود البرمجي. مهمتك تقييم أداء بذرة ذكاء اصطناعي صغيرة وتقديم تغذية راجعة مفصلة وبناءة."
                    },
                    {
                        "role": "user",
                        "content": evaluation_prompt
                    }
                ],
                temperature=self.evaluation_config["evaluation_temperature"],
                max_tokens=2000
            )
            
            # استخراج النتيجة
            evaluation_text = response.choices[0].message.content
            
            # تحليل النتيجة
            result = self.parse_evaluation_response(evaluation_text, request)
            
            return result
            
        except Exception as e:
            logger.error(f"خطأ في استدعاء OpenAI API: {e}")
            raise
    
    async def evaluate_with_anthropic(self, request: EvaluationRequest) -> EvaluationResult:
        """التقييم باستخدام Anthropic Claude"""
        # يمكن تنفيذ هذا لاحقاً عند توفر مفتاح API
        raise NotImplementedError("تقييم Anthropic غير مُنفذ بعد")
    
    async def evaluate_with_gemini(self, request: EvaluationRequest) -> EvaluationResult:
        """التقييم باستخدام Google Gemini"""
        # يمكن تنفيذ هذا لاحقاً عند توفر مفتاح API
        raise NotImplementedError("تقييم Gemini غير مُنفذ بعد")
    
    def build_evaluation_prompt(self, request: EvaluationRequest) -> str:
        """بناء برومبت التقييم"""
        criteria_descriptions = {
            EvaluationCriteria.CORRECTNESS: "صحة الحل ومطابقته للمتطلبات",
            EvaluationCriteria.EFFICIENCY: "كفاءة الحل من ناحية الوقت والذاكرة",
            EvaluationCriteria.READABILITY: "وضوح الكود وسهولة قراءته",
            EvaluationCriteria.CREATIVITY: "الإبداع والابتكار في الحل",
            EvaluationCriteria.BEST_PRACTICES: "اتباع أفضل الممارسات البرمجية",
            EvaluationCriteria.LEARNING_PROGRESS: "مدى التقدم في التعلم",
            EvaluationCriteria.PROBLEM_SOLVING: "مهارات حل المشكلات",
            EvaluationCriteria.CODE_QUALITY: "جودة الكود الإجمالية"
        }
        
        criteria_list = "\n".join([
            f"- {criteria.value}: {criteria_descriptions[criteria]}"
            for criteria in request.criteria
        ])
        
        prompt = f"""
قم بتقييم أداء بذرة الذكاء الاصطناعي التالية:

**معرف البذرة:** {request.seed_id}

**وصف المهمة:**
{request.task_description}

**حل البذرة:**
```
{request.seed_solution}
```

**المخرجات المتوقعة (إن وجدت):**
{request.expected_output or "غير محدد"}

**السياق الإضافي:**
{json.dumps(request.context, ensure_ascii=False, indent=2) if request.context else "لا يوجد"}

**معايير التقييم:**
{criteria_list}

**المطلوب:**
قدم تقييماً شاملاً ومفصلاً يتضمن:

1. **النقاط الإجمالية** (من 0 إلى 100):
2. **نقاط كل معيار** (من 0 إلى 100 لكل معيار):
3. **التغذية الراجعة المفصلة**: تحليل شامل للحل
4. **نقاط القوة**: ما يميز هذا الحل
5. **نقاط الضعف**: المجالات التي تحتاج تحسين
6. **اقتراحات التحسين**: توصيات محددة وقابلة للتطبيق
7. **رؤى التعلم**: ما يمكن أن تتعلمه البذرة من هذه التجربة
8. **مستوى الثقة**: مدى ثقتك في هذا التقييم (من 0 إلى 100)

**تنسيق الإجابة:**
استخدم تنسيق JSON التالي:
```json
{{
    "overall_score": <النقاط الإجمالية>,
    "criteria_scores": {{
        "<معيار1>": <النقاط>,
        "<معيار2>": <النقاط>
    }},
    "detailed_feedback": "<التغذية الراجعة المفصلة>",
    "strengths": ["<نقطة قوة 1>", "<نقطة قوة 2>"],
    "weaknesses": ["<نقطة ضعف 1>", "<نقطة ضعف 2>"],
    "suggestions": ["<اقتراح 1>", "<اقتراح 2>"],
    "learning_insights": {{
        "key_concepts": ["<مفهوم 1>", "<مفهوم 2>"],
        "improvement_areas": ["<مجال 1>", "<مجال 2>"],
        "next_challenges": ["<تحدي 1>", "<تحدي 2>"]
    }},
    "confidence_level": <مستوى الثقة>
}}
```

كن دقيقاً وبناءً في تقييمك، واهتم بتقديم تغذية راجعة تساعد البذرة على التعلم والتحسن.
"""
        
        return prompt
    
    def parse_evaluation_response(self, response_text: str, request: EvaluationRequest) -> EvaluationResult:
        """تحليل استجابة التقييم"""
        try:
            # البحث عن JSON في النص
            start_idx = response_text.find('{')
            end_idx = response_text.rfind('}') + 1
            
            if start_idx == -1 or end_idx == 0:
                raise ValueError("لم يتم العثور على JSON في الاستجابة")
            
            json_text = response_text[start_idx:end_idx]
            evaluation_data = json.loads(json_text)
            
            # تحويل النقاط إلى نطاق 0-1
            overall_score = evaluation_data.get("overall_score", 0) / 100.0
            criteria_scores = {
                criteria: score / 100.0 
                for criteria, score in evaluation_data.get("criteria_scores", {}).items()
            }
            confidence_level = evaluation_data.get("confidence_level", 0) / 100.0
            
            # إنشاء نتيجة التقييم
            result = EvaluationResult(
                request_id=request.request_id,
                seed_id=request.seed_id,
                overall_score=overall_score,
                criteria_scores=criteria_scores,
                detailed_feedback=evaluation_data.get("detailed_feedback", ""),
                suggestions=evaluation_data.get("suggestions", []),
                strengths=evaluation_data.get("strengths", []),
                weaknesses=evaluation_data.get("weaknesses", []),
                learning_insights=evaluation_data.get("learning_insights", {}),
                confidence_level=confidence_level,
                evaluation_time=0.0,  # سيتم تحديثه لاحقاً
                llm_provider=request.llm_provider.value,
                timestamp=datetime.now()
            )
            
            return result
            
        except Exception as e:
            logger.error(f"خطأ في تحليل استجابة التقييم: {e}")
            
            # محاولة استخراج تقييم أساسي من النص
            return self.extract_basic_evaluation(response_text, request)
    
    def extract_basic_evaluation(self, response_text: str, request: EvaluationRequest) -> EvaluationResult:
        """استخراج تقييم أساسي من النص"""
        try:
            # تقييم أساسي بناءً على طول النص ووجود كلمات إيجابية
            positive_words = ["جيد", "ممتاز", "صحيح", "فعال", "مناسب", "good", "excellent", "correct"]
            negative_words = ["خطأ", "ضعيف", "غير صحيح", "سيء", "error", "wrong", "poor", "bad"]
            
            positive_count = sum(1 for word in positive_words if word in response_text.lower())
            negative_count = sum(1 for word in negative_words if word in response_text.lower())
            
            # حساب نقاط أساسية
            base_score = 0.5
            if positive_count > negative_count:
                base_score += 0.3
            elif negative_count > positive_count:
                base_score -= 0.3
            
            base_score = max(0.0, min(1.0, base_score))
            
            return EvaluationResult(
                request_id=request.request_id,
                seed_id=request.seed_id,
                overall_score=base_score,
                criteria_scores={criteria.value: base_score for criteria in request.criteria},
                detailed_feedback=response_text,
                suggestions=["تحسين جودة الكود", "مراجعة المنطق"],
                strengths=["محاولة جيدة"],
                weaknesses=["يحتاج تحسين"],
                learning_insights={"basic_feedback": True},
                confidence_level=0.3,
                evaluation_time=0.0,
                llm_provider=request.llm_provider.value,
                timestamp=datetime.now()
            )
            
        except Exception as e:
            logger.error(f"خطأ في استخراج التقييم الأساسي: {e}")
            
            # تقييم افتراضي في حالة الفشل الكامل
            return EvaluationResult(
                request_id=request.request_id,
                seed_id=request.seed_id,
                overall_score=0.5,
                criteria_scores={criteria.value: 0.5 for criteria in request.criteria},
                detailed_feedback="تم إنشاء تقييم افتراضي بسبب خطأ في التحليل",
                suggestions=[],
                strengths=[],
                weaknesses=[],
                learning_insights={},
                confidence_level=0.1,
                evaluation_time=0.0,
                llm_provider=request.llm_provider.value,
                timestamp=datetime.now()
            )
    
    def save_evaluation_request(self, request: EvaluationRequest):
        """حفظ طلب التقييم"""
        with sqlite3.connect(self.evaluation_db_path) as conn:
            conn.execute("""
                INSERT OR REPLACE INTO evaluation_requests 
                (request_id, seed_id, task_description, seed_solution, expected_output,
                 context, criteria, llm_provider, timestamp)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                request.request_id,
                request.seed_id,
                request.task_description,
                request.seed_solution,
                request.expected_output,
                json.dumps(request.context or {}),
                json.dumps([c.value for c in request.criteria]),
                request.llm_provider.value,
                request.timestamp.isoformat()
            ))
    
    def save_evaluation_result(self, result: EvaluationResult):
        """حفظ نتيجة التقييم"""
        with sqlite3.connect(self.evaluation_db_path) as conn:
            conn.execute("""
                INSERT OR REPLACE INTO evaluation_results 
                (request_id, seed_id, overall_score, criteria_scores, detailed_feedback,
                 suggestions, strengths, weaknesses, learning_insights, confidence_level,
                 evaluation_time, llm_provider, timestamp)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                result.request_id,
                result.seed_id,
                result.overall_score,
                json.dumps(result.criteria_scores),
                result.detailed_feedback,
                json.dumps(result.suggestions),
                json.dumps(result.strengths),
                json.dumps(result.weaknesses),
                json.dumps(result.learning_insights),
                result.confidence_level,
                result.evaluation_time,
                result.llm_provider,
                result.timestamp.isoformat()
            ))
    
    async def generate_learning_assessment(self, seed_id: str, period: str = "weekly") -> LearningAssessment:
        """توليد تقييم التعلم للبذرة"""
        try:
            # تحديد الفترة الزمنية
            if period == "daily":
                start_date = datetime.now() - timedelta(days=1)
            elif period == "weekly":
                start_date = datetime.now() - timedelta(weeks=1)
            elif period == "monthly":
                start_date = datetime.now() - timedelta(days=30)
            else:
                start_date = datetime.now() - timedelta(weeks=1)
            
            # جلب التقييمات من قاعدة البيانات
            evaluations = self.get_seed_evaluations(seed_id, start_date)
            
            if not evaluations:
                logger.warning(f"لا توجد تقييمات للبذرة {seed_id} في الفترة المحددة")
                return self.create_empty_assessment(seed_id, period)
            
            # حساب الإحصائيات
            total_evaluations = len(evaluations)
            scores = [eval_data["overall_score"] for eval_data in evaluations]
            average_score = sum(scores) / len(scores)
            
            # حساب معدل التحسن
            improvement_rate = 0.0
            if len(scores) > 1:
                first_half = scores[:len(scores)//2]
                second_half = scores[len(scores)//2:]
                if first_half and second_half:
                    improvement_rate = (sum(second_half)/len(second_half)) - (sum(first_half)/len(first_half))
            
            # تحليل تقدم المهارات
            skill_progression = self.analyze_skill_progression(evaluations)
            
            # حساب سرعة التعلم
            learning_velocity = self.calculate_learning_velocity(evaluations)
            
            # حساب نقاط الثبات
            consistency_score = self.calculate_consistency_score(scores)
            
            # تحليل تقدم مستوى التحدي
            challenge_progression = self.analyze_challenge_progression(evaluations)
            
            # توليد التوصيات
            recommendations = await self.generate_recommendations(seed_id, evaluations, average_score, improvement_rate)
            
            # إنشاء التقييم
            assessment = LearningAssessment(
                seed_id=seed_id,
                assessment_period=period,
                total_evaluations=total_evaluations,
                average_score=average_score,
                improvement_rate=improvement_rate,
                skill_progression=skill_progression,
                learning_velocity=learning_velocity,
                consistency_score=consistency_score,
                challenge_level_progression=challenge_progression,
                recommendations=recommendations,
                timestamp=datetime.now()
            )
            
            # حفظ التقييم
            self.save_learning_assessment(assessment)
            
            return assessment
            
        except Exception as e:
            logger.error(f"خطأ في توليد تقييم التعلم: {e}")
            return self.create_empty_assessment(seed_id, period)
    
    def get_seed_evaluations(self, seed_id: str, start_date: datetime) -> List[Dict[str, Any]]:
        """جلب تقييمات البذرة من قاعدة البيانات"""
        try:
            with sqlite3.connect(self.evaluation_db_path) as conn:
                cursor = conn.execute("""
                    SELECT * FROM evaluation_results 
                    WHERE seed_id = ? AND timestamp >= ?
                    ORDER BY timestamp ASC
                """, (seed_id, start_date.isoformat()))
                
                evaluations = []
                for row in cursor.fetchall():
                    columns = [desc[0] for desc in cursor.description]
                    eval_data = dict(zip(columns, row))
                    
                    # تحويل JSON strings
                    eval_data["criteria_scores"] = json.loads(eval_data["criteria_scores"])
                    eval_data["suggestions"] = json.loads(eval_data["suggestions"])
                    eval_data["strengths"] = json.loads(eval_data["strengths"])
                    eval_data["weaknesses"] = json.loads(eval_data["weaknesses"])
                    eval_data["learning_insights"] = json.loads(eval_data["learning_insights"])
                    
                    evaluations.append(eval_data)
                
                return evaluations
                
        except Exception as e:
            logger.error(f"خطأ في جلب تقييمات البذرة: {e}")
            return []
    
    def analyze_skill_progression(self, evaluations: List[Dict[str, Any]]) -> Dict[str, float]:
        """تحليل تقدم المهارات"""
        try:
            skill_scores = {}
            
            for evaluation in evaluations:
                criteria_scores = evaluation["criteria_scores"]
                for skill, score in criteria_scores.items():
                    if skill not in skill_scores:
                        skill_scores[skill] = []
                    skill_scores[skill].append(score)
            
            # حساب التقدم لكل مهارة
            skill_progression = {}
            for skill, scores in skill_scores.items():
                if len(scores) > 1:
                    # حساب الاتجاه العام
                    first_half_avg = sum(scores[:len(scores)//2]) / len(scores[:len(scores)//2])
                    second_half_avg = sum(scores[len(scores)//2:]) / len(scores[len(scores)//2:])
                    progression = second_half_avg - first_half_avg
                else:
                    progression = 0.0
                
                skill_progression[skill] = progression
            
            return skill_progression
            
        except Exception as e:
            logger.error(f"خطأ في تحليل تقدم المهارات: {e}")
            return {}
    
    def calculate_learning_velocity(self, evaluations: List[Dict[str, Any]]) -> float:
        """حساب سرعة التعلم"""
        try:
            if len(evaluations) < 2:
                return 0.0
            
            # حساب التحسن عبر الوقت
            scores = [eval_data["overall_score"] for eval_data in evaluations]
            timestamps = [datetime.fromisoformat(eval_data["timestamp"]) for eval_data in evaluations]
            
            # حساب معدل التغيير
            total_improvement = scores[-1] - scores[0]
            total_time = (timestamps[-1] - timestamps[0]).total_seconds() / 3600  # بالساعات
            
            if total_time > 0:
                velocity = total_improvement / total_time  # تحسن في الساعة
            else:
                velocity = 0.0
            
            return velocity
            
        except Exception as e:
            logger.error(f"خطأ في حساب سرعة التعلم: {e}")
            return 0.0
    
    def calculate_consistency_score(self, scores: List[float]) -> float:
        """حساب نقاط الثبات"""
        try:
            if len(scores) < 2:
                return 1.0
            
            # حساب الانحراف المعياري
            mean_score = sum(scores) / len(scores)
            variance = sum((score - mean_score) ** 2 for score in scores) / len(scores)
            std_deviation = variance ** 0.5
            
            # تحويل إلى نقاط ثبات (كلما قل الانحراف، زاد الثبات)
            consistency = max(0.0, 1.0 - std_deviation)
            
            return consistency
            
        except Exception as e:
            logger.error(f"خطأ في حساب نقاط الثبات: {e}")
            return 0.5
    
    def analyze_challenge_progression(self, evaluations: List[Dict[str, Any]]) -> Dict[str, int]:
        """تحليل تقدم مستوى التحدي"""
        try:
            # يمكن تحسين هذا بربطه مع نظام التحديات
            # للآن، نحلل بناءً على تعقيد المهام
            
            challenge_levels = {"beginner": 0, "intermediate": 0, "advanced": 0, "expert": 0}
            
            for evaluation in evaluations:
                # تحديد مستوى التحدي بناءً على النقاط
                score = evaluation["overall_score"]
                if score < 0.4:
                    challenge_levels["beginner"] += 1
                elif score < 0.6:
                    challenge_levels["intermediate"] += 1
                elif score < 0.8:
                    challenge_levels["advanced"] += 1
                else:
                    challenge_levels["expert"] += 1
            
            return challenge_levels
            
        except Exception as e:
            logger.error(f"خطأ في تحليل تقدم التحدي: {e}")
            return {}
    
    async def generate_recommendations(
        self, 
        seed_id: str, 
        evaluations: List[Dict[str, Any]], 
        average_score: float, 
        improvement_rate: float
    ) -> List[str]:
        """توليد التوصيات للبذرة"""
        try:
            recommendations = []
            
            # تحليل الأداء العام
            if average_score < 0.4:
                recommendations.append("التركيز على المفاهيم الأساسية والتدريب على مهام بسيطة")
            elif average_score < 0.6:
                recommendations.append("زيادة التدريب على مهام متوسطة الصعوبة")
            elif average_score < 0.8:
                recommendations.append("التحدي بمهام أكثر تعقيداً وتنوعاً")
            else:
                recommendations.append("الحفاظ على المستوى العالي والتركيز على الإبداع")
            
            # تحليل معدل التحسن
            if improvement_rate < -0.1:
                recommendations.append("مراجعة استراتيجية التعلم - هناك تراجع في الأداء")
            elif improvement_rate < 0.05:
                recommendations.append("تنويع أساليب التدريب لتحفيز التحسن")
            else:
                recommendations.append("الاستمرار في النهج الحالي - التقدم جيد")
            
            # تحليل نقاط الضعف الشائعة
            common_weaknesses = {}
            for evaluation in evaluations:
                for weakness in evaluation["weaknesses"]:
                    common_weaknesses[weakness] = common_weaknesses.get(weakness, 0) + 1
            
            # إضافة توصيات للنقاط الأكثر ضعفاً
            if common_weaknesses:
                most_common = max(common_weaknesses.items(), key=lambda x: x[1])
                recommendations.append(f"التركيز على تحسين: {most_common[0]}")
            
            # تحليل المهارات
            if evaluations:
                latest_eval = evaluations[-1]
                criteria_scores = latest_eval["criteria_scores"]
                
                # العثور على أضعف مهارة
                if criteria_scores:
                    weakest_skill = min(criteria_scores.items(), key=lambda x: x[1])
                    if weakest_skill[1] < 0.5:
                        recommendations.append(f"تحسين مهارة: {weakest_skill[0]}")
            
            return recommendations
            
        except Exception as e:
            logger.error(f"خطأ في توليد التوصيات: {e}")
            return ["مراجعة الأداء العام وتحسين نقاط الضعف"]
    
    def create_empty_assessment(self, seed_id: str, period: str) -> LearningAssessment:
        """إنشاء تقييم فارغ"""
        return LearningAssessment(
            seed_id=seed_id,
            assessment_period=period,
            total_evaluations=0,
            average_score=0.0,
            improvement_rate=0.0,
            skill_progression={},
            learning_velocity=0.0,
            consistency_score=0.0,
            challenge_level_progression={},
            recommendations=["بدء التدريب وجمع البيانات"],
            timestamp=datetime.now()
        )
    
    def save_learning_assessment(self, assessment: LearningAssessment):
        """حفظ تقييم التعلم"""
        with sqlite3.connect(self.evaluation_db_path) as conn:
            conn.execute("""
                INSERT INTO learning_assessments 
                (seed_id, assessment_period, total_evaluations, average_score,
                 improvement_rate, skill_progression, learning_velocity, consistency_score,
                 challenge_level_progression, recommendations, timestamp)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                assessment.seed_id,
                assessment.assessment_period,
                assessment.total_evaluations,
                assessment.average_score,
                assessment.improvement_rate,
                json.dumps(assessment.skill_progression),
                assessment.learning_velocity,
                assessment.consistency_score,
                json.dumps(assessment.challenge_level_progression),
                json.dumps(assessment.recommendations),
                assessment.timestamp.isoformat()
            ))
    
    def update_evaluation_stats(self, result: EvaluationResult):
        """تحديث إحصائيات التقييم"""
        try:
            self.evaluation_stats["total_evaluations"] += 1
            
            # تحديث متوسط النقاط
            current_avg = self.evaluation_stats["average_score"]
            total_evals = self.evaluation_stats["total_evaluations"]
            new_avg = (current_avg * (total_evals - 1) + result.overall_score) / total_evals
            self.evaluation_stats["average_score"] = new_avg
            
            # تحديث استخدام المقدمين
            provider = result.llm_provider
            if provider not in self.evaluation_stats["provider_usage"]:
                self.evaluation_stats["provider_usage"][provider] = 0
            self.evaluation_stats["provider_usage"][provider] += 1
            
            # تحديث متوسط وقت التقييم
            current_time_avg = self.evaluation_stats["evaluation_time_avg"]
            new_time_avg = (current_time_avg * (total_evals - 1) + result.evaluation_time) / total_evals
            self.evaluation_stats["evaluation_time_avg"] = new_time_avg
            
        except Exception as e:
            logger.error(f"خطأ في تحديث إحصائيات التقييم: {e}")
    
    async def evaluation_processor(self):
        """معالج التقييمات المعلقة"""
        while self.is_running:
            try:
                # انتظار طلب تقييم
                request = await asyncio.wait_for(
                    self.pending_evaluations.get(),
                    timeout=10.0
                )
                
                # تنفيذ التقييم
                result = await self.perform_evaluation(request)
                
                # حفظ النتيجة
                self.save_evaluation_result(result)
                
                # تحديث الإحصائيات
                self.update_evaluation_stats(result)
                
            except asyncio.TimeoutError:
                # لا توجد طلبات معلقة
                continue
            except Exception as e:
                logger.error(f"خطأ في معالج التقييمات: {e}")
                await asyncio.sleep(5)
    
    async def stats_monitor(self):
        """مراقب الإحصائيات"""
        while self.is_running:
            try:
                # حفظ الإحصائيات كل 10 دقائق
                await asyncio.sleep(600)
                
                with sqlite3.connect(self.evaluation_db_path) as conn:
                    conn.execute("""
                        INSERT INTO evaluation_statistics 
                        (timestamp, total_evaluations, average_score, provider_usage,
                         evaluation_time_avg, cache_hit_rate)
                        VALUES (?, ?, ?, ?, ?, ?)
                    """, (
                        datetime.now().isoformat(),
                        self.evaluation_stats["total_evaluations"],
                        self.evaluation_stats["average_score"],
                        json.dumps(self.evaluation_stats["provider_usage"]),
                        self.evaluation_stats["evaluation_time_avg"],
                        self.evaluation_stats["cache_hit_rate"]
                    ))
                
            except Exception as e:
                logger.error(f"خطأ في مراقب الإحصائيات: {e}")
    
    async def stop_evaluator(self):
        """إيقاف مقيم LLM"""
        logger.info("إيقاف مقيم LLM")
        
        self.is_running = False
        
        # إلغاء جميع المهام
        for task in self.evaluation_tasks:
            task.cancel()
        
        # انتظار انتهاء المهام
        if self.evaluation_tasks:
            await asyncio.gather(*self.evaluation_tasks, return_exceptions=True)
        
        logger.info("تم إيقاف مقيم LLM")
    
    def get_evaluation_statistics(self) -> Dict[str, Any]:
        """الحصول على إحصائيات التقييم"""
        try:
            with sqlite3.connect(self.evaluation_db_path) as conn:
                # إحصائيات عامة
                cursor = conn.execute("""
                    SELECT 
                        COUNT(*) as total_evaluations,
                        AVG(overall_score) as avg_score,
                        AVG(confidence_level) as avg_confidence,
                        AVG(evaluation_time) as avg_time
                    FROM evaluation_results
                """)
                general_stats = cursor.fetchone()
                
                # إحصائيات المقدمين
                cursor = conn.execute("""
                    SELECT 
                        llm_provider,
                        COUNT(*) as count,
                        AVG(overall_score) as avg_score
                    FROM evaluation_results
                    GROUP BY llm_provider
                """)
                provider_stats = cursor.fetchall()
                
                # أفضل البذور
                cursor = conn.execute("""
                    SELECT 
                        seed_id,
                        COUNT(*) as evaluation_count,
                        AVG(overall_score) as avg_score,
                        MAX(overall_score) as best_score
                    FROM evaluation_results
                    GROUP BY seed_id
                    ORDER BY avg_score DESC
                    LIMIT 10
                """)
                top_seeds = cursor.fetchall()
                
                return {
                    "general": {
                        "total_evaluations": general_stats[0] or 0,
                        "average_score": general_stats[1] or 0.0,
                        "average_confidence": general_stats[2] or 0.0,
                        "average_evaluation_time": general_stats[3] or 0.0
                    },
                    "providers": [
                        {
                            "provider": row[0],
                            "count": row[1],
                            "average_score": row[2]
                        }
                        for row in provider_stats
                    ],
                    "top_seeds": [
                        {
                            "seed_id": row[0],
                            "evaluation_count": row[1],
                            "average_score": row[2],
                            "best_score": row[3]
                        }
                        for row in top_seeds
                    ],
                    "current_stats": self.evaluation_stats,
                    "cache_size": len(self.evaluation_cache)
                }
                
        except Exception as e:
            logger.error(f"خطأ في الحصول على إحصائيات التقييم: {e}")
            return {}

# مثال على الاستخدام
async def main():
    """مثال على الاستخدام"""
    evaluator = LLMEvaluator()
    
    try:
        # بدء المقيم
        await evaluator.start_evaluator()
        
        # مثال على تقييم بذرة
        result = await evaluator.evaluate_seed_performance(
            seed_id="test_seed_001",
            task_description="كتابة دالة لحساب العدد الأولي",
            seed_solution="""
def is_prime(n):
    if n < 2:
        return False
    for i in range(2, int(n**0.5) + 1):
        if n % i == 0:
            return False
    return True
            """,
            expected_output="True for prime numbers, False otherwise",
            criteria=[
                EvaluationCriteria.CORRECTNESS,
                EvaluationCriteria.EFFICIENCY,
                EvaluationCriteria.CODE_QUALITY
            ]
        )
        
        print(f"نتيجة التقييم: {result.overall_score:.2f}")
        print(f"التغذية الراجعة: {result.detailed_feedback}")
        
        # توليد تقييم التعلم
        assessment = await evaluator.generate_learning_assessment("test_seed_001", "weekly")
        print(f"تقييم التعلم: متوسط النقاط {assessment.average_score:.2f}")
        
        # عرض الإحصائيات
        stats = evaluator.get_evaluation_statistics()
        print(f"إحصائيات التقييم: {json.dumps(stats, indent=2, ensure_ascii=False)}")
        
    except KeyboardInterrupt:
        print("إيقاف البرنامج...")
    finally:
        await evaluator.stop_evaluator()

if __name__ == "__main__":
    asyncio.run(main())

