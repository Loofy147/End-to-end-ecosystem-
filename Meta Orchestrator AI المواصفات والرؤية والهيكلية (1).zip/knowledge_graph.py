import networkx as nx
import json
import ast
import os
import re
from typing import Dict, List, Any, Tuple, Optional
from dataclasses import dataclass
from datetime import datetime
import sqlite3

@dataclass
class Entity:
    id: str
    type: str  # 'function', 'class', 'module', 'requirement', 'test', 'bug', etc.
    name: str
    properties: Dict[str, Any]
    created_at: str = ""

@dataclass
class Relationship:
    source_id: str
    target_id: str
    relationship_type: str  # 'calls', 'implements', 'tests', 'depends_on', etc.
    properties: Dict[str, Any]
    created_at: str = ""

class KnowledgeGraph:
    """
    Knowledge Graph for Meta Orchestrator AI
    Stores entities, relationships, context, logic, and outcomes
    """
    
    def __init__(self, db_path: str = "knowledge_graph.db"):
        self.graph = nx.DiGraph()
        self.db_path = db_path
        self.init_database()
    
    def init_database(self):
        """Initialize the Knowledge Graph database"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        # Entities table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS entities (
                id TEXT PRIMARY KEY,
                type TEXT NOT NULL,
                name TEXT NOT NULL,
                properties TEXT,
                created_at TEXT
            )
        ''')
        
        # Relationships table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS relationships (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                source_id TEXT,
                target_id TEXT,
                relationship_type TEXT,
                properties TEXT,
                created_at TEXT,
                FOREIGN KEY (source_id) REFERENCES entities (id),
                FOREIGN KEY (target_id) REFERENCES entities (id)
            )
        ''')
        
        # Outcomes table (for learning from results)
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS outcomes (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                entity_id TEXT,
                outcome_type TEXT,  -- 'test_result', 'static_analysis', 'performance', etc.
                outcome_data TEXT,
                timestamp TEXT,
                FOREIGN KEY (entity_id) REFERENCES entities (id)
            )
        ''')
        
        conn.commit()
        conn.close()
    
    def add_entity(self, entity: Entity) -> bool:
        """Add an entity to the knowledge graph"""
        try:
            entity.created_at = datetime.now().isoformat()
            
            # Add to NetworkX graph
            self.graph.add_node(entity.id, **{
                'type': entity.type,
                'name': entity.name,
                'properties': entity.properties,
                'created_at': entity.created_at
            })
            
            # Add to database
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            cursor.execute('''
                INSERT OR REPLACE INTO entities (id, type, name, properties, created_at)
                VALUES (?, ?, ?, ?, ?)
            ''', (entity.id, entity.type, entity.name, json.dumps(entity.properties), entity.created_at))
            conn.commit()
            conn.close()
            
            return True
        except Exception as e:
            print(f"Error adding entity: {e}")
            return False
    
    def add_relationship(self, relationship: Relationship) -> bool:
        """Add a relationship to the knowledge graph"""
        try:
            relationship.created_at = datetime.now().isoformat()
            
            # Add to NetworkX graph
            self.graph.add_edge(
                relationship.source_id,
                relationship.target_id,
                relationship_type=relationship.relationship_type,
                properties=relationship.properties,
                created_at=relationship.created_at
            )
            
            # Add to database
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            cursor.execute('''
                INSERT INTO relationships (source_id, target_id, relationship_type, properties, created_at)
                VALUES (?, ?, ?, ?, ?)
            ''', (relationship.source_id, relationship.target_id, relationship.relationship_type, 
                  json.dumps(relationship.properties), relationship.created_at))
            conn.commit()
            conn.close()
            
            return True
        except Exception as e:
            print(f"Error adding relationship: {e}")
            return False
    
    def parse_python_file(self, file_path: str) -> List[Entity]:
        """Parse a Python file and extract entities (functions, classes, etc.)"""
        entities = []
        
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                content = f.read()
            
            tree = ast.parse(content)
            
            # Extract module entity
            module_name = os.path.basename(file_path).replace('.py', '')
            module_entity = Entity(
                id=f"module_{module_name}",
                type="module",
                name=module_name,
                properties={
                    "file_path": file_path,
                    "content_hash": hash(content),
                    "line_count": len(content.split('\n'))
                }
            )
            entities.append(module_entity)
            
            # Extract functions and classes
            for node in ast.walk(tree):
                if isinstance(node, ast.FunctionDef):
                    func_entity = Entity(
                        id=f"function_{module_name}_{node.name}",
                        type="function",
                        name=node.name,
                        properties={
                            "module": module_name,
                            "line_number": node.lineno,
                            "args": [arg.arg for arg in node.args.args],
                            "docstring": ast.get_docstring(node),
                            "is_async": isinstance(node, ast.AsyncFunctionDef)
                        }
                    )
                    entities.append(func_entity)
                    
                elif isinstance(node, ast.ClassDef):
                    class_entity = Entity(
                        id=f"class_{module_name}_{node.name}",
                        type="class",
                        name=node.name,
                        properties={
                            "module": module_name,
                            "line_number": node.lineno,
                            "bases": [base.id for base in node.bases if isinstance(base, ast.Name)],
                            "docstring": ast.get_docstring(node)
                        }
                    )
                    entities.append(class_entity)
            
        except Exception as e:
            print(f"Error parsing file {file_path}: {e}")
        
        return entities
    
    def find_function_calls(self, file_path: str) -> List[Relationship]:
        """Find function calls within a Python file to create relationships"""
        relationships = []
        
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                content = f.read()
            
            tree = ast.parse(content)
            module_name = os.path.basename(file_path).replace('.py', '')
            
            for node in ast.walk(tree):
                if isinstance(node, ast.FunctionDef):
                    current_func_id = f"function_{module_name}_{node.name}"
                    
                    # Find function calls within this function
                    for child in ast.walk(node):
                        if isinstance(child, ast.Call) and isinstance(child.func, ast.Name):
                            called_func_name = child.func.id
                            called_func_id = f"function_{module_name}_{called_func_name}"
                            
                            relationship = Relationship(
                                source_id=current_func_id,
                                target_id=called_func_id,
                                relationship_type="calls",
                                properties={"line_number": child.lineno}
                            )
                            relationships.append(relationship)
            
        except Exception as e:
            print(f"Error finding function calls in {file_path}: {e}")
        
        return relationships
    
    def ingest_codebase(self, directory_path: str):
        """Ingest an entire codebase into the knowledge graph"""
        print(f"Ingesting codebase from {directory_path}...")
        
        for root, dirs, files in os.walk(directory_path):
            for file in files:
                if file.endswith('.py'):
                    file_path = os.path.join(root, file)
                    print(f"Processing {file_path}...")
                    
                    # Extract entities
                    entities = self.parse_python_file(file_path)
                    for entity in entities:
                        self.add_entity(entity)
                    
                    # Extract relationships
                    relationships = self.find_function_calls(file_path)
                    for relationship in relationships:
                        self.add_relationship(relationship)
    
    def find_similar_entities(self, entity_type: str, query: str, limit: int = 3) -> List[Entity]:
        """Find similar entities based on type and name similarity"""
        similar_entities = []
        
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute('''
            SELECT id, type, name, properties, created_at 
            FROM entities 
            WHERE type = ? AND name LIKE ?
            ORDER BY name
            LIMIT ?
        ''', (entity_type, f"%{query}%", limit))
        
        rows = cursor.fetchall()
        conn.close()
        
        for row in rows:
            entity = Entity(
                id=row[0],
                type=row[1],
                name=row[2],
                properties=json.loads(row[3]) if row[3] else {},
                created_at=row[4]
            )
            similar_entities.append(entity)
        
        return similar_entities
    
    def get_entity_context(self, entity_id: str) -> Dict[str, Any]:
        """Get comprehensive context for an entity including relationships"""
        context = {
            "entity": None,
            "incoming_relationships": [],
            "outgoing_relationships": [],
            "related_entities": []
        }
        
        # Get the entity
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute('SELECT * FROM entities WHERE id = ?', (entity_id,))
        entity_row = cursor.fetchone()
        
        if entity_row:
            context["entity"] = Entity(
                id=entity_row[0],
                type=entity_row[1],
                name=entity_row[2],
                properties=json.loads(entity_row[3]) if entity_row[3] else {},
                created_at=entity_row[4]
            )
        
        # Get relationships
        cursor.execute('''
            SELECT source_id, target_id, relationship_type, properties 
            FROM relationships 
            WHERE source_id = ? OR target_id = ?
        ''', (entity_id, entity_id))
        
        relationships = cursor.fetchall()
        for rel in relationships:
            if rel[0] == entity_id:  # Outgoing
                context["outgoing_relationships"].append({
                    "target_id": rel[1],
                    "type": rel[2],
                    "properties": json.loads(rel[3]) if rel[3] else {}
                })
            else:  # Incoming
                context["incoming_relationships"].append({
                    "source_id": rel[0],
                    "type": rel[2],
                    "properties": json.loads(rel[3]) if rel[3] else {}
                })
        
        conn.close()
        return context
    
    def record_outcome(self, entity_id: str, outcome_type: str, outcome_data: Dict[str, Any]):
        """Record an outcome for learning purposes"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute('''
            INSERT INTO outcomes (entity_id, outcome_type, outcome_data, timestamp)
            VALUES (?, ?, ?, ?)
        ''', (entity_id, outcome_type, json.dumps(outcome_data), datetime.now().isoformat()))
        
        conn.commit()
        conn.close()
    
    def get_graph_stats(self) -> Dict[str, Any]:
        """Get statistics about the knowledge graph"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute('SELECT COUNT(*) FROM entities')
        entity_count = cursor.fetchone()[0]
        
        cursor.execute('SELECT COUNT(*) FROM relationships')
        relationship_count = cursor.fetchone()[0]
        
        cursor.execute('SELECT type, COUNT(*) FROM entities GROUP BY type')
        entity_types = dict(cursor.fetchall())
        
        conn.close()
        
        return {
            "total_entities": entity_count,
            "total_relationships": relationship_count,
            "entity_types": entity_types,
            "graph_density": nx.density(self.graph) if self.graph.number_of_nodes() > 0 else 0
        }

# Example usage and testing
if __name__ == "__main__":
    kg = KnowledgeGraph()
    
    # Ingest the current codebase
    kg.ingest_codebase("/home/ubuntu/meta-orchestrator")
    
    # Print statistics
    stats = kg.get_graph_stats()
    print("Knowledge Graph Statistics:")
    print(json.dumps(stats, indent=2))
    
    # Find similar functions
    similar_funcs = kg.find_similar_entities("function", "init", limit=3)
    print(f"\nFound {len(similar_funcs)} similar functions:")
    for func in similar_funcs:
        print(f"- {func.name} ({func.id})")

