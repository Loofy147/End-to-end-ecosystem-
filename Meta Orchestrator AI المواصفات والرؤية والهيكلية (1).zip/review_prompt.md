
You are now performing a code review.

Please review the following code for:
- Correctness
- Style guide adherence (as per project's MCP configuration)
- Potential bugs or edge cases
- Opportunities to refactor or DRY (Don't Repeat Yourself)
- Adherence to SOLID principles
- Readability and maintainability
- Completeness of documentation (docstrings, comments)

Code:
```{{language}}
{{generated_code}}
```

Feedback:


