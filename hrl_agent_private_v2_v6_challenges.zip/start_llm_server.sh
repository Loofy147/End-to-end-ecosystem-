
#!/bin/bash
# Start the local LLM server stub (runs in foreground)
python3 llm_local_server.py
