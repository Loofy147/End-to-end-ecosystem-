
#!/bin/bash
echo "LLM local integration helper - instructions"
echo "This script does NOT install a large LLM automatically."
echo "Recommended steps to integrate a local LLM:"
echo "1) Install a local model runtime (e.g., llama.cpp, text-generation-webui, or a dockerized model)."
echo "2) Host a local HTTP endpoint or Unix socket that accepts JSON prompts and returns JSON responses."
echo "3) Edit llm_adapter.py in the package to point to your local endpoint (change MODE and implement external branch)."
echo "Example (pseudo):"
echo '  curl -s -X POST http://localhost:8080/generate -d "{\"prompt\": \"...\"}" -H "Content-Type: application/json"'
