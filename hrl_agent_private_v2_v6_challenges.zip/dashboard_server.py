
from http.server import SimpleHTTPRequestHandler, HTTPServer
import os, json, threading, urllib.parse
from datetime import datetime
import time, io, zipfile, re

# Import run service utilities
import run_service_v2 as rsv2

PORT = 8787
ROOT = os.path.dirname(__file__)
TASKS_DIR = os.path.join(ROOT, "tasks")
RUNS_DIR = os.path.join(ROOT, "runs")
CONFIG_PATH = os.path.join(ROOT, "agent_config.json")

PROCESS_LOCK = threading.Lock()
SCHEDULER_ACTIVE = False
SCHEDULER_INTERVAL = 30
SCHEDULER_THREAD = None
SERVICE_LOG = os.path.join(ROOT, 'runs', 'service.log')

def list_runs(limit=100):
    files = [f for f in os.listdir(RUNS_DIR) if f.endswith(".json")]
    files.sort(reverse=True)
    out = []
    for f in files[:limit]:
        try:
            j = json.load(open(os.path.join(RUNS_DIR, f)))
            ok = all(s.get("verifier",{}).get("verified", False) for s in j.get("subgoals", []))
            out.append({
                "file": f,
                "timestamp": j.get("timestamp"),
                "problem_id": j.get("problem",{}).get("problem_id"),
                "goal": j.get("problem",{}).get("goal_high"),
                "success": ok,
                "subgoals": len(j.get("subgoals", []))
            })
        except Exception as e:
            out.append({"file": f, "error": str(e)})
    return out


def kpi():
    runs = list_runs(limit=999999)
    total = len(runs)
    success = sum(1 for r in runs if r.get("success"))
    return {
        "total_runs": total,
        "success_runs": success,
        "success_rate": (success/total if total else 0.0),
        "timestamp": datetime.utcnow().isoformat()+"Z"
    }

def kpi_series(window=20):
    # compute rolling success rate over last N runs
    runs = list_runs(limit=999999)
    flags = [1 if r.get("success") else 0 for r in runs]
    flags.reverse()  # chronological
    series = []
    for i in range(len(flags)):
        start = max(0, i-window+1)
        w = flags[start:i+1]
        rate = sum(w)/len(w) if w else 0.0
        series.append(rate)
    return {"window": window, "series": series}

def run_detail(file_name):
    path = os.path.join(RUNS_DIR, file_name)
    if not os.path.exists(path):
        return {"error":"not found"}
    try:
        j = json.load(open(path, "r", encoding="utf-8"))
    except Exception as e:
        return {"error": str(e)}
    return j

def tail_log(lines=200):
    if not os.path.exists(SERVICE_LOG):
        return ""
    with open(SERVICE_LOG, "r", encoding="utf-8") as f:
        data = f.read().splitlines()
    return "\n".join(data[-lines:])

def export_runs_zip():
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, 'w', zipfile.ZIP_DEFLATED) as zf:
        for f in os.listdir(RUNS_DIR):
            if f.endswith(".json"):
                zf.write(os.path.join(RUNS_DIR,f), arcname=f)
    return buf.getvalue()

def rebuild_report_and_certificate():
    # Re-generate KPI report (reuse existing logic in runs/kpi_report.md if present)
    # Simply call generate_certificate.py after ensuring report exists
    try:
        # attempt to (re)generate report via existing report generator if available
        import subprocess, sys
        py = sys.executable
        # If report generator isn't available, it's okay—certificate script reads existing report
        subprocess.run([py, "generate_certificate.py"], cwd=ROOT, check=False, capture_output=True)
    except Exception:
        pass
    # return file presence info
    rep_md = os.path.join(RUNS_DIR, "kpi_report.md")
    cert_pdf = os.path.join(RUNS_DIR, "certificate_signed.pdf")
    cert_txt = os.path.join(RUNS_DIR, "certificate_signed.txt")
    return {
        "report_md_exists": os.path.exists(rep_md),
        "certificate_pdf_exists": os.path.exists(cert_pdf),
        "certificate_txt_exists": os.path.exists(cert_txt),
    }

    runs = list_runs(limit=999999)
    total = len(runs)
    success = sum(1 for r in runs if r.get("success"))
    return {
        "total_runs": total,
        "success_runs": success,
        "success_rate": (success/total if total else 0.0),
        "timestamp": datetime.utcnow().isoformat()+"Z"
    }

def list_tasks(limit=200):
    files = [f for f in os.listdir(TASKS_DIR) if f.endswith(".json")]
    files.sort()
    out = []
    for f in files[:limit]:
        try:
            j = json.load(open(os.path.join(TASKS_DIR, f)))
            out.append({
                "file": f,
                "problem_id": j.get("problem_id"),
                "type": j.get("meta",{}).get("type"),
                "goal": j.get("goal_high")
            })
        except Exception as e:
            out.append({"file": f, "error": str(e)})
    return out


def process_once(max_tasks=50):
    # lock to avoid concurrent processing
    with PROCESS_LOCK:
        res = rsv2.run_once(max_tasks=max_tasks)
    return {"processed": len(res)}

def scheduler_loop():
    global SCHEDULER_ACTIVE, SCHEDULER_INTERVAL
    while SCHEDULER_ACTIVE:
        try:
            process_once(max_tasks=50)
        except Exception as e:
            pass
        for _ in range(SCHEDULER_INTERVAL):
            if not SCHEDULER_ACTIVE: break
            time.sleep(1)

def scheduler_start(interval=30):
    global SCHEDULER_ACTIVE, SCHEDULER_INTERVAL, SCHEDULER_THREAD
    if SCHEDULER_ACTIVE: return {"status":"already_running","interval":SCHEDULER_INTERVAL}
    SCHEDULER_INTERVAL = max(5, int(interval))
    SCHEDULER_ACTIVE = True
    t = threading.Thread(target=scheduler_loop, daemon=True)
    SCHEDULER_THREAD = t
    t.start()
    return {"status":"started","interval":SCHEDULER_INTERVAL}

def scheduler_stop():
    global SCHEDULER_ACTIVE
    SCHEDULER_ACTIVE = False
    return {"status":"stopped"}

    # lock to avoid concurrent processing
    with PROCESS_LOCK:
        res = rsv2.run_once(max_tasks=max_tasks)
    return {"processed": len(res)}

def set_llm_mode(mode):
    # Update agent_config.json; effective after next run
    try:
        cfg = json.load(open(CONFIG_PATH, "r", encoding="utf-8"))
    except Exception:
        cfg = {}
    cfg["llm_mode"] = mode
    json.dump(cfg, open(CONFIG_PATH, "w", encoding="utf-8"), ensure_ascii=False, indent=2)
    return {"llm_mode": mode}

def add_task(task_json):
    # Create a unique filename
    pid = task_json.get("problem_id") or "p"
    fname = f"user_{pid}_{int(__import__('time').time())}.json"
    with open(os.path.join(TASKS_DIR, fname), "w", encoding="utf-8") as f:
        json.dump(task_json, f, ensure_ascii=False, indent=2)
    return {"added": fname}

class Handler(SimpleHTTPRequestHandler):
    def _send_json(self, obj, code=200):
        data = json.dumps(obj).encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)


def do_GET(self):
    p = urllib.parse.urlparse(self.path)
    if p.path == "/":
        return SimpleHTTPRequestHandler.do_GET(self)
    if p.path == "/api/kpi":
        return self._send_json(kpi())
    if p.path == "/api/kpi_series":
        qs = urllib.parse.parse_qs(p.query or "")
        window = int(qs.get("window", ["20"])[0])
        return self._send_json(kpi_series(window=window))
    if p.path == "/api/runs":
        qs = urllib.parse.parse_qs(p.query or "")
        limit = int(qs.get("limit", ["100"])[0])
        flt = qs.get("filter", ["all"])[0]
        search = qs.get("q", [""])[0]
        data = list_runs(limit=999999)
        # filtering
        if flt == "success":
            data = [r for r in data if r.get("success")]
        elif flt == "fail":
            data = [r for r in data if not r.get("success")]
        if search:
            rx = re.compile(re.escape(search), re.IGNORECASE)
            data = [r for r in data if rx.search(r.get("problem_id","") or "") or rx.search(r.get("goal","") or "")]
        return self._send_json(data[:limit])
    if p.path.startswith("/api/run/"):
        name = p.path.split("/api/run/")[-1]
        return self._send_json(run_detail(name))
    if p.path == "/api/tasks":
        return self._send_json(list_tasks())
    if p.path == "/api/process":
        qs = urllib.parse.parse_qs(p.query or "")
        max_tasks = int(qs.get("max", ["50"])[0])
        return self._send_json(process_once(max_tasks=max_tasks))
    if p.path == "/api/config":
        try:
            cfg = json.load(open(CONFIG_PATH, "r", encoding="utf-8"))
        except Exception:
            cfg = {}
        return self._send_json(cfg)
    if p.path == "/api/logs":
        qs = urllib.parse.parse_qs(p.query or "")
        lines = int(qs.get("lines", ["200"])[0])
        return self._send_json({"log": tail_log(lines)})
    if p.path == "/api/export/runs_zip":
        data = export_runs_zip()
        self.send_response(200)
        self.send_header("Content-Type", "application/zip")
        self.send_header("Content-Disposition", "attachment; filename=runs_export.zip")
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data); return
    if p.path == "/api/export/rebuild":
        return self._send_json(rebuild_report_and_certificate())
    if p.path == "/api/scheduler/start":
        qs = urllib.parse.parse_qs(p.query or "")
        interval = int(qs.get("interval", ["30"])[0])
        return self._send_json(scheduler_start(interval))
    if p.path == "/api/scheduler/stop":
        return self._send_json(scheduler_stop())
    return SimpleHTTPRequestHandler.do_GET(self)

        p = urllib.parse.urlparse(self.path)
        if p.path == "/":
            return SimpleHTTPRequestHandler.do_GET(self)
        if p.path == "/api/kpi":
            return self._send_json(kpi())
        if p.path == "/api/difficulty_buckets":
            try:
                # compute buckets from tasks
                tdir = os.path.join(ROOT, 'tasks')
                buckets = [0,0,0,0,0]
                if os.path.exists(tdir):
                    for f in os.listdir(tdir):
                        if f.endswith('.json'):
                            try:
                                j = json.load(open(os.path.join(tdir,f),'r',encoding='utf-8'))
                                d = j.get('difficulty_estimate',0.0)
                                idx = min(4, int(d*5))
                                buckets[idx] += 1
                            except:
                                pass
                return self._send_json({'task_buckets': buckets})
            except Exception as e:
                return self._send_json({'error': str(e)})

        if p.path == "/api/runs":
            qs = urllib.parse.parse_qs(p.query or "")
            limit = int(qs.get("limit", ["100"])[0])
            return self._send_json(list_runs(limit=limit))
        if p.path == "/api/tasks":
            return self._send_json(list_tasks())
        if p.path == "/api/process":
            qs = urllib.parse.parse_qs(p.query or "")
            max_tasks = int(qs.get("max", ["50"])[0])
            return self._send_json(process_once(max_tasks=max_tasks))
        if p.path == "/api/config":
            try:
                cfg = json.load(open(CONFIG_PATH, "r", encoding="utf-8"))
            except Exception:
                cfg = {}
            return self._send_json(cfg)
        return SimpleHTTPRequestHandler.do_GET(self)


def do_POST(self):
    p = urllib.parse.urlparse(self.path)
    length = int(self.headers.get("Content-Length", "0"))
    body = self.rfile.read(length).decode("utf-8") if length else ""
    if p.path == "/api/add_task":
        try:
            obj = json.loads(body) if body else {}
        except Exception as e:
            return self._send_json({"error": str(e)}, code=400)
        # Accept array or JSONL string under {"batch": "..."} as well
        if isinstance(obj, list):
            added = []
            for item in obj:
                r = add_task(item)
                added.append(r.get("added"))
            return self._send_json({"added_batch": added})
        if "batch" in obj and isinstance(obj.get("batch"), str):
            lines = [ln.strip() for ln in obj["batch"].splitlines() if ln.strip()]
            added = []
            for ln in lines:
                try:
                    item = json.loads(ln)
                    r = add_task(item)
                    added.append(r.get("added"))
                except Exception:
                    pass
            return self._send_json({"added_batch": added})
        return self._send_json(add_task(obj))
    if p.path == "/api/config":
        try:
            obj = json.loads(body) if body else {}
            # allow full config update; minimal validation
            assert isinstance(obj, dict)
        except Exception as e:
            return self._send_json({"error": str(e)}, code=400)
        json.dump(obj, open(CONFIG_PATH, "w", encoding="utf-8"), ensure_ascii=False, indent=2)
        return self._send_json({"status":"saved"})
    return self._send_json({"error":"Unknown endpoint"}, code=404)

        p = urllib.parse.urlparse(self.path)
        length = int(self.headers.get("Content-Length", "0"))
        body = self.rfile.read(length).decode("utf-8") if length else ""
        if p.path == "/api/add_task":
            try:
                obj = json.loads(body) if body else {}
            except Exception as e:
                return self._send_json({"error": str(e)}, code=400)
            return self._send_json(add_task(obj))
        if p.path == "/api/config":
            try:
                obj = json.loads(body) if body else {}
                mode = obj.get("llm_mode", "local_stub")
            except Exception as e:
                return self._send_json({"error": str(e)}, code=400)
            return self._send_json(set_llm_mode(mode))
        return self._send_json({"error":"Unknown endpoint"}, code=404)

if __name__=="__main__":
    os.chdir(os.path.join(ROOT, "control_panel"))
    server = HTTPServer(("127.0.0.1", PORT), Handler)
    print(f"Control Panel available at http://127.0.0.1:{PORT}/")
    server.serve_forever()
