import hashlib, math
def hash_to_vector(s, dim=64):
    h = hashlib.sha256(s.encode('utf-8')).digest()
    vec = []
    for i in range(dim):
        start = (i*4) % len(h)
        chunk = h[start:start+4]
        val = int.from_bytes(chunk, 'little', signed=False)
        vec.append((val / 2**32) * 2 - 1)
    return vec

def embed(obj, dim=64):
    return hash_to_vector(str(obj), dim=dim)

def dot(a,b):
    return sum(x*y for x,y in zip(a,b))

def norm(a):
    return math.sqrt(sum(x*x for x in a))

def cosine(a,b):
    na = norm(a); nb = norm(b)
    if na==0 or nb==0: return 0.0
    return dot(a,b)/(na*nb)