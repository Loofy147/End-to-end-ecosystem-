
#!/usr/bin/env python3
import os, json, argparse, random, math, uuid, time

WEATHERS = ['clear','rain_light','rain_heavy','fog','night']
MAPS = ['Town01','Town02','Town03','Highway01','Suburb02']

def difficulty_score_driving(meta):
    dyn = meta.get('dynamic_agents',0)
    traffic = meta.get('traffic_density',0)
    noise = (meta.get('sensor_noise',{}).get('lidar',0)+meta.get('sensor_noise',{}).get('camera',0))/2.0
    po = meta.get('partial_observability',0)
    time_budget = meta.get('time_budget_sec',60)
    s = 0.25*min(1.0, dyn/20.0) + 0.25*traffic + 0.15*noise + 0.2*po + 0.15*max(0, (30-time_budget)/30)
    return max(0.0, min(1.0, s))

def gen_driving_task(bucket):
    dyn_base = [0,2,6,12,25][bucket]
    traffic = [0.0,0.2,0.45,0.7,0.95][bucket]
    weather = WEATHERS[min(bucket, len(WEATHERS)-1)]
    noise = 0.005 * (1 + bucket*4)
    po = 0.0 + bucket*0.25
    goal = [random.uniform(20,200), random.uniform(20,200), 0.0]
    meta = {'env':'CARLA-v0','map_id': random.choice(MAPS),'start':[0.0,0.0,0.0],'goal': goal,
            'dynamic_agents': dyn_base,'traffic_density': traffic,'weather': weather,
            'sensor_noise': {'lidar': noise, 'camera': noise*2},'partial_observability': po,
            'time_budget_sec': max(20, 120 - bucket*15),'seed': random.randint(0,999999)}
    return meta

def gen_robot_task(bucket):
    slip = 0.0 + bucket*0.15
    dyn = [0,1,3,6,10][bucket]
    subgoals = 1 + bucket
    meta = {'env':'MiniWorldSim','map_id':'indoor_'+str(bucket),'start':[0,0,0],'goal':[5+bucket*3,5,0],
            'dynamic_agents': dyn,'slip': slip,'sensor_noise': {'lidar': 0.01 * (1 + bucket)},
            'subgoals': subgoals,'time_budget_sec': max(10,60 - bucket*5),'seed': random.randint(0,999999)}
    return meta

def gen_coding_task(bucket):
    base_size = [1000, 5000, 20000, 200000, 2000000][bucket]
    forbidden = ['sort()'] if bucket>=2 else []
    tests = ['unit_1','unit_2'] + (['stress_1'] if bucket>=2 else [])
    meta = {'problem_template': 'process_large_log_and_aggregate','input_size': base_size,
            'forbidden_patterns': forbidden,'correctness_tests': tests,'time_limit_sec': [10,8,5,3,1][bucket],
            'structural_complexity': 0.2 + 0.2*bucket,'seed': random.randint(0,999999)}
    return meta

def synthesize_from_recording(rec, kind):
    if kind=='driving':
        return {'env':'CARLA-v0','map_id': rec.get('map','Town01'),'start': rec.get('start',[0,0,0]),
                'goal': rec.get('goal',[50,50,0]), 'dynamic_agents': min(40, rec.get('vehicles',0)+rec.get('pedestrians',0)),
                'traffic_density': rec.get('traffic_density',0.2),'weather': rec.get('weather','clear'),
                'sensor_noise': rec.get('sensor_noise',{'lidar':0.01,'camera':0.02}),
                'partial_observability': rec.get('partial_observability',0.0),'time_budget_sec': rec.get('time_budget_sec',60),
                'seed': random.randint(0,999999)}
    if kind=='robot_nav':
        return {'env':'MiniWorldSim','map_id': rec.get('map','indoor_0'),'start': rec.get('start',[0,0,0]),
                'goal': rec.get('goal',[5,5,0]), 'dynamic_agents': rec.get('humans',0),'slip': rec.get('slip',0.0),
                'sensor_noise': rec.get('sensor_noise',{'lidar':0.01}),'subgoals': rec.get('subgoals',1),
                'time_budget_sec': rec.get('time_budget_sec',60),'seed': random.randint(0,999999)}
    if kind=='coding':
        return {'problem_template': rec.get('template','process_logs'),'input_size': rec.get('input_size',1000),
                'forbidden_patterns': rec.get('forbidden',[]),'correctness_tests': rec.get('tests',[]),
                'time_limit_sec': rec.get('time_limit_sec',10),'structural_complexity': rec.get('structural_complexity',0.5),
                'seed': random.randint(0,999999)}
    return {}

def make_task(kind, idx, meta):
    task_id = f"task_{kind}_{idx:04d}"
    task = {'task_id': task_id, 'problem_id': f'{kind}:{uuid.uuid4().hex[:8]}', 'goal_high': meta.get('goal_high', kind+'_challenge'),
            'type': kind, 'meta': meta}
    # difficulty estimate naive
    if kind=='driving':
        task['difficulty_estimate'] = round(difficulty_score_driving(meta),3)
    elif kind=='robot_nav':
        # small heuristic: reuse driving scoring for placeholder
        task['difficulty_estimate'] = round(min(1.0, (meta.get('dynamic_agents',0)/10.0 + meta.get('slip',0))*0.5),3)
    else:
        task['difficulty_estimate'] = round(min(1.0, math.log1p(meta.get('input_size',1000))/10.0),3)
    task['tags'] = [kind]
    return task

def generate_tasks(out_dir, n_per_type=30, seed=42, use_recordings=False):
    random.seed(seed)
    os.makedirs(out_dir, exist_ok=True)
    idx = 0
    recs = []
    if use_recordings:
        rec_dir = os.path.join(os.path.dirname(__file__), 'data', 'recordings')
        if os.path.exists(rec_dir):
            for fn in os.listdir(rec_dir):
                if fn.endswith('.json'):
                    try:
                        recs.append(json.load(open(os.path.join(rec_dir, fn),'r',encoding='utf-8')))
                    except:
                        pass
    for kind in ['driving','robot_nav','coding']:
        for i in range(n_per_type):
            bucket = min(4, int(i * 5 / max(1, n_per_type-1)))
            if use_recordings and recs and random.random() < 0.4:
                rec = random.choice(recs)
                meta = synthesize_from_recording(rec, kind)
            else:
                if kind=='driving':
                    meta = gen_driving_task(bucket)
                elif kind=='robot_nav':
                    meta = gen_robot_task(bucket)
                else:
                    meta = gen_coding_task(bucket)
            task = make_task(kind, idx, meta)
            fname = os.path.join(out_dir, task['task_id'] + '.json')
            with open(fname, 'w', encoding='utf-8') as f:
                json.dump(task, f, indent=2, ensure_ascii=False)
            idx += 1
    print(f'Generated {idx} tasks in {out_dir} (use_recordings={use_recordings})')

if __name__=='__main__':
    p = argparse.ArgumentParser()
    p.add_argument('--out', default='tasks')
    p.add_argument('--n-per-type', type=int, default=30)
    p.add_argument('--seed', type=int, default=42)
    p.add_argument('--use-recordings', action='store_true')
    args = p.parse_args()
    generate_tasks(args.out, args.n_per_type, args.seed, args.use_recordings)
