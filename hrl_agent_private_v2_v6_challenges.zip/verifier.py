def verify(subgoal, result):
    sc = subgoal.get("success_criteria", {})
    issues = []
    ok = True
    if "distance_lt" in sc:
        final = result.get("final_pos")
        if final is None:
            ok = False
            issues.append("no_final_pos")
        else:
            wp = subgoal["exec_spec"]["waypoint"]
            dist = abs(final[0]-wp[0]) + abs(final[1]-wp[1])
            if dist > sc["distance_lt"]:
                ok = False
                issues.append(f"distance_too_large:{dist}")
    if "picked" in sc:
        if not result.get("picked", False):
            ok = False
            issues.append("not_picked")
    if "delivered" in sc:
        if not result.get("delivered", False):
            ok = False
            issues.append("not_delivered")
    if "sum_eq" in sc:
        expected = sc["sum_eq"]
        if "roots" in result:
            s = sum(result["roots"])
        elif "sum" in result:
            s = result["sum"]
        else:
            ok = False
            issues.append("no_sum_info")
            s = None
        if s is None or abs(s-expected) > 1e-8:
            ok = False
            issues.append(f"sum_mismatch:{s}_vs_{expected}")
    return {"verified": ok, "issues": issues}