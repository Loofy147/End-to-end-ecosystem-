# Minimal POST helper using urllib if 'requests' isn't installed
import json, urllib.request, urllib.error

def post_json(url, obj, timeout=5):
    data = json.dumps(obj).encode('utf-8')
    req = urllib.request.Request(url, data=data, headers={'Content-Type':'application/json'})
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            return json.load(resp)
    except urllib.error.URLError as e:
        raise