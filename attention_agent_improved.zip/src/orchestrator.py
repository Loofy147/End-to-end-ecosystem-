import time
import torch
from typing import Dict, Any
from .consistency import AttentionDataConsistencyManager
from .consistency import ConsistencyLevel
from enum import Enum
from collections import defaultdict

class AttentionUpdateType(Enum):
    GRADIENT = "gradient"
    MOMENTUM = "momentum"
    ADAPTIVE = "adaptive"
    DECAY = "decay"
    LAYER_NORM = "layer_norm"
    NOISE_RESILIENT = "noise_resilient"

class AttentionWeightUpdateOrchestrator:
    def __init__(self, consistency: AttentionDataConsistencyManager):
        self.consistency = consistency
        self.strategies = {
            AttentionUpdateType.GRADIENT: self._grad,
            AttentionUpdateType.MOMENTUM: self._momentum,
            AttentionUpdateType.ADAPTIVE: self._adaptive,
            AttentionUpdateType.DECAY: self._decay,
            AttentionUpdateType.LAYER_NORM: self._layer_norm,
            AttentionUpdateType.NOISE_RESILIENT: self._noise_resilient
        }
        self.momentum_buf = {}
        self.adaptive_rates = defaultdict(lambda: 0.001)

    def execute_update(self, tid, tensor, utype, params):
        if not self.consistency.validate(tid, self.consistency.registry[tid].version):
            self.consistency.log_violation(tid, self.consistency.registry[tid].version, self.consistency.registry[tid].version)
            raise RuntimeError("Consistency failed")
        return self.strategies[utype](tid, tensor, params)

    def _grad(self, tid, tensor, params):
        lr = params.get('lr', 1e-3)
        grad = params.get('grad', torch.zeros_like(tensor))
        return tensor - lr*grad

    def _momentum(self, tid, tensor, params):
        lr = params.get('lr',1e-3); mom=params.get('mom',0.9); g=params.get('grad',torch.zeros_like(tensor))
        buf = self.momentum_buf.setdefault(tid, torch.zeros_like(tensor))
        buf.mul_(mom).add_(g, alpha=1-mom)
        return tensor - lr*buf

    def _adaptive(self, tid, tensor, params):
        base = params.get('base',1e-3); af = params.get('factor',0.95); g=params.get('grad',torch.zeros_like(tensor))
        norm = g.norm()
        r = self.adaptive_rates[tid]
        self.adaptive_rates[tid] = r*af if norm>1 else min(r*(1/af), base)
        return tensor - self.adaptive_rates[tid]*g

    def _decay(self, tid, tensor, params):
        rate=params.get('decay',1e-4)
        return tensor*(1-rate)

    def _layer_norm(self, tid, tensor, params):
        eps=params.get('eps',1e-5); dim=params.get('dim',-1)
        mn=tensor.mean(dim=dim,keepdim=True); vr=tensor.var(dim=dim,keepdim=True,unbiased=False)
        norm=(tensor-mn)/torch.sqrt(vr+eps)
        g=params.get('gamma',torch.ones_like(tensor)); b=params.get('beta', torch.zeros_like(tensor))
        return g*norm + b

    def _noise_resilient(self, tid, tensor, params):
        lr=params.get('lr',1e-3); g=params.get('grad',torch.zeros_like(tensor))
        noise = torch.randn_like(g)*params.get('noise_std',0.005)
        return tensor - lr*(g+noise)
