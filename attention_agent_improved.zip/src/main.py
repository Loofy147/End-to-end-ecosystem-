import torch, json
from .attention_agent_core import MultiHeadAttentionDataAgent
from .consistency import ConsistencyLevel
from .orchestrator import AttentionUpdateType

def demo():
    agent = MultiHeadAttentionDataAgent(4, 128, ConsistencyLevel.TEMPORAL)
    x = torch.randn(1, 10, 128)
    out = agent.compute_attention(x)
    agent.update_weights(0, AttentionUpdateType.NOISE_RESILIENT, {'lr':0.001, 'grad':torch.randn_like(agent.attention_weights['query_head_0']), 'noise_std':0.01})
    status = agent.consistency.registry
    print(json.dumps({'output_shape': out.shape, 'registered_tensors': list(status.keys())}, default=str, indent=2))

if __name__ == "__main__":
    demo()
