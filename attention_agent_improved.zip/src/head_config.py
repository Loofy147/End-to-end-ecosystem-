import numpy as np
from dataclasses import dataclass, field
from typing import Tuple, Any

@dataclass
class AttentionHeadConfiguration:
    head_id: int
    input_dim: int
    key_dim: int
    value_dim: int
    output_dim: int
    dropout: float = 0.1
    scaling_factor: float = field(init=False)

    def __post_init__(self):
        self.scaling_factor = 1.0 / np.sqrt(self.key_dim)
