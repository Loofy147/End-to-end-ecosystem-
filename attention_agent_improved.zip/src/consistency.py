import threading, time, hashlib
from enum import Enum
from typing import Dict, Any, List, Tuple
from dataclasses import dataclass, field
import torch
from collections import defaultdict

class ConsistencyLevel(Enum):
    EVENTUAL = "eventual"
    STRONG = "strong"
    CAUSAL = "causal"
    TEMPORAL = "temporal"

@dataclass
class AttentionTensorMetadata:
    tensor_id: str
    shape: Tuple[int, ...]
    dtype: torch.dtype
    creation_time: float
    version: int = 0
    checksum: str = ""
    history: List[Dict[str, Any]] = field(default_factory=list)

    def update_checksum(self, tensor: torch.Tensor):
        self.checksum = hashlib.sha256(tensor.detach().cpu().numpy().tobytes()).hexdigest()
        self.version += 1
        self.history.append({"version": self.version, "time": time.time()})

class AttentionDataConsistencyManager:
    def __init__(self, level: ConsistencyLevel):
        self.level = level
        self.registry: Dict[str, AttentionTensorMetadata] = {}
        self.locks = defaultdict(threading.RLock)
        self.violations: List[Dict[str, Any]] = []

    def register_tensor(self, tid: str, tensor: torch.Tensor):
        with self.locks[tid]:
            meta = AttentionTensorMetadata(tid, tensor.shape, tensor.dtype, time.time())
            meta.update_checksum(tensor)
            self.registry[tid] = meta
            return meta

    def validate(self, tid: str, expected: int) -> bool:
        with self.locks[tid]:
            if self.level == ConsistencyLevel.STRONG:
                return self.registry[tid].version == expected
            return True

    def log_violation(self, tid, expected, actual):
        self.violations.append({"tid": tid, "exp": expected, "act": actual, "time": time.time()})
