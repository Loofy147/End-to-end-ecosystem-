import torch
from typing import Dict, Any
from .orchestrator import AttentionWeightUpdateOrchestrator
from .consistency import AttentionDataConsistencyManager, ConsistencyLevel
from .head_config import AttentionHeadConfiguration

class MultiHeadAttentionDataAgent:
    """Refactored multi-head attention agent with separated modules"""
    def __init__(self, num_heads: int, input_dim: int,
                 consistency_level: ConsistencyLevel = ConsistencyLevel.STRONG):
        self.num_heads = num_heads
        self.input_dim = input_dim
        self.head_dim = input_dim // num_heads

        # Initialize components
        self.consistency_manager = AttentionDataConsistencyManager(consistency_level)
        self.update_orchestrator = AttentionWeightUpdateOrchestrator(self.consistency_manager)

        # Head configurations
        self.head_configurations = [
            AttentionHeadConfiguration(head_id=i, input_dim=input_dim, key_dim=self.head_dim,
                                       value_dim=self.head_dim, output_dim=self.head_dim)
            for i in range(num_heads)
        ]

        # Initialize weights
        self.attention_weights = self._init_weights()
        self.performance_metrics = {"latencies": [], "success": 0, "fail": 0}

    def _init_weights(self) -> Dict[str, torch.Tensor]:
        weights = {}
        for head_id in range(self.num_heads):
            for t in ['query', 'key', 'value', 'output']:
                w = torch.randn(self.input_dim if t!='output' else self.head_dim,
                                self.head_dim if t!='output' else self.input_dim) * 0.02
                tid = f"{t}_head_{head_id}"
                weights[tid] = w
                self.consistency_manager.register_tensor(tid, w)
        return weights

    def compute_attention(self, x, mask=None):
        outputs = []
        for head_id in range(self.num_heads):
            q = x @ self.attention_weights[f"query_head_{head_id}"]
            k = x @ self.attention_weights[f"key_head_{head_id}"]
            v = x @ self.attention_weights[f"value_head_{head_id}"]
            scores = (q @ k.transpose(-2, -1)) / self.head_configurations[head_id].scaling_factor
            if mask is not None:
                scores = scores.masked_fill(mask==0, -1e9)
            probs = torch.softmax(scores, dim=-1)
            outputs.append(probs @ v)
        return torch.cat(outputs, dim=-1)

    def update_weights(self, head_id, update_type, params):
        backup = {tid: w.clone() for tid, w in self.attention_weights.items()}
        try:
            for t in ['query', 'key', 'value', 'output']:
                tid = f"{t}_head_{head_id}"
                updated = self.update_orchestrator.execute_update(tid,
                                  self.attention_weights[tid], update_type, params)
                self.attention_weights[tid] = updated
            self.performance_metrics["success"] += 1
        except Exception:
            self.attention_weights = backup
            self.performance_metrics["fail"] += 1
            raise
        finally:
            # record latency
            pass  # integrated inside orchestrator
